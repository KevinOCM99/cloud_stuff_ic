#!/bin/bash

#Used by Python to locate modules
#

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"

export PYTHONPATH=${DIR}

#WLST is Jython based, which doesn't use PYTHONPATH  set via WLST_PROPERTIES
#
export WLST_PROPERTIES="-Dweblogic.security.SSL.minimumProtocolVersion=TLSv1.2 -Dpython.path=${DIR}"

#Variable set help reference Python Utility files
# example:
#    ${PYTHONUTILSPATH}/shellLogging.py
#
export PYTHONUTILSPATH=${DIR}/pythonUtils/
