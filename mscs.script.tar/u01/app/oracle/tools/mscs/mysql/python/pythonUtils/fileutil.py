#
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#
"""
Description: These are common methods for file operations.
"""
import pythonUtils
import pythonUtils.commonLogging as commonLogging

import os
import socket
import time


def print_content(file_name, host=None, logger=None, file_description=None, delete=False):
    """
    Print the contents of the file on stdout
    :param file_name: full path to the file to be printed.
    :type file_name: str
    :param host: Name of the host on which the file is present. Default is local host
    :type host: str
    :param logger: logger to log the error messages.
    :type logger: logging.Logger
    :param file_description: Descriptive file name. If None, defaults to file_name.
        Example: file_name="/path/nodemanager.log", file_description="Node Manager Log File"
    :type file_description: str
    :param delete: If True, the file is deleted after it's contents are printed. Default is False.
    :type delete: bool
    :return: Return 0 if the operation is successful.
             Return error code https://docs.python.org/2/library/errno.html  in case of error.
    :rtype: int
    """

    local_host = socket.gethostname()
    if host is None:
        host = local_host

    if not file_description:
        file_description = "%s on the host %s" %(file_name, host)

    if host != local_host:
        tmp_file_name = "/tmp/%s_%s_%s" % (host, str(os.path.basename(file_name)), time.time())
        pythonUtils.execute_scp_cmd(file_name, tmp_file_name, host, local_host)
        #fixme: delete remote file, if requested
        return __print_content__(tmp_file_name, logger, file_description, delete=True)

    return __print_content__(file_name, logger, file_description, delete)


def __print_content__(file_name, logger=None, file_description=None, delete=False):

    if logger is None:
        logger = commonLogging.getLogger("fileutil")

    try:
        with open(file_name, 'r') as fin:
            msg = "The content of the file %s are:\n%s" % (file_description, fin.read())
            logger.info(msg)
    except IOError as io_error:
        msg = "<JCS-ERR-20157> : Unable to open file %s. Reason : %s" % (file_name, io_error.strerror)
        logger.error(msg)
        return io_error.errno

    if delete:
        remove_file(file_name, logger)

    return 0

def remove_file(file_name, logger=None):
    """
    Remove the file
    :param file_name: full path to the file to be removed.
    :type file_name: str
    :param logger: logger to log the error messages.
    :type logger: logging.Logger
    :return:
        Return 0 if the operation is successful.
        Return error code https://docs.python.org/2/library/errno.html in case of error.
    :rtype: int
    """

    if logger is None:
        logger = commonLogging.getLogger("fileutil")

    try:
        os.remove(file_name)
        return 0
    except OSError as os_error:
        msg = "<JCS-ERR-20158> : Unable to remove file %s. Reason : %s" % (file_name, os_error.strerror)
        logger.error(msg)
        return os_error.errno

def print_wlserver_log(domain_path, server_name, host, logger=None, print_out_file=True, print_log_file=False):
    """
    Print weblogic server logs on stdout.
    :param domain_path: full path to the Weblogic server domain including domain home path / domain name
    :type domain_path: str
    :param server_name: Weblogic server administration server or managed server name whose logs are to be printed
    :type server_name: str
    :param logger: logger to log the error messages.
    :type logger: logging.Logger
    :param print_out_file:  If True, print wl server ,out file.  Default is True.
    :type print_out_file: bool
    :param print_log_file:  If True, print wl server log file.  Default is False.
    :type print_log_file: bool
    :return: Return 0 if the operation is successful. Return > 0 in case of error.
    :rtype: int

    """

    path_prefix = "%s/servers/%s/logs/%s" % (domain_path, server_name, server_name)
    status = 0

    if print_log_file:
        status += print_content("%s.log" % path_prefix, host, logger=logger)

    if print_out_file:
        status += print_content("%s.out" % path_prefix, host, logger=logger)

    return status

def print_wlserver_logs(domain_path, servers, logger=None, print_out_file=True, print_log_file=False):
    """
    Print weblogic server logs on stdout.
    :param domain_path: full path to the Weblogic server domain including domain home path / domain name
    :type domain_path: str
    :param servers: Dictionary of (server_name, host_name) key value pairs,
        containing Weblogic server names whose logs are to be printed, and corresponding host names to pull the logs from
        Example:  servers = dict([('server1', 'host1'), ('server2',  host2)])
    :type servers: dict
    :param logger: logger to log the error messages.
    :type logger: logging.Logger
    :param print_out_file:  If True, print wl server ,out file.  Default is True.
    :type print_out_file: bool
    :param print_log_file:  If True, print wl server log file.  Default is False.
    :type print_log_file: bool
    :return: Return 0 if the operation is successful. Return > 0 in case of error.
    :rtype: int

    """

    for server_name in servers.keys():
        print_wlserver_log(domain_path, server_name, servers.get(server_name), logger, print_out_file, print_log_file)

def print_node_manager_log(node_manager_home, host, logger=None, print_log_file=True, print_properties_file=False):
    """
    Print node manager log file and properties file on stdout.
    If the host is remote, the files are copies over from the remote host.
    :param node_manager_home: full path to the Weblogic server node manager home directory.
    :type node_manager_home: str
    :param host: name of the host to pull the node manager logs from
    :type host: str
    :param logger: logger to log the error messages.
    :type logger: logging.Logger
    :param print_log_file:  If True, print node manager log file.  Default is True.
    :type print_log_file: bool
    :param print_properties_file:  If True, print node manager properties file.  Default is False.
    :type print_properties_file: bool
    :return: Return 0 if the operation is successful. Return > 0 in case of error.
    :rtype: int
    """

    status = 0

    if print_log_file:
        nm_log = "%s/nodemanager.log" % node_manager_home
        status += print_content(nm_log, host, logger)

    if print_properties_file:
        nm_props = "%s/nodemanager.properties" % node_manager_home
        status += print_content(nm_props, host, logger)

    return status

def print_node_manager_logs(node_manager_home, hosts, logger=None, print_log_file=True, print_properties_file=False):
    """
    Print the Weblogic server node manager log file and properties file for each host on stdout.
    :param node_manager_home: full path to the Weblogic server node manager home directory.
    :type node_manager_home: str
    :param hosts: List of the host names to pull the node manager logs from.
    :type hosts: list
    :param logger: logger to log the error messages. If None, print the error on stdout. Default is None.
    :type logger: logging.Logger
    """

    for host in hosts:
        # fixme: This assumes that node manager home is same on all the hosts. Use host:node_manager_home to remove the assumption.
        print_node_manager_log(node_manager_home, host, logger, print_log_file, print_properties_file)
