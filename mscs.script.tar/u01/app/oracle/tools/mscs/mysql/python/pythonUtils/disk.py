#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
Description: These are common methods for disk, directory, or files command.
"""
import pythonUtils.commonLogging as commonLogging
import pythonUtils

def get_disk_info(path, host=None):
    """
    Gathers information about a disk and return the information via the DiskInfoClass.
    DiskInfoClass contains disk, size, used space, available space, percent used, and mount_point
    :param path: Filesystem or filesystem of which path is a part
    :param host: Host where command is to be executed <default is None indicating local)
    :return: DiskInfoClass object

    Example:  disk_info = get_disk_info('/')
              free_space = disk_info.get_available()

    Note: Will raise exception via load_disk_information if error while attempting to load info.
    """

    disk_info = DiskInfoClass()
    disk_info.load_disk_information(path, host)
    return disk_info


def get_disk_size(path, host=None):
    """
    Convience method that gets the disk information and extracts out the disk size
    :param path: Filesystem or filesystem of which path is a part
    :param host: Host where command is to be executed <default is None indicating local)
    :return: disk size in bytes

    Note: Will raise exception via get_disk_info if error while attempting to load info.
    """
    disk_info = get_disk_info(path, host)
    return disk_info.get_size()

def get_disk_free_space(path, host=None):
    """
    Convience method that gets the disk information and extracts out the available space
    :param path: Filesystem or filesystem of which path is a part
    :param host: Destination host where command is to be executed <default is None indicating local)
    :return: available free space in bytes

    Note: Will raise exception via get_disk_info if error while attempting to load info.
    """
    disk_info = get_disk_info(path, host)
    return disk_info.get_available()


def verify_disk_free_space(path, required_free_space, host=None):
    """
    Verify that disk has enough required space
    :param path: Filesystem or filesystem of which path is a part
    :param required_free_space: required free space in bytes
    :param host: Host where the disk is located <default is None indicating local>
    :return: True if there is enough space on disk, False otherwise
    """
    logger = commonLogging.getLogger("execute")
    if host is None:
        host_msg = "local"
    else:
        host_msg = host

    logger.info('<JCS-INFO-00165> : Verifying that disk %s on host %s has sufficient free space', path, host_msg)
    if required_free_space < 0:
        logger.error('<JCS-WARN-20156> : Invalid value specified for required free space %s', str(required_free_space))
        return False
    elif required_free_space == 0:
        logger.warning('<JCS-WARN-10017> : Required free space as specified as 0')
        return True
    else:
        disk_free_space = get_disk_free_space(path, host)

        if disk_free_space < required_free_space:
            logger.warning('<JCS-WARN-10016> - Not enough disk space on %s on host %s (free space %s), given required space of %s',
                           path, host, str(disk_free_space), str(required_free_space))
            return False
        else:
            return True


def get_dir_size(path, host=None):
    """
    Returns the size of directory
    :param path: Directory path where the size is calculated
    :param host: destination host where command is to be executed
    :return:
    """
    logger = commonLogging.getLogger("execute")

    result = pythonUtils.execute_cmd("du -ks {0}".format(path), host)
    if result.get_return_code() == 0:
        output = result.get_output()
        size, path = output.split()
        # The -k options displays output in 1024 byte blocks vs 512
        return int(size) * 1024
    else:
        if host is None:
            host_msg = "local"
        else:
            host_msg = host
        pythonUtils.raiseException(None, logger, '<JCS-ERR-20153> - Unable to obtain directory size for %s on host %s. Return code: %s - error output: %s',
                                   path, host_msg, str(result.get_return_code()), result.get_err())


def verify_disk_space_for_dir(disk_path, dir_path, disk_host=None, dir_host=None):
    """
    Verify that disk has enough space for the specified directory
    :param disk_path: Disk path
    :param dir_path: Directory path
    :param disk_host: Host where the disk is located <default is None indicating local>
    :param dir_host: Host where directory is located <default is None indicating local>
    :return: True if there is enough space on disk for directory, otherwise False
    """
    logger = commonLogging.getLogger("execute")
    if disk_host is None:
        disk_host_msg = "local"
    else:
        disk_host_msg = disk_host

    if dir_host is None:
        dir_host_msg = "local"
    else:
        dir_host_msg = dir_host

    logger.info('<JCS-INFO-00166> : Verifying that disk %s on host %s has sufficient free space for directory %s on host %s',
                disk_path, disk_host_msg, dir_path, dir_host_msg)
    disk_free_space = get_disk_free_space(disk_path, disk_host)
    dir_size = get_dir_size(dir_path, dir_host)
    if disk_free_space < dir_size:
        logger.warning('<JCS-WARN-10016> - Not enough disk space on %s on host %s (free space %s), for dir %s on host %s of size %s ',
                       disk_path, disk_host, str(disk_free_space), dir_path, dir_host, str(dir_size))
        return False
    else:
        return True


def cleanup_dir(path, host=None):
    """
    Clean up the particular directory
    :param path: The path to the directory which need to be cleaned up
    :param host: Host where directory is located <default is None indicating local>
    """
    logger = commonLogging.getLogger("execute")

    if host is None:
        host_msg = "local"
    else:
        host_msg = host

    cmd = "rm -rf {0}; mkdir -p {0}".format(path)
    logger.info('<JCS-INFO-00167> : Deleting the content of the directory %s on host %s ', path, host_msg)
    result = pythonUtils.execute_cmd(cmd, host)

    if result.get_return_code() == 0:
        return True
    else:
        if host is None:
            host_msg = "local"
        else:
            host_msg = host


        logger.warning('<JCS-WARN-10019> : Unable to delete or create the directory %s on the host %s.\n Return code: %s - error output: %s',
                       path, host_msg, str(result.get_return_code()), result.get_err())
        return False


class DiskInfoClass(object):
    """
    Class which contains information about disk on the specified file system

    Members:
          filesystem: filesystem or filesystem of which file is a part
          size: size of disk in bytes
          used: amount of disk space that is used in bytes
          availabe: amount of unused disk space in bytes
          percent_used: percentage of disk space that is used
          mount_point: mount point for filesystem
    """

    def __init__(self):
        self.filesystem = None
        self.size = 0
        self.used = 0
        self.available = 0
        self.percent_used = 0
        self.mount_point = None

    def get_filesystem(self):
        """
        Get the filesystem or filesystem of which file is a part.
        """
        return self.filesystem

    def get_size(self):
        """
        Get the size of disk in bytes
        """
        return self.size

    def get_used(self):
        """
        Get the size of used space in bytes
        """
        return self.used

    def get_available(self):
        """
        Get the size of available space in bytes
        """
        return self.available

    def get_percent_used(self):
        """
        Get the percentage of used space
        """
        return self.percent_used

    def get_mount_point(self):
        """
        Get the disk mount point
        """
        return self.mount_point

    def load_disk_information(self, path, host=None):
        """
        load disk information using the df command
        :param path: path of disk
        :param host: host where disk resides
        :return:
        """
        logger = commonLogging.getLogger("DiskInfoClass")

        result = pythonUtils.execute_cmd("df -Pm {0}".format(path), host)
        if result.get_return_code() == 0:
            output = result.get_output()
            self.filesystem, size, used, available, percent, self.mount_point = output.split("\n")[1].split()
            self.size = int(size) * 1048576
            self.used = int(used) * 1048576
            self.available = int(available) * 1048576
            self.percent_used = int(percent.split('%', 1)[0])
        else:
            if host is None:
                host_msg = "local"
            else:
                host_msg = host
            pythonUtils.raiseException(None, logger, '<JCS-ERR-20152> - Unable to load disk information for %s on host %s. Return code: %s -  error output: %s',
                                       path, host_msg, str(result.get_return_code()), result.get_err())



    def to_json(self):
        """
        Convert the disk information into Json format
        """
        json = {}

        json['filesystem'] = self.filesystem
        json['size'] = str(self.size)
        json['used'] = str(self.used)
        json['available'] = str(self.available)
        json['percent_used'] = str(self.percent_used)
        json['mount_point'] = self.mount_point

        return json
