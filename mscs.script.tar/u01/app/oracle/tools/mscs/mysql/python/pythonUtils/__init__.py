#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
initialization script that handles import on pythonUtils.import
Note: Wlst does import pythonUtils, so have to have version check for functionality since wlst is extremely
      early version v2.2.1
"""

def is_jython():
    """
    Determine if running in python or jython
    return True if jython, False otherwise
    """
    import sys

    if sys.platform.startswith('java'):
        return True
    else:
        return False


def is_wlst():
    """
    If running in the WLST environment then supported version is currently
    2.2.1 and it is jython.
    """
    if sys.version_info < (2, 3) and is_jython():
        return True
    else:
        return False


# jython/wlst use java.lang.Exception whereas python uses exceptions.Exception
# if using common pythonUtils code then want Exception to be same object in jython/wlst space
# thus pythonUtils.Exception, will be the correct exception type.
# The main difference is the support of causes which has been added to pythonUtils in both env.
if is_jython():
    import java.lang.Exception as Exception

    from java.lang.management import *
else:
    from exceptions import *

from pythonUtils.constants import *
from pythonUtils.base import *
from pythonUtils.common_exception import *
from pythonUtils.pythonutil_exception import *

#There are some functionality in python that is not available to wlst
#This includes the subprocess package which is used exclusively by
#execute.
if not is_wlst():
    from pythonUtils.execute import *
    from pythonUtils.archive import *
    from pythonUtils.disk import *
