#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
Module used to write messing to the log file using the commonLogger
This is primary a wrapper used by shell script which have not yet been ported to python. The shell
script invokes this script with the python interpreter, providing the necessary logging information

"""
import sys
import pythonUtils.commonLogging as commonLogging

if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit("Usage: python shellLogging.py  message_type message <file_name> <logger_name> <file_name_concurrency> <display_status>")
    else:
        NUMBER_ARGS = len(sys.argv)
        if NUMBER_ARGS == 3:
            commonLogging.logMessage(message_type=sys.argv[1], message=sys.argv[2], file_name="None", logger_name=commonLogging.getLoggerName())
        elif NUMBER_ARGS == 4:
            commonLogging.logMessage(message_type=sys.argv[1], message=sys.argv[2], file_name=sys.argv[3], logger_name=commonLogging.getLoggerName())
        elif NUMBER_ARGS == 5:
            commonLogging.logMessage(message_type=sys.argv[1], message=sys.argv[2], file_name=sys.argv[3], logger_name=sys.argv[4])
        elif NUMBER_ARGS == 6:
            commonLogging.logMessage(message_type=sys.argv[1], message=sys.argv[2], file_name=sys.argv[3], logger_name=sys.argv[4], file_name_concurrency=sys.argv[5])
        else:
            commonLogging.logMessage(message_type=sys.argv[1], message=sys.argv[2], file_name=sys.argv[3], logger_name=sys.argv[4], file_name_concurrency=sys.argv[5], display_status=sys.argv[6])
