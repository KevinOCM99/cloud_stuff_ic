#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
Description: These are common methods for exception processing.
             Important to not note that have two Exception types. In the
             wlst space the exception is of type java.lang.Exception and
             in the python space it is exception.Exception. One difference is
             that the java.lang.Exception has causes or nested exceptions
"""
import traceback, sys
import pythonUtils.commonLogging as commonLogging
import pythonUtils
import re


def get_exc_causes(pattern=None, additional_msg=None):
    """
    Gets the causes form a java.lang.Exception or PythonutilException, example: used in jython/wlst

    Arguments:
        pattern: pattern to look for in the nested exception causes. This method gets the first exception cause
                 from the nested exceptions and any other exception(s) matching the specified pattern
        additional_msg: additional message to append to exception causes if pattern matched.

    Return:
        a string of exception causes each separated by new line.
    """
    ret_causes = None

    try:
        # Only java.lang.Exception (jython/wlst) or pythonUtils.PythonutilException have "causes"
        # normal python exception (exception.Exception) do not have causes
        # loop through exceptions and get all of the nested causes, that are available
        causes = []
        cur_exc = sys.exc_info()[1]
        index = 0
        pattern_matched = False

        while (cur_exc is not None) and (_is_pythonutil_exc(cur_exc) or (_is_jython_exc(cur_exc))):
            if pattern is None:
                causes.append(str(cur_exc))
            else:
                exception_cause = cur_exc.message
                if exception_cause is not None:
                    if index == 0:
                        if len(exception_cause.strip()) > 0:
                            causes.append(exception_cause)
                    else:
                        # only append those exception causes that match the specified pattern
                        match = re.search(pattern, exception_cause)
                        if match:
                            causes.append(exception_cause)
                            pattern_matched = True

            cur_exc = cur_exc.cause
            index += 1

        if pattern is not None and pattern_matched and additional_msg is not None:
            causes.append(additional_msg)

        if len(causes):
            ret_causes = "\n".join(causes)
    except:
        # don't fail
        ret_causes = None

    return ret_causes


def log_exc(error_code, logger, msg, *args):
    """
     Description: log an Exception error message
     Arguments:
        error_code - error code to be associated with exception
        logger - logger use to write message
        msg - The message to be written to the log and the value associated with the exception
        *args - [optional] - Arguments for the message
     Return:
        formatted message
     Example:
          log_exc(None, logger, '<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
    """
    # format and log the exception message
    if logger is None:
        logger = commonLogging.getLogger('exception')

    fmsg = format_exception_msg(msg, *args)

    if error_code is None:
        logger.error('Exception: %s', fmsg)
    else:
        logger.error('Exception: %s  with [error code %s]', fmsg, str(error_code))

    return fmsg


def process_exc(error_code=None, logger=None, msg=None, *args):
    """
    Description: Log message and exception information

    Arguments:
        error_code - error code to be associated with exception
        logger - logger use to write message
        msg - The message to be written to the log and the value associated with the exception
        *args - [optional] - Arguments for the message
     Return:
        formatted message
    """
    # first format and log the exception
    fmsg = log_exc(error_code, logger, msg, *args)

    # next print any causes that may exists
    exec_causes = get_exc_causes()
    if exec_causes is not None:
        logger.error('Exception causes: %s ', str(exec_causes))

    # now dump out the rest of the exception information
    if sys.exc_info()[1] is not None:
        try:
            if sys.version_info < (2, 4):
                traceback.print_exc()
            else:
                logger.error("Traceback exception = %s", traceback.format_exc())
        except:
            pass

    # finally if in wlst (jython) then call dump stack
    if pythonUtils.is_wlst():
        try:
            dumpStack()
        except:
            pass

    return fmsg


def raise_provided_exc(prov_exception, error_code, logger, msg, *args):
    """
         Description: log and raise a PythonutilException given an error message
             prov_exception - a new exception to raise. if None then raise PythonutilException
             error_code - error code to be associated with exception
             logger - logger use to write message
             msg - The message to be written to the log and the value associated with the PythonutilException
             *args - [optional] - Arguments for the message
         Example:
              raise_provided_exc(None, 10, logger, '<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
        """
    fmsg = log_exc(error_code, logger, msg, *args)

    #raise new exception
    if prov_exception is None:
        raise pythonUtils.PythonutilException(fmsg, None, error_code)
    else:
        raise prov_exception



def raise_exc(error_code, logger, msg, *args):
    """
     Description: log and raise a PythonutilException given an error message
         error_code - error code to be associated with exception
         logger - logger use to write message
         msg - The message to be written to the log and the value associated with the PythonutilException
         *args - [optional] - Arguments for the message
     Example:
          raise_exc(10, logger, '<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
    """
    raise_provided_exc(None, error_code, logger, msg, *args)


def process_exc_raise_provided_exc(prov_exception, error_code, logger, msg, *args):
    """
    Description: log message, process current exception, and raise a new Exception
    Attributes:
       prov_exception - a new exception to raise. if None then raise PythonutilException
       error_code - error code to be associated with exception (if no error code then specify None)
       logger - logger use to write message
       msg - The message to be written to the log and the value associated with the PythonutilException
       *args - [optional] - Arguments to the message
    Example:
        process_exc_raise_provided_exc(e,None,logger,'<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
    """
    #save current exception, as it becomes a cause for the new exception
    cur_exc = sys.exc_info()[1]
    fmsg = process_exc(error_code, logger, msg, *args)

    #raise new exception
    if prov_exception is None:
        raise pythonUtils.PythonutilException(fmsg, cur_exc, error_code)
    else:
        raise prov_exception


def process_exc_reraise(error_code, logger, msg, *args):
    """
    Description: log message, process current exception, and re-raise current exception
    Attributes:
        error_code - error code to be associated with exception (if no error code then specify None)
        logger - logger use to write message
        msg - The message to be written to the log and the value associated with the PythonutilException
        *args - [optional] - Arguments to the message
     Example:
          processExceptionReraise(10, logger, '<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
    """
    process_exc_raise_provided_exc(sys.exc_info()[1], error_code, logger, msg, *args)


def process_exc_raise_new(error_code, logger, msg, *args):
    """
    Description: log message, process current exception, and raise a new Exception
    Attributes:
        error_code - error code to be associated with exception (if no error code then specify None)
        logger - logger use to write message
        msg - The message to be written to the log and the value associated with the PythonutilException
        *args - [optional] - Arguments to the message
     Example:
          processExceptionRaisePythonutilException(10, logger, '<JCS-ERR-20100> : Server %s cannot be started on machine %s', serverName, machineName)
    """
    process_exc_raise_provided_exc(None, error_code, logger, msg, *args)



def format_exception_msg(msg, *args):
    """
    Description: internal method to format exception messages
    Arguments:
        msg - message string
        args - variable string of message arguments
    Returns:
        formatted message
    """
    if msg is None:
        return "<no message> "

    if len(args) > 0:
        try:
            fmsg = msg % args
        except:
            fmsg = msg
        return fmsg
    else:
        return msg


def _is_pythonutil_exc(exc):
    """
    Internal method to determine if specified exception is a PythonUtilsException
    :param exc: specified exception
    :return: True if specified exception is an instance of PythonutilException, False otherwise
    """
    try:
        results = isinstance(exc, pythonUtils.PythonutilException)
    except:
        results = False

    return results



def _is_jython_exc(exc):
    """
    Internal method to determine if specified exception is a Jython exception
    :param exc: specified exception
    :return: True if specified exception is an instance of java.lang.Exception, False otherwise
    """
    try:
        if pythonUtils.is_jython():
            import java.lang.Exception as jException
            results = isinstance(exc, jException)
        else:
            results = False
    except:
        results = False

    return results

