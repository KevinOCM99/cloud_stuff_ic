#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
import pythonUtils

class PythonutilException(pythonUtils.Exception):
    """
    Description:  Main exception class for pythonUtils. It is derived from java.lang.Exception
    in the jython/wlst space. If in the python space it is derived from exception.Exception.
    This is to ensure that working with same exception type. The main difference is the
    existance of "cause" which is supported in both environments.

    Has addition attribute of error_code which can be set with error code value, and retrieved when
    processing the exception
    """
    error_code = None
    cause = None

    def __init__(self, message, cause=None, error_code=None):
        """
        Description : Constructor
        Arguments:
            msg : [required] - message associated with this exception
            cause : [optional] - an exception associated with this exception
            error_code : [optional] - error code associated with this exception

        """
        pythonUtils.Exception.__init__(self, message)
        self.error_code = error_code
        self.cause = cause

    def get_error_code(self):
        """
        Description: Return the exception error code
        """
        return self.error_code

    def set_error_code(self, error_code):
        """
        Description: Set an error code for this exception
        """
        self.error_code = error_code


    def __str__(self):
        return "PythonutilException:" + repr(self.message)
