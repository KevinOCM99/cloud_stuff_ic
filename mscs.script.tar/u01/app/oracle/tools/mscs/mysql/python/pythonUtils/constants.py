#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
 Description: This files contains constants used in pythonUtils
"""
REMOTE_CMD_TIMEOUT = 1200
SSH_CONNECTION_TIMEOUT = 600

PYTHONUTILS_SETUP_SCRIPT = '/u01/app/oracle/tools/paas/bin/jcs/python/pythonUtils/setup.sh'
PYTHONUTILS_SETUP_SCRIPT_CMD = '. ' + PYTHONUTILS_SETUP_SCRIPT

SCP_EXEC_OPTIONS = '-o UserKnownHostsFile=/dev/null ' \
                   '-o StrictHostKeyChecking=no ' \
                   '-o LogLevel=error ' \
                   '-o BatchMode=yes ' \
                   '-o ConnectTimeout=%s -p' % SSH_CONNECTION_TIMEOUT

SSH_EXEC_OPTIONS = '-T -o UserKnownHostsFile=/dev/null ' \
                   '-o StrictHostKeyChecking=no ' \
                   '-o LogLevel=error ' \
                   '-o BatchMode=yes ' \
                   '-o ConnectTimeout=%s' % SSH_CONNECTION_TIMEOUT

WLST_PROPERTIES = '-Dweblogic.security.SSL.minimumProtocolVersion=TLSv1.2 ' \
                  '-Dweblogic.security.SSL.ignoreHostnameVerification=true ' \
                  '-Dweblogic.security.TrustKeyStore=DemoTrust ' \
                  '-Djava.security.egd=file:///dev/./urandom'

WLST_PROPERTIES_EXPORT_CMD = 'export WLST_PROPERTIES=\"' + WLST_PROPERTIES + '\"'
WLST_SHELL_SCRIPT = '$WL_HOME/common/bin/wlst.sh'

WLSTUTILS_SETUP_SCRIPT = '/u01/app/oracle/tools/paas/bin/jcs/python/wlstUtils/setup.sh'
WLSTUTILS_SETUP_SCRIPT_CMD = '. ' + WLSTUTILS_SETUP_SCRIPT

