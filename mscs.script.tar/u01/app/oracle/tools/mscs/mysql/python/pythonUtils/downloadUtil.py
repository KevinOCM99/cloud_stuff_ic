# Copyright (c) 2014,  Oracle and/or its affiliates. All rights reserved.
#!/usr/bin/env python
import sys
import time
import traceback
import os
import imp
import socket
import json
import commands
from datetime import datetime
import traceback
try:
    import pythonUtils.commonLogging as logging
except ImportError:
    exc_type, exc_value, tb_root = sys.exc_info()
    tracebackMsg = traceback.format_exc()
    # if importing failed common logging cannot be used
    print "<%s> <SEVERE> <weblogic.DownloadBinary> <Unable to import module: %s>" % (datetime.utcnow().strftime("%b %d, %Y %I:%M:%S %p UTC"), exc_value)
    print "<%s> <DEBUG> <weblogic.DownloadBinary> <\n%s>" % (datetime.utcnow().strftime("%b %d, %Y %I:%M:%S %p UTC"), tracebackMsg)
    print "**STATUS_LOG**", "Unable to load required Python module. Contact Oracle Support Services..."
    sys.exit(254)  # exit with status code 254 for importing error


###########################################
# Configure logger
logger_name = "weblogic.customaction.%s" % (os.path.basename(__file__)[:-3])
prefix = str(os.path.basename(__file__)[:-3])
# logging.setFileNamePrefix(prefix)
logging.setConsoleSeverity(logging.DEBUG)
logger = logging.getLogger(logger_name)
###########################################

class DownloadBinary:

        headgl = ""
        tailgl = ""
        destination_dir=""
        CLOUDKEY=""
        URL=""
        global DESTINATION_DIR
        target_dir = "/u01/app/oracle/tools/downloadBinaries/"
        def __init__(self):
                self.target_dir = "/u01/app/oracle/tools/downloadBinaries/"

#############################################
# downloadBinaries method
#############################################

        def downloadBinaries(self):
                logger.info("Start getting binaries")
                try:
                        if not self.validateArgs(URL,CLOUDKEY,self.target_dir):
                                logger.error("Validation failed for getting the binaries from cloud storage.Returning a status code of 1")
                                return 1
                        else:
                                logger.info("Validation completed successfully for getting the binaries.Start creating the target dir")
                                if self.createTargetDir():
                                        logger.info("head is " +headgl)
                                        logger.info("destination dir is " +destination_dir)
                                        try:
                                                cloudUrl = URL+"/"+CLOUDKEY
                                                logger.info("Cloud url used to download the binaries is "+cloudUrl)
                                                downloadStatus=self.downloadBinariesFromCloud(cloudUrl,destination_dir,tailgl)
                                                if downloadStatus:
                                                        logger.info("Downloaded the binaries successfully from the cloudURL "+cloudUrl+" under "+destination_dir)
                                                        return 0
                                                else:
                                                        logger.error("Error in downloading the binaries from the cloudURL "+cloudUrl)
                                                        return 1
                                        except Exception, e:
                                                logger.error("Error in  downloading the binaries from the cloudurl.Exception stack trace :"+traceback.format_exc())
                                                return 1
                except Exception, e:
                        logger.error("ERROR in getting the binaries. Exception stack trace "+traceback.format_exc())
                        return 1

#############################################
#Utilitiy mehod to creae target directory

#############################################

        def createTargetDir(self):
                #head,tail = os.path.split(CLOUDKEY)
                #global headgl
                #global tailgl
                #headgl=head
                #tailgl=tail
                global destination_dir
                if self.isNoneOrEmptyOrBlankString(headgl):
                        logger.info("Create  dir "+headgl+" under the target dir "+self.target_dir)
                        try:
                                destination_dir = self.target_dir+headgl
                                #print destination_dir
                                if not os.path.exists(destination_dir):
                                        os.makedirs(destination_dir)
                                        return True
                                else:
                                        logger.info("Destination directory "+destination_dir+ " already exists ")
                                        return True

                        except Exception,e:
                                logger.error("Error in creating the dir "+head+" under target dir "+self.target_dir)
                                return False

                else:
                        destination_dir = self.target_dir
                        logger.info("Dir to be created under targetDir "+self.target_dir+" + is either empty or null.Will use this dir to download the binaries")
                        return True

############################################
# Download Binaries from the downloadUtil.py
############################################
        def checkBinaries(self,PASSED_DIR):
                logger.info("Download Binaries from %s function called" %URL)
                try:
                        head,tail = os.path.split(CLOUDKEY)
                        logger.info("Cloud key is "+tail)
                        logger.info("Cloud path is "+head)
                        destination_file=self.target_dir+CLOUDKEY
                        dest_dir=self.target_dir+head
                        if not self.isNoneOrEmptyOrBlankString(PASSED_DIR):
                                passed_dir = ''
                        else:
                                passed_dir=PASSED_DIR+CLOUDKEY
                                if not os.path.isfile(passed_dir):
                                        logger.info("Destination file "+CLOUDKEY+" not exists under "+PASSED_DIR)
                                else:
                                        logger.info("Destination file "+CLOUDKEY+" exists under "+PASSED_DIR+".Remove the previously downloaded file")
                                        del_cmd = "rm -rf "+passed_dir
                                        del_st = os.system(del_cmd)
                                        if del_st !=0:
                                            logger.info("Previously downloaded file "+passed_dir+" not deleted")
                                        else:
                                            logger.info("Previously downloaded file "+passed_dir+"  deleted successfully")


                        logger.info("Download binaries into %s dir" %dest_dir)
                        logger.info("Remove the previously downloaded %s file if available"%destination_file)
                        del_cmd = "rm -rf "+destination_file
                        logger.info("Command to delete the previously downloaded "+destination_file+" file is "+del_cmd)
                        del_status = os.system(del_cmd)
                        if del_status !=0:
                            logger.info("Previously downloaded file "+destination_file+" not deleted ")


                        if not os.path.isfile(destination_file):
                                logger.info("Start downloading the binary "+CLOUDKEY+" from the cloud storage using downloadBinaries method")
                                downloadStatus=self.downloadBinaries()
                                if downloadStatus != 0:
                                    logger.error("Error in downloading the binaries using downloadBinaries method")
                                    return False
                                else:
                                    logger.info("Successfully downloaded the binaries using downloadBinaries() method")
                                    return True

                                try:
                                        logger.info("Check if the path "+dest_dir+" exists,else create it")
                                        if not os.path.exists(dest_dir):
                                                os.makedirs(dest_dir)
                                except Exception, e:
                                        logger.error("ERROR in creating %s dir "%dest_dir)
                                        return False

                                command = "cp -r "+file +" " +destination_file
                                logger.info("Command to copy the file is "+command)
                                stat = os.system(command)
                                if stat != 0:
                                        logger.error("Not able to copy the binaries from "+file+" to "+destination_file)
                                        return False
                                else:
                                        logger.info("Copied the binaries from "+file+" to " +destination_file)
                                        return True

                        else:
                                logger.info("Destination file "+CLOUDKEY+" already exists under "+self.target_dir+" Use it for the execution")
                                return True

                except Exception, e:
                        logger.error( "ERROR in downloading the binaries. Exception stack trace " +traceback.format_exc())
                        return False

 ############################################
 # Download binaries from the passed URL
 ############################################

        def downloadBinariesFromCloud(self,URL,DESTINATION_DIR,fileName):
                 logger.info("Download Python Scripts from %s function called" %URL)
                 logger.info("Download python scripts into %s dir" %DESTINATION_DIR)
                 #Check if the destination directory exists,Else create the dir
                 try:
                         if not os.path.exists(DESTINATION_DIR):
                                 os.makedirs(DESTINATION_DIR)
                 except Exception, e:
                         logger.error("ERROR in creating %s dir "%DESTINATION_DIR)
                         return False

                 command = "curl -X GET -v -m 600 --retry 7 --fail "+  '"'+(URL)+'"'+ " --output "+ (DESTINATION_DIR)+"/"+fileName
                 logger.info("Command %s "%command)
                 try:
                         curlretVal = os.system(command)
                         logger.info("Curl command status %s "%curlretVal)
                         if curlretVal != 0:
                                 logger.error("Curl command returned status other than 0. Failure in downloading the binaries")
                                 return False
                         else:
                                 logger.info("Curl command executed successfully.Completed downloading the binaries")
                                 return True
                 except Exception, e:
                         logger.error( "ERROR in downloading the binaries from %s url. Exception stack trace "%URL,  +traceback.format_exc())
                         return False
############################################
# Utility method to validate URL,CLOUDKEY
# and Destination directory
############################################

        def validateArgs(self,URL,CLOUDKEY,DESTINATION_DIR):
                 logger.info("Start validating storagecontainer,key and targetDir before getting binaries")
                 if not self.isNoneOrEmptyOrBlankString(URL):
                         logger.error("URL to download the binaries is either empty or null.Cannot get the binaries from cloud storage")
                         return False
                 if not self.isNoneOrEmptyOrBlankString(CLOUDKEY):
                         logger.error("key used to download the binaries is either empty or null.Cannot get the binaries from cloud storage")
                         return False
                 if not self.isNoneOrEmptyOrBlankString(DESTINATION_DIR):
                         logger.error("Target directory used to download the binaries is either empty or null.Cannot get the binaries from cloud storage")
                         return False


                 return True

#############################################
# Utility method check for empty or none
#############################################

        def isNoneOrEmptyOrBlankString(self,myString):
                 print myString
                 if myString:
                         if not myString.strip():
                                 return False
                         else:
                                 return True
                 else:
                         return False
                 return False

##############################################
# Utility method to get the Base URL
##############################################
        def getBaseURL(self):
                print "Inside getBaseURL"
                uri=""
                try:

                        command = 'curl -m 60 --retry 7 --fail http://192.0.0.192/latest/user-data/jaas_storage_uri'
                        uri = os.popen(command).read()
                        logger.info("Base URI is "+uri)
                        return uri
                except Exception,e:
                        logger.error("Error in getting the base url.Exception stack trace "+traceback.format_exc())
                        return ""


############################################
# Download Binaries from the downloadUtil.py
############################################


        def getBinaries(self,key,url,PASSED_DIR=''):
                logger.info("Download python scripts from "+key)
                print PASSED_DIR
                global CLOUDKEY
                global URL
                if not self.isNoneOrEmptyOrBlankString(url):
                    logger.error("URL to download the binaries is not specified from the user and is also not available in baseurl attribute.CustomAtions scripts cannot be downloaded and executed")
                    return ""
                else:
                    logger.info("Use the URL "+url+" specified from the caller to download the binaries ")
                CLOUDKEY=key
                URL=url
                try:
                        head,tail = os.path.split(CLOUDKEY)
                        global headgl
                        global tailgl
                        headgl=head
                        tailgl=tail
                        downloadStatus = self.checkBinaries(PASSED_DIR)
                        if downloadStatus:
                                logger.info("checkBinaries function executed successfully")
                                downloaded_dir = self.target_dir+CLOUDKEY
                                if not self.isNoneOrEmptyOrBlankString(PASSED_DIR):
                                        logger.info("Destination directory is not specified from the caller. Return the default dir "+self.target_dir+" where the binaries are downloaded")
                                        return downloaded_dir

                                else:
                                        logger.info("Destination directory is specified from the caller as "+PASSED_DIR+" Download the binaries to the destination directory")
                                        passed_dir=PASSED_DIR+CLOUDKEY
                                        if not os.path.isfile(passed_dir):
                                                logger.info("Destination file "+CLOUDKEY+" not exists under "+PASSED_DIR)
                                                if not os.path.exists(PASSED_DIR+headgl):
                                                        os.makedirs(PASSED_DIR+headgl)

                                                else:
                                                        logger.info("Destination directory "+PASSED_DIR+headgl+ " already exists ")

                                                cmd = "cp -r "+downloaded_dir +" " +passed_dir
                                                logger.info("Command to copy the downloaded binaries to the passed dir "+passed_dir+" is "+cmd)
                                                stat = os.system(cmd)
                                                if stat != 0:
                                                        logger.error("Not able to copy the binaries from "+downloaded_dir+" to "+passed_dir)
                                                        return ""
                                                else:
                                                        logger.info("Copied the binaries from "+downloaded_dir+" to " +passed_dir)
                                                        return passed_dir


                                        else:
                                                logger.info("Destination file "+CLOUDKEY+" exists under "+PASSED_DIR)
                                                return passed_dir
                        else:
                                logger.error("Download function not executed successfully.Return None or empty to the caller")
                                return ""


                except Exception,e:
                        logger.error("Exception in executing the downloadBinaries function. Exception stack trace "+traceback.format_exc())
