#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
Description: These are common methods for execute processing. These method make use of the
             subprocess package which was not available until python 2.4, which means that it
             is not available for use in wlst.  The import of this module in the pythonUtils
             __init__.py file has a conditional import to avoid error when importing pythonUtils in the wlst space
"""
import pythonUtils.commonLogging as commonLogging
import pythonUtils
import subprocess
import time
from datetime import datetime
import socket


def is_current_host(host):
    """
    Method to determine if supplied host is current host
    :param host: host name to determine if local
    :return: True if suplied host is local host, False otherwise
    """
    current_host = socket.gethostname()
    return current_host.find(host) >= 0


def execute_cmd(command,
                host=None,
                command_for_print=None,
                log_status_msgs=True,
                stdin=None,
                retry_count=0,
                retry_sleep_secs=10,
                success_return_codes=None,
                env=None):
    """
    Description:  This is a simple jacket method around the ExecuteCmdClass to execute shell command.
                  By default, we do not do retry unless retryTimes is specified
    Arguments:
       command : <required> - Command to be executed
       host : <optional> - host where to execute command. If remote then will SSH to execute
       command_for_print : <optional> - Command used when logging (should contain no passwords or sensitive information)
       log_status_msgs : <optional> - Boolean indicating whether you log status messages when executing command
       stdin : <optional> - STD-IN for interactive execution
       retry_count : <optional> - The number of attempted retries if command execution fails
       retry_sleep_secs : <optional> - The number of seconds should wait between retries
       success_return_codes : <optional> - The list of return codes that are considered successful- default is [0]
       env : <optional> - a map of environment variables

    Returns: A pythonUtils.ExecuteCmdClass object, which contains a pythonUtils.ExecuteCmdResultClass object
    """
    logger = commonLogging.getLogger("execute")

    #pylint
    if success_return_codes is None:
        success_return_codes = [0]

    if host is None or is_current_host(host):
        #execute local

        # get an ExecuteCmdClass object
        exec_cmd_obj = pythonUtils.ExecuteCmdClass(command=command,
                                                   command_for_print=command_for_print,
                                                   retry_count=retry_count,
                                                   retry_sleep_secs=retry_sleep_secs)

        # execute command
        return exec_cmd_obj.execute(logger, success_return_codes=success_return_codes, stdin=stdin, env=env, log_status_msgs=log_status_msgs)
    else:
        #execute remote
        return execute_ssh_cmd(host, command, command_for_print=command_for_print, log_status_msgs=log_status_msgs, stdin=stdin,
                               retry_count=retry_count, retry_sleep_secs=retry_sleep_secs,
                               success_return_codes=success_return_codes, env=env)


def execute_cmd_on_hosts(command,
                         host_list,
                         command_for_print=None,
                         log_status_msgs=True,
                         stdin=None,
                         retry_count=0,
                         retry_sleep_secs=10,
                         success_return_codes=None,
                         env=None):
    """
    Description:  This is a simple jacket method around the execute_cmd to support a list of hosts

    Arguments:
       command : <required> - Command to be executed
       host_list : <required> - List of hosts where to execute command. If remote then will SSH to execute
       command_for_print : <optional> - Command used when logging (should contain no passwords or sensitive information)
       log_status_msgs : <optional> - Boolean indicating whether you log status messages when executing command
       stdin : <optional> - STD-IN for interactive execution
       retry_count : <optional> - The number of attempted retries if command execution fails
       retry_sleep_secs : <optional> - The number of seconds should wait between retries
       success_return_codes : <optional> - The list of return codes that are considered successful- default is [0]
       env : <optional> - a map of environment variables

    Returns: A list of pythonUtils.ExecuteCmdClass object, which contains a pythonUtils.ExecuteCmdResultClass object
    """

    resultslist = []

    for host in host_list:
        result = execute_cmd(command=command,
                             host=host,
                             command_for_print=command_for_print,
                             log_status_msgs=log_status_msgs,
                             stdin=stdin,
                             retry_count=retry_count,
                             retry_sleep_secs=retry_sleep_secs,
                             success_return_codes=success_return_codes,
                             env=env)

        resultslist.append(result)

        return resultslist


def execute_ssh_cmd(host, command, command_for_print=None, log_status_msgs=True, stdin=None, retry_count=3, retry_sleep_secs=10, success_return_codes=None, env=None):
    """
    Description:  Jacket routine around execute command for  SSH commands. By default, we do not do retry unless retryTimes is specified
    Arguments:
        host : <required> - Target host
        command : <required> - Command to be executed
        command_for_print : <optional> - Command used when logging (should contain no passwords or sensitive information)
        log_status_msgs : <optional> - Boolean indicating whether you log status messages when executing command
        stdin : <optional> - STD-IN for interactive execution
        retry_count : <optional> - The number of attempted retries if command execution fails
        retry_sleep_secs : <optional> - The number of seconds should wait between retries
        success_return_codes : <optional> - The list of return codes that are considered successful - default is [0]
        env : <optional> - a map of environment variables

        Returns: A pythonUtils.ExecuteCmdClass object, which contains a pythonUtils.ExecuteCmdResultClass object
    """
    logger = commonLogging.getLogger("execute")

    #pylint
    if success_return_codes is None:
        success_return_codes = [0]

    ssh_commnad = "ssh %s %s \"%s\"" % (host, pythonUtils.SSH_EXEC_OPTIONS, command)

    # get an ExecuteCmdClass object
    exec_cmd_obj = pythonUtils.ExecuteCmdClass(ssh_commnad,
                                               command_for_print=command_for_print,
                                               retry_count=retry_count,
                                               retry_sleep_secs=retry_sleep_secs)

    # execute command
    results = exec_cmd_obj.execute(logger, success_return_codes=success_return_codes, stdin=stdin, env=env, log_status_msgs=log_status_msgs)


    if exec_cmd_obj.get_result().get_return_code() == 255:
        logger.error('<JCS-ERR-20151> : Host %s is unreachable', host)

    # The exec_cmd_object contains the results
    return results


def execute_scp_cmd(source_path,
                    target_path,
                    source_host=None,
                    target_host=None,
                    retry_count=3,
                    retry_sleep_secs=10,
                    env=None):
    """
    Description:  Jacket routine around exec command to execute SCP command. By default, we do not do retry unless retryTimes is specified
    Arguments:
        source_path : <required> - path of source
        target_path : <required> - path of target
        source_host : <optional> - Host for source
        target_host : <optional> - Host for  target
        retry_count : <optional> - The number of attempted retries if command execution fails
        retry_sleep_secs : <optional> - The number of seconds should wait between retries
        success_return_codes : <optional> - The list of return codes that are considered successful
        env : <optional> - a map of environment variables

        Returns: A pythonUtils.ExecuteCmdClass object, which contains a pythonUtils.ExecuteCmdResultClass object
    """
    logger = commonLogging.getLogger("execute")

    if source_host is None and target_host is None:
        # local copy
        command = "cp %s %s" % (source_path, target_path)
    elif source_host is None:
        #local source to remote target
        command = "scp %s %s %s:%s" % (pythonUtils.SCP_EXEC_OPTIONS, source_path, target_host, target_path)
    elif target_host is None:
        #remote source to local target
        command = "scp %s %s:%s %s" % (pythonUtils.SCP_EXEC_OPTIONS, source_host, source_path, target_path)
    else:
        #remote source to remote target
        command = "scp %s %s:%s %s:%s" % (pythonUtils.SCP_EXEC_OPTIONS, source_host, source_path, target_host, target_path)

    # get ExecuteCmdClass object
    exec_cmd_obj = pythonUtils.ExecuteCmdClass(command,
                                               command_for_print=command,
                                               retry_count=retry_count,
                                               retry_sleep_secs=retry_sleep_secs)

    # execute command
    exec_cmd_obj.execute(logger, env=env)

    # The exec_cmd_object contains the results
    return exec_cmd_obj


def execute_wlst_cmd(command,
                     init_command=None,
                     wlst_prop_command=pythonUtils.WLST_PROPERTIES_EXPORT_CMD,
                     pythonutils_env_script=pythonUtils.PYTHONUTILS_SETUP_SCRIPT_CMD,
                     domain_dir=None,
                     command_for_print=None,
                     log_status_msgs=True,
                     stdin=None,
                     retry_count=0,
                     retry_sleep_secs=10,
                     success_return_codes=None,
                     env=None):
    """
    Description:  This is a convience method that provides a jacket around the ExecuteWlstCmdClass, which is
                  used to execute a wlst command from python. By default, we do not do retry unless retryTimes is specified

    Arguments:
      command : <required> - WLST command to be executed
      init_command : <optional> - String containing any commands that need to be executued before wlst command
      wlst_prop_command : <optional> - Command to define WLST_PROPERITES
      pythonutils_env_script : <optional> - Command to setup the pythonUtils env
      domain_dir : <optional> - location of domain directory, used to run the {1}/bin/setDomainEnv.sh script
      command_for_print : <optional> - Command used when logging (should contain no passwords or sensitive information)
      log_status_msgs : <optional> - Boolean indicating whether you log status messages when executing command
      stdin : <optional> - STD-IN for interactive execution
      retry_count : <optional> - The number of attempted retries if command execution fails
      retry_sleep_secs : <optional> - The number of seconds should wait between retries
      success_return_codes : <optional> - The list of return codes that are considered successful. Default is [0]
      env : <optional> - a map of environment variables

    Returns: A pythonUtils.ExecuteCmdClass object, which contains a pythonUtils.ExecuteCmdResultClass object

    """

    logger = commonLogging.getLogger("execute")

    #pylint
    if success_return_codes is None:
        success_return_codes = [0]

    # get an ExecuteCmdClass object
    exec_cmd_obj = pythonUtils.ExecuteWlstCmdClass(command,
                                                   init_command=init_command,
                                                   wlst_prop_command=wlst_prop_command,
                                                   pythonutils_env_script=pythonutils_env_script,
                                                   domain_dir=domain_dir,
                                                   command_for_print=command_for_print,
                                                   retry_count=retry_count,
                                                   retry_sleep_secs=retry_sleep_secs)

    # execute command
    return exec_cmd_obj.execute(logger, success_return_codes=success_return_codes, stdin=stdin, env=env, log_status_msgs=log_status_msgs)


class ExecuteCmdResultClass(object):
    """
    Class which contains the results from an execute command
    """

    def __init__(self, success_return_codes=None):

        # expected success return codes
        if success_return_codes:
            self.success_return_codes = success_return_codes
        else:
            #pylint - set default here
            self.success_return_codes = [0]

        # initialize
        self.start_time = 0
        self.end_time = 0
        self.return_code = None
        self.output = None
        self.err = None
        self.detail = None

    def set_return_code(self, return_code):
        """
        Set the return code
        """
        if self.start_time == 0:
            return "Did not run"
        else:
            self.return_code = return_code

    def get_return_code(self):
        """
        Get the return code associated with results
        """
        return self.return_code

    def set_output(self, output):
        """
        Set the output from the executed command
        """
        self.output = output

    def get_output(self):
        """
        Get the output from the executed command
        """
        return self.output

    def set_err(self, err):
        """
        Set the standard error output from the executed command
        """
        self.err = err

    def get_err(self):
        """
        Get the standard error output form the executed command
        """
        return self.err

    def get_detail(self):
        """
        Get the details of run which include out and err
        """
        return (self.output + self.err).strip()

    def set_start_time(self, start_time):
        """
        Set the time when starting the execute command
        """
        self.start_time = start_time

    def get_start_time(self):
        """
        Get the time when execute command was started
        """
        return self.start_time

    def set_end_time(self, end_time):
        """
        Set the time when the execute command completed
        """
        self.end_time = end_time

    def get_end_time(self):
        """
        Get the time when execute command was completed
        """
        return self.end_time

    def get_duration(self):
        """
        Get the duration time of the execution of the command
        """
        duration = self.end_time - self.start_time
        duration = duration.seconds * 1000 + duration.microseconds / 1000.0
        return duration

    def if_successful(self):
        """
        Return True if the return code of the exeucted command is in the list of success_return_codes
        """
        return self.return_code in self.success_return_codes

    def log_results(self, command, logger=None,):
        """
        Log results of the executed command
        """
        if logger is None:
            logger = commonLogging.getLogger("ExecuteCmdResultClass")

        logger.info('<JCS-INFO-00162> : Executed command with status %s in %s milliseconds [ %s ] ', str(self.get_return_code()), str(self.get_duration()), command)


    def to_json(self):
        """
        Convert the results into Json format
        """
        json = {}

        if self.start_time == 0:
            json['return_code'] = "No Results"
        else:
            if self.end_time == 0:
                #still running
                json['return_code'] = "Started but not completed"
            else:
                json['output'] = self.output
                json['error'] = self.err
                json['detail'] = self.get_detail()
                json['return_code'] = self.return_code
                json['start_time'] = str(self.start_time)
                json['end_time'] = str(self.end_time)
                json['duration'] = str(self.get_duration())
                json['success_return_codes'] = str(self.success_return_codes)
        return json


class ExecuteCmdClass(object):
    """
    Class for executing shell command
    """

    def __init__(self, command, command_for_print=None, retry_count=0, retry_sleep_secs=10):
        self.command = command
        self.result = None

        if command_for_print:
            self.command_for_print = command_for_print
        else:
            self.command_for_print = command

        self.retry_count = retry_count
        self.retry_sleep_secs = retry_sleep_secs


    def get_result(self):
        """
        Get results from execute command
        :return: result of type ExecuteCmdResultClass
        """
        return self.result

    def set_command(self, command, command_for_print=None):
        """
        Set the comand to execute

        :param command: Command to execute
        :param command_for_print: The command to display, should not contain sensitive
                                  information such as passwords.
        """
        self.command = command
        if command_for_print:
            self.command_for_print = command_for_print
        else:
            self.command_for_print = command

    def get_command(self):
        """
        Get the execute command
        """
        return self.command

    def get_command_for_print(self):
        """
        Get the command that is to be displayed
        (Should not contain any sensitive information such as passwords
        """
        return self.command_for_print

    def set_retry_count(self, retry_count):
        """
        Set the number of retry attempts to be made if executeCommand fails
        :param retry_count: number of times to retry in case of failure
        """
        self.retry_count = retry_count

    def set_retry_sleep_secs(self, retry_sleep_secs):
        """
        Sets the number of seconds to sleep between retries
        :param retry_sleep_secs: Seconds to sleep
        """
        self.retry_sleep_secs = retry_sleep_secs


    def execute(self, logger=None, success_return_codes=None, stdin=None, env=None, log_status_msgs=True):
        """
        Execute supplied command

        :param logger: logger to use for logging message
        :param success_return_codes: list of possible successful return codes
        :param stdin: stdin for command
        :param env: environment variables to be set for command
        :param log_status_msgs: boolean indicating whether status messages should be logged
        :return: result of type ExecuteCmdResultClass
        """
        if logger is None:
            logger = commonLogging.getLogger("execute")

        #pylint
        if success_return_codes is None:
            success_return_codes = [0]

        try:
            self.result = ExecuteCmdResultClass(success_return_codes)
            self.result.set_start_time(datetime.now())

            retry = int(self.retry_count)
            counter = 0

            try:
                while counter <= retry:
                    if log_status_msgs:
                        logger.info('<JCS-INFO-00161> : executing command %s', self.command_for_print)

                    process = subprocess.Popen(self.command, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
                    out, err = process.communicate(stdin)
                    self.result.set_output(out)
                    self.result.set_err(err)
                    self.result.set_return_code(process.returncode)

                    if self.result.if_successful():
                        break

                    logger.warning('%s %s', self.result.get_output(), self.result.get_err())

                    # not successful and out of retries
                    if counter == retry:
                        logger.error('<JCS-ERR-20149> : Execution of command failed with status %s', str(self.result.get_return_code()))
                        logger.error('<JCS-ERR-20150> : Exceeded retry count without success')
                        break

                    logger.warning('<JCS-WARN-10015> : Execution of command failed with status %s, will retry in %s seconds', str(self.result.get_return_code()), str(self.retry_sleep_secs))
                    time.sleep(self.retry_sleep_secs)
                    counter = counter+1

            except pythonUtils.PythonutilException:
                pythonUtils.process_exc_raise_new(self.result.return_code, logger, '<JCS-ERR-20149> : Execution of command failed with status %s', str(self.result.get_return_code()))

        finally:
            self.result.set_end_time(datetime.now())
            if log_status_msgs:
                self.result.log_results(self.command_for_print, logger)

            # Close pipe after execution
            process.stdout.close()
            process.stdin.close()


        return self.result


    def to_json(self):
        """
        Convert the ExecuteCmdClass object into Json format
        """
        json = {}

        json['command'] = self.command_for_print
        json['retry_count'] = self.retry_count
        json['retry_sleep_secs'] = self.retry_sleep_secs
        if self.result is None:
            json['result'] = None
        else:
            json['result'] = self.result.to_json()

        return json


class ExecuteWlstCmdClass(ExecuteCmdClass):
    """
    Class for executing wlst command
    """
    def __init__(self, command,
                 init_command=None,
                 wlst_prop_command=pythonUtils.WLST_PROPERTIES_EXPORT_CMD,
                 pythonutils_env_script=pythonUtils.PYTHONUTILS_SETUP_SCRIPT_CMD,
                 domain_dir=None,
                 command_for_print=None,
                 retry_count=0,
                 retry_sleep_secs=10, ):

        if command_for_print is None:
            display_command = command
        else:
            display_command = command_for_print

        pre_cmd = ''

        if init_command is not None:
            pre_cmd = pre_cmd + init_command + ';'

        if wlst_prop_command is not None:
            pre_cmd = pre_cmd + wlst_prop_command + ';'

        if pythonutils_env_script is not None:
            pre_cmd = pre_cmd + pythonutils_env_script + ';'

        if domain_dir is not None:
            domain_script = ". {1}/bin/setDomainEnv.sh;".format(domain_dir)
            pre_cmd = pre_cmd + domain_script

        if pre_cmd is not None:
            new_cmd = pre_cmd + pythonUtils.WLST_SHELL_SCRIPT + " " + command
            new_cmd_print = pre_cmd + pythonUtils.WLST_SHELL_SCRIPT + " " + display_command
        else:
            new_cmd = pythonUtils.WLST_SHELL_SCRIPT + " " + command
            new_cmd_print = pythonUtils.WLST_SHELL_SCRIPT + " " + display_command


        #now have built all the command can use base class
        ExecuteCmdClass.__init__(self, new_cmd, new_cmd_print, retry_count, retry_sleep_secs, )
