#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
 Description: This files contains common base methods for python library
"""

import pythonUtils
import sys
import os


def strToBool(in_str):
    """
    Helper function to convert string to boolean

    :param in_str: string to convert to Boolean
    :return: True if string is "true" or "t", False otherwise
    """
    return in_str.lower() in ("true", "t")


def getPid():
    """
    Get the pid for a process.  Doesn't work for all platforms (jython - wlst)
    so need to utilize runtime mbean
    :return: process pid
    """
    if pythonUtils.is_jython():
        jvm_name = ManagementFactory.getRuntimeMXBean().getName()
        pid = jvm_name.split('@', 1)[0]
    else:
        pid = os.getpid()

    return str(pid)


def validateSysArg(ReqArgCount, printDocText=False):
    """
    Description: Validate sys.arg has the expected number of arguments
    Arguments:
        ReqArgCount: The number of required arguments
        printDocText:  Boolean indicating whether to print the __doc__ text <default is False>
    Return:
        Boolean indicating if the required number of arguments was provided
    """
    logger = pythonUtils.commonLogging.getLogger('pythonutils_base')

    if  len(sys.argv) < ReqArgCount:
        logger.error('<JCS-ERR-20048> : Invalid number of arguments specified')
        if printDocText:
            print  __doc__
        return False
    else:
        return True
