#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
This is the python specific logging module. It is used by
commonLogging.py to support the python logging option.
It should not be imported on its own. commonLogging.py should
be imported and based on the python/jython version it will perform
a conditional import of the desired logging package.
"""

import os, sys
import logging.config
import pythonUtils.clogging.constants as lconstants
import pythonUtils.clogging.common_logger as common_logger

# These are the local variables used to keep track of the
# configurations settings.
# They are set with default values in commongLogging.py (not here)
cps_filename = None
cps_loggername = None
cps_maxbytes = None
cps_backupcount = None
cps_fh_level = None
cps_ch_level = None

# configuration settings, that are not currently configurable
cps_formatter_string = "<%(asctime)s> <%(levelname)s> <%(name)s> <%(message)s>"
cps_formatter_date = "%b %d, %Y %I:%M:%S %p %Z"
cps_encoding = "utf8"

# Used to map cps logging levels to python logging
LEVELS = {lconstants.DEBUG : logging.DEBUG,
          lconstants.INFO : logging.INFO,
          lconstants.WARNING : logging.WARNING,
          lconstants.ERROR : logging.ERROR,
          lconstants.CRITICAL : logging.CRITICAL}


def getLogger(loggername=cps_loggername):
    """
    Get a logger given a logger name. If the logger doesn't
    exist a new one will be created, otherwise will return
    existing logger.
    :param loggername: name of the logger
    :return: either a new or existing logger
    """
    cps_logger = PythonCustomLogger(loggername)
    if not cps_logger.handlers:
        #There may not be a file handler. Many of the scripts that are run
        #have their output piped to stdout, thus a console logger may be good enough
        if cps_filename is not None:
            cps_fh = logging.handlers.RotatingFileHandler(cps_filename,
                                                          maxBytes=cps_maxbytes,
                                                          backupCount=cps_backupcount,
                                                          encoding=cps_encoding)
            # file handler
            cps_fh.setFormatter(logging.Formatter(cps_formatter_string, cps_formatter_date))
            cps_fh.setLevel(LEVELS.get(cps_fh_level))
            cps_logger.addHandler(cps_fh)

        # console handler
        cps_formatter = logging.Formatter(cps_formatter_string, cps_formatter_date)
        cps_ch = logging.StreamHandler(sys.stdout)
        cps_ch.setFormatter(cps_formatter)
        cps_ch.setLevel(LEVELS.get(cps_ch_level))
        cps_logger.addHandler(cps_ch)
        #set the logger to the highest level and control at the handler level
        cps_logger.setLevel(logging.DEBUG)

    return cps_logger

def getFileName():
    if cps_filename is not None:
        return os.path.abspath(cps_filename)
    else:
        return cps_filename

def setFileName(filename):
    global cps_filename
    cps_filename = filename

def getLoggerName():
    """
    Returns the value of current default logger name. This is the
    default logger name used when creating a new logger.
    Note: Useful in the shell script logging script
    :return: default name of logger
    """
    return cps_loggername

def setLoggerName(loggername):
    """
    Sets the default logger name value, which is used when creating a new logger
    :param loggername: Default name use to create a new logger
    """
    global cps_loggername
    cps_loggername = loggername

def getLogFileSeverity():
    return cps_fh_level

# support dynamic setting of level
# change in variable as well as current file handler
def setLogFileSeverity(level):
    global cps_fh_level
    #global cps_fh
    cps_fh_level = level
    #if cps_fh is not None:
    #    cps_fh.setLevel(LEVELS.get(cps_fh_level))

def getFileCount():
    return str(cps_backupcount)

def setFileCount(count):
    global cps_backupcount
    cps_backupcount = count

def getFileSize():
    return str(cps_maxbytes / 1024)

def setFileSize(size):
    global cps_maxbytes
    cps_maxbytes = size * 1024

def getConsoleSeverity():
    return str(cps_ch_level)

# support dynamic setting of level
# change in variable as well as current console handler
def setConsoleSeverity(level):
    global cps_ch_level
    #global cps_ch
    cps_ch_level = level
    #if cps_ch is not None:
    #    cps_ch.setLevel(LEVELS.get(cps_ch_level))

# There is a version of this in the wlst_logging.py file, which is derived from
# a wls logger. Changes here should be coordinated there.
class PythonCustomLogger(logging.Logger):

    def __init__(self, name):
        logging.Logger.__init__(self, name)
        self.cur_msgs = {}

    def getLoggerName(self):
        return self.name

    def debug(self, msg, *args):
        logging.Logger.debug(self, self.formatMsg(msg, *args))

    def info(self, msg, *args):
        logging.Logger.info(self, self.formatMsg(msg, *args))

    def warning(self, msg, *args):
        logging.Logger.warning(self, self.formatMsg(msg, *args))

    def error(self, msg, *args):
        logging.Logger.error(self, self.formatMsg(msg, *args))

    def critical(self, msg, *args):
        logging.Logger.critical(self, self.formatMsg(msg, *args))

    def formatMsg(self, msg, *args):
        return common_logger.formatMsg(self.cur_msgs, msg, *args)

    def getMessage(self, message_id):
        return common_logger.getMessage(self.cur_msgs, message_id)

    def addMessages(self, msgPath):
        common_logger.addMessages(self.cur_msgs, msgPath)

