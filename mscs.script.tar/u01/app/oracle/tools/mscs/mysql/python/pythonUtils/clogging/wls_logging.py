#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
This is the WLS specific logging module. It is used by
commonLogging.py to support the WLS logging option.
It should not be imported on its own. commonLogging.py should
be imported and based on the python/jython version it will perform
a conditional import of the desired logging package.
"""

import os
import java
from weblogic.i18n.logging import NonCatalogLogger
import pythonUtils.clogging.constants as lconstants
import pythonUtils.clogging.common_logger as common_logger

# The logger used in WLST (2.2.1) when python logging (2.3) is not available
# is NonCatalogLogger
#      http://docs.oracle.com/cd/E15051_01/wls/docs103/javadocs/weblogic/logging/NonCatalogLogger.html
#      "This class is also intended for use by client code not running within a Weblogic Server. The
#      logging properties of clients are configured with Java system properites: weblogic.log.<attributeInLogMBean>
#
# Following properties need to be set but are not currently configurable.
# Currently only support rotation type based on size (not configurable so set).
java.lang.System.setProperty('weblogic.log.RotationType', "bySize")
java.lang.System.setProperty('weblogic.log.NumberOfFilesLimited',"true")
#
# Following properties are used. Default values are set via commonLogging initialization
#weblogic.log.FileCount
#weblogic.log.FileMinSize
#weblogic.log.FileName
#weblogic.log.LogFileSeverity
#weblogic.log.StdoutSeverity
#
# logging properties not currently supported
#weblogic.log.StdoutLogStack
#weblogic.log.LogFileRotationDir
#weblogic.log.FileTimeSpan
#weblogic.log.BufferSizeKB
#weblogic.log.RotateLogOnStartup
#weblogic.log.RotationTime


# WLS logging has case sensitive setting that differ from
# python logging. Use table for lookup/conversion
LEVELS = {lconstants.DEBUG : 'Debug',
          lconstants.INFO : 'Info',
          lconstants.WARNING : 'Warning',
          lconstants.ERROR : 'Error',
          lconstants.CRITICAL : 'Critical'}


# logger name is not WLS attribute set via system property
wls_loggername = lconstants.DEFAULT_LOGGER_NAME


def getLogger(loggername=wls_loggername):
    """
    Create new wls logger
    :param loggername: name of the logger
    :return: newly created logger
    """
    return WlsCustomLogger(loggername)


def getFileName():
    """
    Returns the name of the wls log file. WLS logging relies on
    system properties for configuration
    :return: log file name
    """
    fn = java.lang.System.getProperty("weblogic.log.FileName")
    if fn is not None:
        return os.path.abspath(fn)
    else:
        return fn

def setFileName(filename):
    """
    Sets the name of the wls log. WLS logging relies on system
    properties for configuration
    :param filename: name of log file
    :return:
    """
    if filename is not None:
        java.lang.System.setProperty("weblogic.log.FileName",filename)

def getLoggerName():
    """
    Returns the value of current default logger name. This is the
    default logger name used when creating a new logger.
    Note: Useful in the shell script logging script
    :return: default name of logger
    """
    return wls_loggername

def setLoggerName(loggername):
    """
    Sets the default logger name value, which is used when creating a new logger
    :param loggername: Default name use to create a new logger
    """
    global wls_loggername
    wls_loggername = loggername

def getLogFileSeverity():
    return str(java.lang.System.getProperty("weblogic.log.LogFileSeverity"))

def setLogFileSeverity(level):
    java.lang.System.setProperty("weblogic.log.LogFileSeverity",LEVELS.get(level.upper()))

def getFileCount():
    return str(java.lang.System.getProperty("weblogic.log.FileCount"))

def setFileCount(count):
    java.lang.System.setProperty("weblogic.log.FileCount",str(count))

def getFileSize():
    return str(java.lang.System.getProperty("weblogic.log.FileMinSize"))

def setFileSize(size):
    java.lang.System.setProperty("weblogic.log.FileMinSize",str(size))

def getConsoleSeverity():
    return str(java.lang.System.getProperty("weblogic.log.StdoutSeverity"))

def setConsoleSeverity(level):
    java.lang.System.setProperty("weblogic.log.StdoutSeverity",LEVELS.get(level.upper()))


class WlsCustomLogger(NonCatalogLogger):
    lname=None

    def __init__(self, name):
        NonCatalogLogger.__init__(self, name)
        self.lname = name
        self.cur_msgs = {}

    def getLoggerName(self):
        return self.lname

    def debug(self, msg, *args):
        NonCatalogLogger.debug(self, self.formatMsg(msg, *args))

    def info(self, msg, *args):
        NonCatalogLogger.info(self, self.formatMsg(msg, *args))

    def warning(self, msg, *args):
        NonCatalogLogger.warning(self, self.formatMsg(msg, *args))

    def error(self, msg, *args):
        NonCatalogLogger.error(self, self.formatMsg(msg, *args))

    def critical(self, msg, *args):
        NonCatalogLogger.critical(self, self.formatMsg(msg, *args))

    def formatMsg(self, msg, *args):
        return common_logger.formatMsg(self.cur_msgs, msg, *args)

    def getMessage(self, message_id):
        return common_logger.getMessage(self.cur_msgs, message_id)

    def addMessages(self, msgPath):
        common_logger.addMessages(self.cur_msgs, msgPath)
