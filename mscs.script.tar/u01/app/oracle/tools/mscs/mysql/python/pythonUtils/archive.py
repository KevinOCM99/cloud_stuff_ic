#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
"""
Description: Common methods for archive commands
"""
import pythonUtils.commonLogging as commonLogging
import pythonUtils
import os
import traceback
import zipfile
import shutil


def create_zip(zip_file_path, src_path, remove_source=False):
    """
    Create a zip file of the src directory

    :param zip_file_path: Name of the destination zip file
    :param src_path: Source directory to be zipped
    :param remove_source: <optional> - Boolean indicating if the src directory should
           be removed after zip is created (default is False)

    :return:
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    if not src_path:
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", src_path)
        return None

    name, ext = os.path.splitext(zip_file_path)
    if ext == ".zip":
        zip_file = zip_file_path
    else:
        zip_file = "%s.zip" % (zip_file_path)

    logger.info("Starting to zip %s to %s", src_path, zip_file)
    cmd = "zip -r %s '%s'" % (zip_file, src_path)
    cmd_result = pythonUtils.execute_cmd(cmd)

    return_code = cmd_result.get_return_code()
    if return_code == 0:
        # return the actual file name
        logger.info('Successfully zipped %s to %s', src_path, zip_file)
        if remove_source:
            shutil.rmtree(src_path)
    else:
        pythonUtils.process_exc_raise_new(return_code, logger, "Failed trying to zip %s to %s", src_path, zip_file)


def create_zip_native(zip_file_path, src_path, remove_source=False, log_files=True):
    """
    Create a zip file of the src directory

    :param zip_file_path: Name of the destination zip file
    :param src_path: Source directory to be zipped
    :param remove_source: <optional> - Boolean indicating if the src directory should
           be removed after zip is created (default is False)
    :param log_files: Log the individual files that are added to the zip file

    :return:
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    if not src_path:
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", src_path)
        return None

    parent_folder = os.path.dirname(src_path)
    contents = os.walk(src_path)

    name, ext = os.path.splitext(zip_file_path)
    if ext == ".zip":
        zip_file = zip_file_path
    else:
        zip_file = "%s.zip" % (zip_file_path)

    try:
        logger.info("Starting to zip %s to %s", src_path, zip_file)
        zip_archive = zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED)
        for root, folders, files in contents:
            # Zip directories including empty sub-dirs
            for folder_name in folders:
                absolute_path = os.path.join(root, folder_name)
                relative_path = absolute_path.replace(parent_folder + '\\', '')
                if log_files:
                    logger.info('zipping %s', relative_path)
                zip_archive.write(absolute_path, relative_path)
            # Zip files
            for file_name in files:
                absolute_path = os.path.join(root, file_name)
                relative_path = absolute_path.replace(parent_folder + '\\', '')
                if log_files:
                    logger.info('zipping %s', relative_path)
                zip_archive.write(absolute_path, relative_path)

        logger.info('Successfully zipped %s to %s', src_path, zip_file)

        if remove_source:
            shutil.rmtree(src_path)
    except:
        pythonUtils.process_exc_raise_new(None, logger, "Failed trying to zip %s to %s", src_path, zip_file)


def zip_archive_contains(zip_archive_path, filename):
    """
    Check if zip archive contains a specific file

    :param zip_archive_path: Path to the zip archive
    :param filename: file name to check archive for, can be partial or full

    :return: The file or file(s) that were found, None if not found

    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    if not zip_archive_path:
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", zip_archive_path)
        return None

    cmd = "zipinfo -1 %s | grep '%s'" % (zip_archive_path, filename)
    cmd_result = pythonUtils.execute_cmd(cmd)

    if cmd_result.get_return_code() == 0:
        # return the actual file name
        return cmd_result.get_output().strip()
    else:
        logger.warning("<JCS-WARN-10020> : Archive %s does not contain %s", zip_archive_path, filename)
        return None


def zip_archive_contains_native(zip_archive_path, filename, partial_name=True):
    """
    Check if zip archive contains a specific file

    :param zip_archive_path: Path to the zip archive
    :param filename: file name to check archive for
    :param partial_name: Boolean indicating if want to check for partial name or not
                         True:  indicates that partial name checking will be performed
                                A test to see if filename string exists in the archive file list
                         False: indicates that partial name check will not be performed
                                An exact file name including path must be provided

    :return: The file or file(s) (command seperated list files names that have a partial match) that were found, None if not found
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    if not zip_archive_path:
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", zip_archive_path)
        return None

    return_filename = None

    zip_archive = zipfile.ZipFile(zip_archive_path)
    try:
        finfo = zip_archive.getinfo(filename)
        return_filename = finfo.filename
    except KeyError:
        if not partial_name:
            logger.warning("<JCS-WARN-10020> : Archive %s does not contain %s", zip_archive_path, filename)
        else:
            # see if can find partial name
            for finfo in zip_archive.infolist():
                if filename in finfo.filename:
                    if return_filename == None:
                        return_filename = finfo.filename
                    else:
                        return_filename = return_filename + ',' + finfo.filename

    return return_filename



def get_content_size_in_zip(zip_archive_path, archived_file_name=None):
    """
    Get the size of a specified file in the in zip archive.
    If file is NOT specified then returns the size of the largest file in archive

    :param zip_archive_path: Path to the zip archive
    :param archived_file_name: A name of file within archive.

    :return: The size of the specified file. If no file is specified then return largest file size
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    size = -1
    if not zip_archive_path or not os.path.isfile(zip_archive_path):
        logger.warning("<JCS-WARN-10024>: Required file %s does not exist", zip_archive_path)
        return size

    if not archived_file_name:
        cmd = "unzip -l %s | sort -k1 -nr | awk 'NR==2 { print $1 }'" % zip_archive_path  # Get the largest content size
        # NR==2 will just print the second row
    else:
        cmd = "unzip -l %s | grep %s | awk '{ print $1 }'" % (zip_archive_path, archived_file_name)  # Get the particular content size

    cmd_result = pythonUtils.execute_cmd(cmd)
    if cmd_result.get_return_code() == 0:
        try:
            size = int(cmd_result.get_output().strip())
        except ValueError as exc:
            #todo get new exception pep8 when checked-in
            traceback_msg = traceback.format_exc()
            logger.warning(exc.message)
            logger.warning(traceback_msg)
        return size
    else:
        logger.warning("<JCS-WARN-10021> : Unable to get the size of %s in archive %s", archived_file_name, zip_archive_path)
        logger.warning(cmd_result.get_err())
        return size


def add_file_to_zip(zip_archive_path, source_file_path):
    """
    Add and/or update file in zip archive

    :param zip_archive_path: Path to the zip archive
    :param source_file_path: Path to file to be added to zip archive

    :return: Boolean indicating if file was successfully added to zip archive
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    if not os.path.isfile(source_file_path):
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", source_file_path)
        return False

    cmd = "zip -j -0u -g %s %s" % (zip_archive_path, source_file_path)
    cmd_result = pythonUtils.execute_cmd(cmd)
    if cmd_result.get_return_code() != 0:
        logger.warning("<JCS-WARN-10022> : Unable to add file %s to archive %s", source_file_path, zip_archive_path)
        logger.warning(cmd_result['DETAIL'])
        return False
    else:
        try:
            # Remove tar.gz.enc file once adding to zip is successful
            os.remove(source_file_path)
        except OSError:
            pass

        return True


def extract_file_from_zip(zip_archive_path, source_file_path, target_dir, if_log=True):
    """
    Extract particular file from zip archive
    :param zip_archive_path: Path to the zip archive
    :param source_file_path:
    :param targetDir:
    :param if_log:
    :return:
    """
    logger = commonLogging.getLogger(os.path.basename(__file__)[:-3])

    #Need this because will cd to another directory an want to reference file
    abs_zip = os.path.abspath(zip_archive_path)

    # Check if zip archive exist
    if not os.path.isfile(abs_zip):
        logger.warning("<JCS-WARN-10024> : Required file %s does not exist", abs_zip)
        return None

    # Check if zip archive contains the file which will be extracted
    file_name = zip_archive_contains(abs_zip, source_file_path)
    if not file_name:
        if if_log:
            logger.warning("<JCS-WARN-10023> : Unable to extract file matching %s. File is not in archive %s", source_file_path, abs_zip)
        return None

    # If target file exist then return target file full name
    # check if the file exists in the target dir as it may have already been extracted and decrypted
    result_file = "%s/%s" % (target_dir, source_file_path)
    if os.path.isfile(result_file):
        logger.debug("no need to extract already extracted")
        return result_file

    # Extract the file to target place
    cmd = "cd %s; unzip %s %s" % (target_dir, abs_zip, file_name)
    cmd_result = pythonUtils.execute_cmd(cmd)
    if cmd_result.get_return_code() != 0:
        logger.warning("<JCS-WARN-10025> : Unable to extract file %s from archive %s", source_file_path, abs_zip)
        return None
    else:
        logger.info("<JCS-INFO-00168> : Extracted file matching %s from archive %s to %s", source_file_path, abs_zip, target_dir)
        return "%s/%s" % (target_dir, file_name)
