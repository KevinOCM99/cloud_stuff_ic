
"""
These are constants used in the common logging which and in based logging (wlst or python).
Common logging is a wrapper over either a python logger or in the case of wlst, a wls logger.
The base loggers need to reference these constants as does the commonLogging, put here to
avoid base logging dependency on common logging.
This should not be imported directly, instead import pythonUtils.commonLogging
"""
import os

# constants: message types
DEBUG = "DEBUG"
INFO = "INFO"
WARNING = "WARNING"
ERROR = "ERROR"
CRITICAL = "CRITICAL"

#loggername
DEFAULT_LOGGER_NAME = 'CPSLogger'

# constants: names for supported env variables
ENV_OCS_LOG_CFG = 'OCS_LOG_CFG'                   # path for configuration file
ENV_OCS_LOG_SECTION = 'OCS_LOG_SECTION'           # section withing configuration file
ENV_OCS_LOG_LEVEL = 'OCS_LOG_FILE_LEVEL'          # override of severity level for log file
ENV_OCS_CONSOLE_LEVEL = 'OCS_LOG_CONSOLE_LEVEL'   # override of severity level for console
ENV_OCS_LOG_ECID = 'OCS_LOG_ECID'                 # ECID used for logging message

# use to define global ecid value via env variable
OCS_LOG_ECID = ""
ecid = os.getenv(ENV_OCS_LOG_ECID)
if ecid:
    OCS_LOG_ECID = ecid