#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
This is the base custom logger that both the python and wls logger derived from
Note: multiple inheritence doesn't work in early version thus factor out common methods and call
"""

import socket
import pythonUtils.clogging.constants as lconstants


def formatMsg(cur_msgs, msg, *args):
    #see if catalog message

    fmsg = getMessage(cur_msgs, msg)

    # see if msg is in the msg file
    if fmsg is None:
        fmsg = msg
    else:
        fmsg = msg + ":" + fmsg

    # now we have the actual string, format with arguments if provided
    if len(args) > 0:
        try:
            tmsg = fmsg % args
            fmsg = tmsg
        except:
            print "** Warning while trying to format message %s with provided arguments" % (msg)
            print "** Message is not fully formatted, please check message and provided arguments"

    #don't fail to put our error because cannot get host name
    try:
        msgHost = socket.gethostname()
    except:
        msgHost = "<unknown_host>"

    fmsg = "(host:" + msgHost + ") - " + fmsg

    # apply ecid if supplied
    if lconstants.OCS_LOG_ECID:
        fmsg = "[ecid: " + lconstants.OCS_LOG_ECID + "]" + fmsg

    return fmsg

def getMessage(cur_msgs, message_id):
    if cur_msgs:
        if message_id in cur_msgs:
            return cur_msgs[message_id]
        else:
            return None
            # else:
            #     #try to load a default message file
            #     msg_path = os.path.join(os.getenv('PYTHONUTILSPATH'),'messages', 'jcs_messages.txt')
            #     if os.path.exists(msg_path):
            #         addMessages(msg_path)

def addMessages(cur_msgs, msgPath):
    iFile = open(msgPath)
    try:
        for line in iFile:
            cline = line.strip()
            if cline.startswith('#') or ':' not in cline:
                continue

            key, val = line.split(':')
            if key is not None and val is not None:
                cur_msgs[key] = val
    finally:
        iFile.close() #needed for older version of python
