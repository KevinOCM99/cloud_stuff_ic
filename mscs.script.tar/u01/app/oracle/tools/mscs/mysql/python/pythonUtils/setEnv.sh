#!/bin/bash

#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"

export PYTHONPATH=${DIR}:${PYTHONPATH}

#WLST is Jython based, which doesn't use PYTHONPATH  set via WLST_PROPERTIES
#
export WLST_PROPERTIES="${WLST_PROPERTIES} -Dweblogic.security.SSL.minimumProtocolVersion=TLSv1.2 -Dpython.path=${DIR}:${PYTHONPATH} -Dweblogic.security.SSL.ignoreHostnameVerification=true -Dweblogic.security.TrustKeyStore=DemoTrust -Djava.security.egd=file:///dev/urandom"


#Variable set help reference Python Utility files
# example:
#    ${PYTHONUTILSPATH}/shellLogging.py
#
export PYTHONUTILSPATH=${DIR}/pythonUtils/


# Variable set help reference WLST Utility files
# example:
#    ${WLSTUTILSPATH}/shellLogging.py
#
export WLSTUTILSPATH=${DIR}/wlstUtils/
