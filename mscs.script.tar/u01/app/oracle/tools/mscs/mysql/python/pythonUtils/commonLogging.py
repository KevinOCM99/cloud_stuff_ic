#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
"""
This is the common logging module.
At the core it relies on python logging that was introduced in v 2.3
however in WLST the supported python (actually jython) version is 2.2.1.
To support a common logging of both python and WLST, this
module provides a common jacket around the WLS logging option when
using WLST and python logging when using version 2.3 or higher of python
"""
import sys, os
import pythonUtils.clogging.constants as lconstants
import pythonUtils


#Constants

# Severity levels
DEBUG = lconstants.DEBUG
INFO = lconstants.INFO
WARNING = lconstants.WARNING
ERROR = lconstants.ERROR
CRITICAL = lconstants.CRITICAL

# Used for validation
VALID_MESSAGE_TYPES = [DEBUG, INFO, WARNING, ERROR, CRITICAL]

# defaults
# change in default behavior. Don't log to file unless log file is explicitly set
#DEFAULT_LOG_FILE_NAME_PREFIX = 'cps'
DEFAULT_FILE_NAME_CONCURRENCY = True
DEFAULT_LOGGER_NAME = lconstants.DEFAULT_LOGGER_NAME
DEFAULT_FILE_SEVERITY = DEBUG
DEFAULT_FILE_COUNT = 7
DEFAULT_FILE_SIZE_KILOBYTES = 500
DEFAULT_CONSOLE_SEVERITY = INFO

# constants: config file
CONFIG_LOG_FILE_NAME_PREFIX = 'LOG_FILE_NAME_PREFIX'
CONFIG_FILE_NAME_CONCURRENCY = 'FILE_NAME_CONCURRENCY'
CONFIG_LOGGER_NAME = 'LOGGER_NAME'
CONFIG_LOG_FILE_SEVERITY = 'LOG_FILE_SEVERITY'
CONFIG_LOG_FILE_COUNT = 'LOG_FILE_COUNT'
CONFIG_LOG_FILE_SIZE_KILOBYTES = 'LOG_FILE_SIZE_KILOBYTES'
CONFIG_CONSOLE_SEVERITY = 'CONSOLE_SEVERITY'


CPS_FILE_NAME_CONCURRENCY = DEFAULT_FILE_NAME_CONCURRENCY


def getLogger(loggername=None):
    """
    Method used to obtain a logger. Calls to the base logging class
    (wlst or python) to obtain the appropriate logger.

    :param loggername: name of logger
    :return: a logger object
    """
    if loggername is None:
        logger = logging.getLogger(logging.getLoggerName())
    else:
        logger = logging.getLogger(loggername)
    return logger


def setFileNamePrefix(prefix):
    """
    Set the logger file name give a file prefix
    Python logging does not support concurrency between processes,
    therefore get the process id for the current process and use it
    in deriving the logging name. This will avoid collisions.

    :param prefix: Used in determining the logger file name
    """

    if CPS_FILE_NAME_CONCURRENCY:
        filename = prefix + "_" + pythonUtils.getPid() + ".log"
    else:
        if prefix.endswith(".log"):
            filename = prefix
        else:
            filename = prefix + ".log"
    logging.setFileName(filename)

def getFileName():
    """
    Get the logger file name

    :return: logger file name
    """
    return logging.getFileName()

def setFileNameConcurrency(conc_flag):
    """
    Set boolean indicating whether to avoid collision
    in file name based on concurrency.

    :param conc_flag: Boolean indicating whether file name
                      concurrency is enabled or disabled
    """
    global CPS_FILE_NAME_CONCURRENCY
    CPS_FILE_NAME_CONCURRENCY = conc_flag

def getFileNameConcurrency():
    """
    Get filename concurrency flag
    :return: Flag indicating if file name concurrency is enabled/disabled
    """
    return CPS_FILE_NAME_CONCURRENCY

def setLoggerName(loggername):
    """
    Set logger name
    :param loggername: name of logger
    """
    logging.setLoggerName(loggername)

def getLoggerName():
    """
    Get logger name
    :return: name of logger
    """
    return logging.getLoggerName()

def setLogFileSeverity(level):
    """
    Set severity level used when logging to file.
    Any message that is at this severity or higer will be
    written to the log file
    :param level: Severity level
    :return:
    """
    if validateLoggingLevel(level, "file"):
        logging.setLogFileSeverity(level.upper())

def getLogFileSeverity():
    """
    Get the severity level for writing to the log file
    :return:
    """
    return logging.getLogFileSeverity()

def setFileCount(count):
    """
    Set the File count indicating the number of log files to save
    :param count: Count of log files to save
    :return:
    """
    logging.setFileCount(count)

def getFileCount():
    """
    Get the current setting for log file count
    :return: Count of log files to save
    """
    return logging.getFileCount()

def setFileSize(size):
    """
    Set the max size of a log file
    :param size: max size of log file
    """
    logging.setFileSize(size)

def getFileSize():
    """
    Get the maximum log file size setting
    :return: maximum size of a log file
    """
    return logging.getFileSize()

def setConsoleSeverity(level):
    """
    Set the severity level for writing to console.
    Anything at this level or higher (more severe) will
    be written to the console
    :param level: Severity level
    :return:
    """
    if validateLoggingLevel(level, "console"):
        logging.setConsoleSeverity(level.upper())

def getConsoleSeverity():
    """
    Get the severity level for logging to the console
    :return: console severity level
    """
    return logging.getConsoleSeverity()

def validateLoggingLevel(level, logger_type):
    """
    Validate that the supplied severity level is accurate
    :param level: Severity level to validate
    :param logger_type: type of logger (file or consoel)
    :return: Boolean indicating if a valid severity level (True) or not (False)
    """
    if level in VALID_MESSAGE_TYPES:
        return True
    else:
        print "*** <WARNING> The specified " + logger_type + " severity level of " + level + " is invalid and could not be set"
    return False


def displayLoggingConfigStatus(logger=None):
    """
     Displays configuration status to console and log

    :param logger: optional logger object
    :return:
    """
    #log file name
    lfn = getFileName()
    if lfn is None:
        fn_msg = " >>>> Log file: None"
    else:
        fn_msg = " >>>> Log file: " + getFileName()

    fsev_msg = " >>>> Log file severity: " + getLogFileSeverity()
    fc_msg = " >>>> Log file count: " + str(logging.getFileCount())
    fsize_msg = " >>>> Log file Size: " + str(logging.getFileSize())
    csev_msg = " >>>> Console severity: " + str(logging.getConsoleSeverity())

    if logger is None:
        print fn_msg
        print fsev_msg
        print fc_msg
        print fsize_msg
        print csev_msg
    else:
        logger.debug(fn_msg)
        logger.debug(fsev_msg)
        logger.debug(fc_msg)
        logger.debug(fsize_msg)
        logger.debug(csev_msg)


def loadLoggingConfigFile(config_path, config_section="default"):
    """
    Load the logging config file
    :param config_path: path of the config file
    :param config_section: section within config file
    :return:
    """
    # If running in the wlst environment then supported version is currently
    # 2.2.1, which means SafeConfigParser is not support (2.3)
    if sys.version_info < (2, 3):
        from ConfigParser import ConfigParser as CParser
    else:
        from ConfigParser import SafeConfigParser as CParser

    if os.path.exists(config_path):
        cparser = CParser()
        cparser.read(config_path)

        if cparser.has_section(config_section):
            print '<Info> - Loading configuration file "' + config_path + '" using section "' + config_section + '"'

            if cparser.has_option(config_section, CONFIG_FILE_NAME_CONCURRENCY):
                concurrency = cparser.get(config_section, CONFIG_FILE_NAME_CONCURRENCY)
                if concurrency.upper() == 'TRUE':
                    setFileNameConcurrency(True)
                elif concurrency.upper() == 'FALSE':
                    setFileNameConcurrency(False)

            if cparser.has_option(config_section, CONFIG_LOG_FILE_NAME_PREFIX):
                setFileNamePrefix(cparser.get(config_section, CONFIG_LOG_FILE_NAME_PREFIX))

            if cparser.has_option(config_section, CONFIG_LOGGER_NAME):
                setLoggerName(cparser.get(config_section, CONFIG_LOGGER_NAME))

            if cparser.has_option(config_section, CONFIG_LOG_FILE_SEVERITY):
                setLogFileSeverity(cparser.get(config_section, CONFIG_LOG_FILE_SEVERITY))

            if cparser.has_option(config_section, CONFIG_LOG_FILE_COUNT):
                setFileCount(int(cparser.get(config_section, CONFIG_LOG_FILE_COUNT)))

            if cparser.has_option(config_section, CONFIG_LOG_FILE_SIZE_KILOBYTES):
                setFileSize(int(cparser.get(config_section, CONFIG_LOG_FILE_SIZE_KILOBYTES)))

            if cparser.has_option(config_section, CONFIG_CONSOLE_SEVERITY):
                setConsoleSeverity(cparser.get(config_section, CONFIG_CONSOLE_SEVERITY))
        else:
            raise Exception("<Error> Could not load configuration file. Section " + config_section + " in configuration file " + config_path + " not found.")
    else:
        raise Exception("<Error> Specified configuration file " + config_path + " is not found.")


# Main processing (done on import)

#If running in the WLST environment then supported version is currently
# 2.2.1, which means python logging is not supported (2.3)
# Also note that import of the logging needs to be done after the
# processing of configuration information

if pythonUtils.is_wlst():
    import pythonUtils.clogging.wls_logging as logging
else:
    import pythonUtils.clogging.py_logging as logging

# Set initial default values in logging package
setFileNameConcurrency(DEFAULT_FILE_NAME_CONCURRENCY)
# Default is to log to stdout only
#setFileNamePrefix(CONFIG_LOG_FILE_NAME_PREFIX)
setLoggerName(DEFAULT_LOGGER_NAME)
setLogFileSeverity(DEFAULT_FILE_SEVERITY)
setFileCount(DEFAULT_FILE_COUNT)
setFileSize(DEFAULT_FILE_SIZE_KILOBYTES)
setConsoleSeverity(DEFAULT_CONSOLE_SEVERITY)

# Environment Variable Processing performed on import
# Process config file if one exists
CPATH = ""
CLOG_CONFIG = os.getenv(lconstants.ENV_OCS_LOG_CFG)
if CLOG_CONFIG:
    CPATH = CLOG_CONFIG
else:
    CFILE = os.path.join(".", "clogging", "logging_config.ini")
    if os.path.exists(CFILE):
        CPATH = CFILE

# section within config file
CLOG_SECTION = os.getenv(lconstants.ENV_OCS_LOG_SECTION)
if CLOG_SECTION:
    CSECTION = CLOG_SECTION
else:
    CSECTION = 'defaults'

if CPATH:
    loadLoggingConfigFile(CPATH, CSECTION)

# it is possible override log levels
# using an environment variable.
OCSLL = os.getenv(lconstants.ENV_OCS_LOG_LEVEL)
if OCSLL:
    logging.setLogFileSeverity(OCSLL)

OCSCL = os.getenv(lconstants.ENV_OCS_CONSOLE_LEVEL)
if OCSCL:
    logging.setConsoleSeverity(OCSCL)


# Helper logging methods

def logMessage(message_type,
               message,
               file_name,
               logger_name,
               file_name_concurrency='True',
               display_status='False'):
    """
      Description: General method use to write log messages
                    (Used by shellLogging.py script)

       Example:
          logMessage(Debug "Debug msg" ext.log logger True)
          logMessage( Info "Info msg" ext.log logger)

        message_type:   Support values, DEBUG, INFO, WARNING, ERROR, CRITICAL
        message:        Actual text of  message
        file_name:      [optional] Log file name prefix <default cps>
        logger_name:    [optional] Logger name <default CPSLogger>
        file_name_concurrency: [optional] Boolean indicating whether log file name should
                               contain a PID ensuring no concurrency conflicts between
                               multiple processes writing to single log file <default=False>
        display_status: [optional] Status output flag <default False>
    """

    # Because there is not concurrency control between processes for
    # writing to log files, the default behavior is to create a log
    # file which contains the PID in the name. Every process thus
    # creates its own log file.
    if file_name_concurrency.upper() == 'TRUE':
        setFileNameConcurrency(True)
    elif file_name_concurrency.upper() == 'FALSE':
        setFileNameConcurrency(False)

    if file_name != "None":
        setFileNamePrefix(file_name)

    logger = getLogger(logger_name)

    if display_status.upper() == 'TRUE':
        displayLoggingConfigStatus(logger)


    if message_type.upper() == DEBUG:
        logger.debug(message)
    elif message_type.upper() == INFO:
        logger.info(message)
    elif message_type.upper() == WARNING:
        logger.warning(message)
    elif message_type.upper() == ERROR:
        logger.error(message)
    elif message_type.upper() == CRITICAL:
        logger.critical(message)
    else:
        logger.info("Invalid message type specified " + message_type + "default to INFO")
        logger.info(message)
