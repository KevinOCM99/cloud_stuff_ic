#!/bin/bash
# This script purges files according to configure file $CONF, and logs
# the result to $LOG:
#   mscs_cron $CONF $LOG
#
# Each line in the configuration file has the following format:
#   PATH:FILES:DAYS

CONF=$1
LOG=$2

echo "MySQL Purge starts at $(date +%Y-%m-%d\ %H:%M)" >> $LOG

sed -e '/^$/d;/^#/d' $CONF | while read LINE; do
    mscsPATH=${LINE%%:*}; LINE=${LINE#*:}
    mscsFILE=${LINE%%:*}; LINE=${LINE#*:}
    mscsTIME=${LINE}

    echo "Purge: path: $mscsPATH, files: $mscsFILE, days: $mscsTIME" >> $LOG
    find $mscsPATH -name $mscsFILE -type f -mtime +$mscsTIME -print -delete >> $LOG
done
