#!/bin/bash
#
#Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#

#
# This script will do the things needed when system or nimbula-orchestration is restarted
#

#Absolute path of current file
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#import
source $DIR/constants.sh
source $DIR/msaas-provisioning-utils.sh
source $DIR/mysql-installation-utils.sh
#logger used for logging msaas provisioning
source $DIR/logger.sh  --source_only
meb_option=`getAttribute /userdata/msaas_enterprise_backup`
#Userdata variables
#mounting
bin_home=`getAttribute /storage_map/bin/mountpoint`
bin_device=`getAttribute /storage_map/bin/device`
data_home=`getAttribute /storage_map/data/mountpoint`
data_device=`getAttribute /storage_map/data/device`

if [ "$meb_option" == "BOTH" ]; then
    backup_home=`getAttribute /storage_map/backup/mountpoint`
    backup_device=`getAttribute /storage_map/backup/device`
fi
tools_home=`getCriticalAttribute /storage_map/tools/mountpoint`
sys_user_home=${tools_home}/home/$SYS_USER

componet_name=`getAttribute /artifacts/SERVICE_TOOLS`
#log file and marker file location
msaas_home=${tools_home}/${MSAAS_HOME_FOLDER}
log_home=${msaas_home}/${MSAAS_LOG_FOLDER}
log_file=$log_home/${MSAAS_PROVISIONING_LOG_NAME}

#mountingVariables
volume_group_bin=vg_bin
logical_volume_bin=lv_bin
device_path_bin=/dev/${volume_group_bin}/${logical_volume_bin}
volume_group_data=vg_data
logical_volume_data=lv_data
device_path_data=/dev/${volume_group_data}/${logical_volume_data}

#mysql
base_dir="${bin_home}/mysql"
data_dir="${data_home}/mysql"
mysql_bin_dir=${base_dir}/bin
mysqld_safe=${mysql_bin_dir}/mysqld_safe
mysql_bin_log_dir=${data_dir}/binlogs
mysql_bin_log=${data_dir}/binlogs/mysql01-bin
mysql_conf_file=${MYSQL_CONF_FILE}
mysql_em_dir="${bin_home}/enterprise/monitor"

#variables
orchestration_restart=0
isMaster=0

#Initialize logger
if [ ! -f $log_file ]; then
        mkdir -p $log_home
        chown -R $SYS_USER:$SYS_USER $log_home
fi
launchLogger $log_file "Starting start-service.sh"

log START "Restart Service"

#Check for orchestration restart
if [ ! -f /tmp/credentials_admin ]; then
    orchestration_restart=1
    log "Found orchestration restart."
else
    log "Found Machine restart."
fi
#Latency Volume Check
latency_volume_found=1
mysql_log_home=`getAttribute /storage_map/MySQLlog/mountpoint`
if test $? -ne 0; then log Warning "Latency volume mountpoint attribute is not available"; latency_volume_found=0; fi
mysql_log_device=`getAttribute /storage_map/MySQLlog/device`
if test $? -ne 0; then log Warning "Latency volume device attribute is not available"; latency_volume_found=0; fi

mountStorageVolume $bin_home $bin_device "bin"
mountStorageVolume $data_home $data_device "data"
if test $latency_volume_found -eq 1; then
    mountStorageVolume $mysql_log_home $mysql_log_device "log"
else
    log ERROR "translog volume Not Found"
fi
if [ "$meb_option" == "BOTH" ]; then
    mountStorageVolume $backup_home $backup_device "backup"
fi



#Start mysql server
#check if mysqld_safe is running
ISMYSQLUP=$(pgrep mysqld_safe | wc -l);
#
log START "Mysql server"
if [ -d  ${mysql_bin_dir} -a "$ISMYSQLUP" -ne 1 ]; then
    log "Already existing mysql installation directory found."
    runuser -l $SYS_USER -c "cd $mysql_bin_dir/..; ./bin/mysqld_safe &"

    log "Started mysql using system user $sys_user..."
    log FINISH "Mysql server"
fi

#delay of 25 secs, since EM uses the already created mysql instance
sleep 25

#Start enterprise monitor
log START "Enterprise Monitor"
if [ -d ${mysql_em_dir} ]; then
    log "Already existing enterprise monitor directory found."
    runuser -l $SYS_USER -c "cd $mysql_em_dir; ./mysqlmonitorctl.sh start tomcat"
    $mysql_em_dir/mysqlmonitorctl.sh status | grep "Tomcat is running"
    if [ $? -eq 0  ]; then
         log "Started enterprise monitor using system user $sys_user..."
    else
         log "Could not start enterprise monitor"
    fi
fi
log FINISH "Enterprise Monitor"

log FINISH "Restart service"
