#!/bin/bash
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#

#
# This script contains functions used by msaas provisiong
#

attributes="http://192.0.0.192/latest/attributes"
metadata="http://192.0.0.192/latest/meta-data"
NOT_FOUND="metadata not foUnd"

#
# this function will fetch an orchestration attribute from the given key and return its value
#
getAttribute() {
    key=$1

    return_value=$(curl -w "%{http_code}" -m 60 -s ${attributes}/"$key")
    result_code=${return_value:(-3)}
    user_data_value=${return_value::${#return_value}-3}
    if [ -z "$user_data_value" ] || [ $result_code != "200" ]
    then
        log WARNING "Not Found Userdata: $attributes/$key"
        echo "$NOT_FOUND"
        return 1
    else
        echo "$user_data_value"
        return 0
    fi
}

#
# this function will exit if metadata item is not found
#
getCriticalAttribute() {
    key=$1

    return_value=`getAttribute "$key"`
    if [ "$return_value" == "${NOT_FOUND}" ]; then
        log ERROR "Not Found Critical Userdata: $attributes/$key Exiting..."
        exit 1
    else
         echo "$return_value"
    fi
}

#function to get meta-data values
getMetadata(){
    key=$1

    return_value=$(curl -w "%{http_code}" -m 60 -s ${metadata}/"$key")
    result_code=${return_value:(-3)}
    user_data_value=${return_value::${#return_value}-3}
    if [ -z "$user_data_value" ] || [ $result_code != "200" ]
    then
        log WARNING "Not Found Userdata: $metadata/$key"
        echo "$NOT_FOUND"
        return 1
    else
        echo "$user_data_value"
        return 0
    fi
}

#check whether artifact is ther in cloud storage

getArtifactStatus() {
    storage_uri=$1
    cloudKey=$2
    retry_count=10
    wait_time=1
    count=0
    found_artifact=0

    while (( retry_count > count && found_artifact != 1 )); do
        wget --spider "${storage_uri}/${cloudKey}"
        if test $? -eq 0; then
            found_artifact=1
            break;
        fi
        sleep $wait_time
        ((count++))
    done

    if [ $found_artifact -eq 1 ] ; then
        return 0
    else
        return 1
    fi
}

#check whether artifact is ther in cloud storage
getArtifactSize() {
    storage_uri=$1
    cloudKey=$2

    size=$(curl --head "${storage_uri}/${cloudKey}" | grep Content-Length | cut -d " " -f 2)
    lengthOfBits=${#size}
    echo ${size:0:lengthOfBits-1}
}


#download artifact from cloud
conditionalFetchFromCloud() {
    cloudKey=$1
    fileDest=$2
    authString=$3
    storage_uri=$4
    #additionalCurlOptions=$5
    componentName=$5
    if [ "${NOT_FOUND}" != "${cloudKey}" ]; then
        getArtifactStatus $storage_uri $cloudKey
        status=$?
        if [ $status -ne 0 ]; then
            log ERROR "ARTIFACT-ERROR: not found artifact ${storage_uri}/${cloudKey}."
            return 4
        fi
        log "fetching data for ${cloudKey}"
        curlUserData=""
        if [ "X${authString}" != "X" ] ; then
            curlUserData=" --user ${authString} "
        fi
        #Retry 9 times, with backoff that mean max wait of 511 secs
        curl -X GET -v -m 1200 --retry 9 --fail -C - ${curlUserData} "${storage_uri}/${cloudKey}" --output ${fileDest}
        curlRetVal=$?   
        if [ $curlRetVal -eq 0 ] ; then
            log "using ${storage_uri}/${cloudKey}"
        else
            log ERROR "FETCH-ERROR in downloading artifact for ${componentName} - ${storage_uri}/${cloudKey}"
            return 2
        fi
    else
        log ERROR "ATTRIBUTE-ERROR ${componentName} ${cloudKey}"
        return 3
    fi
    return 0
}

# Fetch the artifact from remote storage
#
# $1: the cloud key (aka. path) of the artifact in remote storage
# $2: the destination for the artifact on this vm
# $3: the artifact container key, http root or nfs storage path
# $4: the name of the component being fetched
#
fetchArtifact() {
    
    # target path for download artifact to
    fileDest=$1
    # base container for artifacts
    storage_container=$2
    # source path from remote storage for artifact
    cloudKey=$3
    # name of artifact that we are downloading
    componentName=$4

    authStringr=
    # each try for 30 seconds, three retries
    conditionalFetchFromCloud ${cloudKey} ${fileDest} "${authString}" ${storage_container}  ${componentName}
    result=$?
    echo $result
    return $result
}

#extract to folder
extractTarGzArtifact(){
    sourceArchive=$1
    extractLocation=$2
    sys_user=$3

    tar zxvf ${sourceArchive} --directory=$extractLocation  > /dev/null 2>&1
    status=$?
    chown -R $sys_user:$sys_user $extractLocation
    status2=$?
    ((status+=status2))
    echo $status
    return $status
}

extractZipArtifact(){
    sourceArchive=$1
    extractLocation=$2
    sys_user=$3

    unzip ${sourceArchive} -d $extractLocation  > /dev/null 2>&1
    status=$?
    chown -R $sys_user:$sys_user $extractLocation
    status=$?
    echo $status
    return $status
}

#This function will mount the device into the mountpoint specified
#
# $1 mount point to where the device should be mounted
# $2 block device which need to be mounted
# $3 any name that can be consumed while creating logical volume and volume group for a particular device.
#
mountStorageVolume() {
    mountpoint=$1
    device=$2
    name=$3

    volume_group="vg_${name}"
    logical_volume="lv_${name}"
    device_path=/dev/${volume_group}/${logical_volume}

    #Mount directory for mysql service.
    if [ -n $mountpoint ] && [ -n $device ]; then
        if ! [ -b $device ]; then log ERROR "device: \"$device\" doesnt exist"; return 3; fi
        if mountpoint -q ${mountpoint}
        then
            echo "The ${mountpoint} is already mounted."
            log "The ${mountpoint} is already mounted."
        else
            if mount ${device_path}  ${mountpoint}
            then    
                log "The $device is already formatted. Successfully mounted it to ${mountpoint}"
            else
                pvcreate --verbose --force --metadatacopies 2 --metadatatype 2 ${device}
                vgcreate --verbose --force --metadatacopies 2 --metadatatype 2 ${volume_group} ${device}
                lvcreate --verbose  --extents 100%VG --name ${logical_volume} ${volume_group}
                mkdir ${mountpoint}
                mkfs.ext4 ${device_path}
                tune2fs -e remount-ro ${device_path}
                mount ${device_path} ${mountpoint}
                if mountpoint -q ${mountpoint}
                then
                    log "Storage volume ${mountpoint} is mounted"
                else
                    log ERROR "Mounting device: \"$device_path\" on mountpoint: \"$mountpoint\" is not successful."
                    return 2
                fi
            fi
        fi
    else
        log ERROR "parameter error - mountpoint:\"$mountpoint\", device:\"$device\""
        return 1
    fi
}

#
#Setup the python scripting env
# $1 system user by which mysql process will be started
# $2 a folder where python files inside the service tools are extracted
#
setPythonEnv(){
    sysuser=$1
    service_tools_home=$2


    #Change permissions of service_tools_home
    log "Changed permission of $service_tools_home to \"$sysuser:$sysuser\"."

    export PYTHONUTILSPATH=${service_tools_home}/python/pythonUtils
    export PYTHONSERVICEUTILSPATH=${service_tools_home}/python/pythonServiceUtils
    export PYTHONPATH=${service_tools_home}/python

    if [ -f ${service_tools_home}/python/pythonUtils/setEnv.sh ] ; then
        . ${service_tools_home}/python/pythonUtils/setEnv.sh
    fi

    if [ -f ${service_tools_home}/python/pythonServiceUtils/setEnv.sh ] ; then
        . ${service_tools_home}/python/pythonServiceUtils/setEnv.sh
    fi
    return 0
    }

#to Find ADMIN or NODE
isAdmin() {

    temp_file1=/tmp/temp1.txt
    service_vms=`getAttribute /serviceVM`
    echo "$service_vms" > $temp_file1

    admin=0
    while read LINE
    do
        role=`getAttribute /serviceVM/$LINE/role`
        if [ "$role" = "ADMIN" ]; then
            masterHost=`getAttribute /serviceVM/$LINE/hostname`
        fi
    done < "$temp_file1"
    rm -f $temp_file1
    if [ "$(uname -a | awk '{print $2}')" = ${masterHost,,} ]; then
        admin=1
    else
        admin=0
    fi
    echo $admin
}

#crete afile if it doesnt exist
createFile () {
    file=$1
    folder=$2
    user=$3

    if [ ! -f $file ]; then
        mkdir -p $folder
        touch $file
        chown -R $user:$user $folder
    fi
}


#returns Admin node name
getMasterHostName(){
    temp_file1=/tmp/temp1.txt
    service_vms=`getAttribute /serviceVM`
    echo "$service_vms" > $temp_file1
    
    while read LINE
    do
        role=`getAttribute /serviceVM/$LINE/role`
        if [ "$role" = "ADMIN" ]; then
            masterHost=`getAttribute /serviceVM/$LINE/hostname`
        fi
    done < "$temp_file1"
    rm -f $temp_file1
    echo "$masterHost"
}

#Return VMids of 
getNodeVmIds()
{
    temp_file1=/tmp/temp1.txt
    service_vms=`getAttribute /serviceVM`
    echo "$service_vms" > $temp_file1
    nodeVmCount=0

    while read LINE
    do
        role=`getAttribute /serviceVM/$LINE/role`
        if [ "$role" != "ADMIN" ]; then
        nodeServiceVmIds[nodeVmCount]="$LINE"
        ((nodeVmCount++))
        fi
    done < "$temp_file1"
    rm -f $temp_file1
    echo "${nodeServiceVmIds[@]}"
}

#Function Todecrypt Credential File
decryptCredentialFile(){
    credentialFile=$1
    index=$2
    userHome=$3

    source $credentialFile
    case ${index} in
    1) word=${mysqlPassword};;
    2) word=${mysqlUserName};;
    3) word=${emManagerPassword};;
    4) word=${emManagerUserName};;
    5) word=${emAgentPassword};;
    6) word=${emAgentUserName};;
    7) word=${backupStorageUserPassword};;
    8) word=${backupStorageUserName};; 
    esac
    echo `echo -n ${word} | openssl enc -A -base64 -d | openssl rsautl -decrypt -oaep -inkey ${userHome}/.ssh/id_rsa`
}


#reads the password file and returns the password based on selection depend on decryptCredentialFile function
readCredentialFileEntry(){
    sempahoreFile=$1
    credFile=$2
    userSelection=$3
    userHome=$4

    password=''
    for i in {1..20}
    do
        #Check to see whether the semaphore file has been set
        if [ -f "$sempahoreFile" ]
        then
            #Use the decrypt strings to extract the password
            password=`decryptCredentialFile ${credFile} $userSelection $userHome`
            break
        else
            if [ $i -eq 20 ];
                then
                log 'Semaphore file not found, retries exhausted - exiting';
                exit;
            else
                log 'Waiting for semaphore file from key transfer';
                sleep 30s;
            fi
        fi
    done
    echo $password
}

#Wait to get the /tmp/credentials_admin: for MASTER node. In case if key transfer opn may get delayed
waitForCredentialFile(){
    credential_file_admin=$1
    master=$2
    sleepTime=$3
    max_retry_count=$4

    if [ $master -eq 1 ]; then
        echo wait to get credentials file
        count=0
        test -f $credential_file_admin
        file_status=$?

        while (( max_retry_count > count && $file_status != 0 ))
        do
            ((count++))
            log "Waiting for credential file \"$credential_file_admin\" to be created in Admin node..."
            sleep $sleepTime
            test -f $credential_file_admin
            file_status=$?
        done
    fi

    return $file_status
}

getMysqlUserNameFromCredFile(){
    sys_user_home=$1

    username=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 2 $sys_user_home)
    echo "$username"
}

getMysqlPasswordFromCredFile(){
    sys_user_home=$1
    
    password=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 1 $sys_user_home)
    echo "$password"
}

getMemManagerUserNameFromCredFile(){
    sys_user_home=$1

    username=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 4 $sys_user_home)
    echo "$username"
}

getMemManagerPasswordFromCredFile(){
    sys_user_home=$1

    password=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 3 $sys_user_home)
    echo "$password"
}

getMemAgentUserNameFromCredFile(){
    sys_user_home=$1

    username=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 6 $sys_user_home)
    echo "$username"
}

getMemAgentPasswordFromCredFile(){
    sys_user_home=$1

    password=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 5 $sys_user_home)
    echo "$password"
}

#create instance from backup
getUserBackupStorageUnameFromCredFile(){
    sys_user_home=$1
    username=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 8 $sys_user_home)
    echo "$username"
}
 
#create instance from backup
getUserBackupStorageUpasswordFromCredFile(){
    sys_user_home=$1
    password=$(readCredentialFileEntry ${SEMAPHORE_FILE} $ADMIN_CRED_FILE 7 $sys_user_home)
    echo "$password"
}

#This will make Slave wait till MASTER script is completely run.
waitForMasterScriptTofinish(){
    master=$1
    sys_user_home=$2
    masterHost=$3
    provisionMarkerforSlaves=$4

    if [ $master -eq 0 ]; then
        flag=0
        while [ $flag -ne 1 ]
        do
            if ssh -i ${sys_user_home}/.ssh/id_rsa $sys_user@$masterHost -o StrictHostKeyChecking=no stat $provisionMarkerforSlaves \> /dev/null 2\>\&1
            then
                flag=1
            fi
            echo "waiting for master host provisioning to complete..."
            log " Waiting for master host provisioning to complete..."
            sleep 3
        done
        echo "master host provisioning is completed"
        log "Master host provisioning is completed."
    fi
}

#Create credential files in slave hosts. This is temporary
createCredFilesInSlaves(){
    master=$1
    sys_user=$2
    sys_user_home=$3
    credential_file_admin=$4
    credential_file_ms=$5

    temp_file1=/tmp/temp1.txt
    getAttribute /serviceVM > $temp_file1
    countVM=0
    while read LINE
    do
        array[countVM]="$LINE"
        ((countVM++))
    done < "$temp_file1"
    rm -f $temp_file1

    if [ $master -eq 1 ]; then
        for i in "${array[@]}"
        do
            slaveHost=`getAttribute /serviceVM/$i/hostname`
            scp -o StrictHostKeyChecking=no -i ${sys_user_home}/.ssh/id_rsa $credential_file_admin $sys_user@$slaveHost:$credential_file_ms
            if [ $? -eq 0 ]; then
                log " Copied credentials from Admin to Managed server \"$slaveHost\"."
            else
                  log " Copiying Failed for credentials from Admin to managed-server \"$slaveHost\"."
            fi
        done
        log "Copiying credentials from Admin to all managed-servers finished."
    fi
}

#Create a Provisioningmarker for slaves to continue their operation
createInitialProvisioningMarker(){
    master=$1
    provisioningMarkerforSlaves=$2
    provisioningMarkerforMaster=$3
    sys_user=$4

    if [ $master -eq 1 ]; then
        echo "Master-server is done with provisioning operations" >> $provisioningMarkerforSlaves
        chown $sys_user:$sys_user $provisioningMarkerforSlaves
    else
        echo "Client-server is done with its provisioning operations" >> $provisioningMarkerforMaster
        chown $sys_user:$sys_user $provisioningMarkerforMaster
    fi
}

#getNodeVmCount
getNodeVmCount(){

    temp_file1=/tmp/temp1.txt
    service_vms=`getAttribute /serviceVM`
    echo "$service_vms" > $temp_file1
    nodeVmCount=0

    while read LINE
    do
        role=`getAttribute /serviceVM/$LINE/role`
        if [ "$role" != "ADMIN" ]; then
            ((nodeVmCount++))
        fi
    done < "$temp_file1"
    rm -f $temp_file1
    echo ${nodeVmCount}
}

#Wait untill all slaves complete
waitForAllSlavesToComplete() {
    master=$1
    sys_user_home=$2
    sys_user=$3
    provisioningMarkerforMaster=$4

    if [ $master -eq 1 ]; then
        provisionedClients=0
        numberOfClients=$(getNodeVmCount)
        for i in "$(getNodeVmIds )"
        do
            alreadyProvisioned[$i]=0
        done
        while [ $numberOfClients -ne $provisionedClients ]
        do
            for i in "$(getNodeVmIds )"
            do
                if [ ${alreadyProvisioned[$i]} -ne 1 ]; then
                    slaveHost=`getAttribute /serviceVM/$i/hostname`
                    if ssh -i ${sys_user_home}/.ssh/id_rsa $sys_user@$slaveHost -o StrictHostKeyChecking=no stat $provisioningMarkerforMaster \> /dev/null 2\>\&1
                    then
                        alreadyProvisioned[$i]=1
                        ((provisionedClients++))
                        log "Provisioning finished in slave-host: \"$slaveHost\"."
                    else
                        log "Provisioning is still going on in slave-host: \"$slaveHost\"."
                        sleep 2
                    fi
                fi
                     #scp -o StrictHostKeyChecking=no -i ${oracle_user_home}/.ssh/id_rsa $credential_file_admin oracle@$slaveHost:$credential_file_ms
            done
        done
        log "Provisioning in all slave-servers finished."
    fi
}



#For provisioning check of SM
createProvisioningMarker(){
    provisioningMarkerFile=$1
    status=$2
    sys_user=$3
    shift;shift;shift
    msg="${@}"

    case $status in
        "0") message="service is started, provisioning done " 
        ;;
        *) message="provisioning failed $msg"
        ;;
    esac

    # check for dirname exists in machineimage; else create it
    marker_dir=$(dirname "${provisioningMarkerFile}")
    mkdir -p $marker_dir

    echo $message >> $provisioningMarkerFile
    /bin/chown  $sys_user:$sys_user  $provisioningMarkerFile
    log "Created provisioning marker log at \"$provisioningMarkerFile\""
    return 0
}

editOracleUlimitInFile () {
    conf_file=$1
    limit=$2
    
    newline="oracle   soft   nofile    $limit"
    line_number=$(awk '/oracle   soft   nofile/{ print NR; exit }' $conf_file)
    
    if [ ! -z $line_number ]; then
        sed -i "${line_number}s/.*/${newline}/" $conf_file
    else
        echo $newline >> $conf_file
    fi

}

serviceCupsOff(){
    
    chkconfig cups off
    service cups stop

}




#Function to configure any os parameters
#function to configure different linux parameters
configureOS(){
    os_open_file_limit=$1

    filename1=/etc/security/limits.d/oracle-rdbms-server-12cR1-preinstall.conf
    filename2=/etc/security/limits.conf 

    if [ -f $filename1 ]; then
        editOracleUlimitInFile $filename1 $os_open_file_limit
        log "Edited ulimit in file: $filename1"
    fi
    if [ -f $filename2 ]; then
        editOracleUlimitInFile $filename2 $os_open_file_limit
        log "Edited ulimit in file: $filename2"
    fi
    ulimit -n $os_open_file_limit

    serviceCupsOff
    return 0
}

#
#Takes line to be modified and put Escape Characters and return the new line
#

putEscapeCharacters(){
line=$1

echo "$line" | sed -r 's/[/]+/\\\//g';
}
#
#function to replace line with number new line and filename as parameters
#
replaceLine(){
    line_number=$1
    newline=$2
    file_name=$3

    sed -i "${line_number}s/.*/${newline}/" $file_name
    sed -i "${line_number}s/.*/${newline}/" $file_name
}

#get Ram allocated to the VM
getSystemRamInMB(){
    # setting default ram size as 7.5 gb, that of the smallest shape supported(oc3).
    default_ram_size=7500

    free -m | fgrep Mem | awk '{printf $2}' /dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       echo $default_ram_size
       return 1
    else
       free_mem=$(free -m | fgrep Mem | awk '{printf $2}')
       echo $free_mem
       return 0
    fi
}

#change Soft Link
changeSoftLink(){
    linkName=$1
    old_mysql=$2
    new_mysql=$3
    
    rm -rf $linkName
    ln -s -f $new_mysql $linkName
    return $?
}

#---frame work to execute jobs--
#cleanup directories from array

removeDirectories(){
    
    declare -a argAry1=("${!1}")
    for i in "${argAry1[@]}"; do rm -rf $i; log2 "Removed object $i "; done
}

cleanup(){
    removeDirectories cleanup_objects[@]
}

makeExit(){
    status=$1
    shift
    message=("${@}")
    cleanup
    createProvisioningMarker $PROVISION_MARKER_FILE $status $SYS_USER "${message[@]}"
    exit ${status}
}

doTask(){
    job=$1
    log_status=$2

    $job; 
    status=$?
    job_name=`echo $job | awk 'BEGIN {FS=" ";} {print $1;}'`

    if test $status -eq 0; then
        status_message="Successful"
    else
        status_message="Failed($status)"
    fi

    if test -z $log_status; then
        log DEBUG "TASK: $job_name, Status: $status_message"
    elif test $log_status = 'log'; then
        log DEBUG "TASK: $job, Status: $status_message"
    fi

    return $status
}

operator(){
  action=$1
  operation=$2
      case $action in  
        "start") log START "$operation" 
        ;;
        "stop") log FINISH "$operation"
        ;;
        *) log "operation action \"$action\" not defined"
        ;;
    esac
}
