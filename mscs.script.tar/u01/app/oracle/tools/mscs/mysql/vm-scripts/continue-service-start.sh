#!/bin/bash
#
# Copyright (c) 2014-2017 Oracle and/or its affiliates. All rights reserved.
#

#
# Service level operations start from here.
# This script will call Mysql Service Provisioning script.
#

#Absolute path of current file
echo "oracle hard nofile 20000" >> /etc/security/limits.conf
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#import
source $DIR/constants.sh
#logger used for logging msaas provisioning
source $DIR/logger.sh  --source_only
source $DIR/msaas-provisioning-utils.sh
source $DIR/mysql-installation-utils.sh

#error logs and debug outputs are redirected to "/tmp/prov_error.log"
touch $DEBUG_LOG
chmod 777 $DEBUG_LOG
chown $SYS_USER $DEBUG_LOG

touch $ERROR_LOG
chmod 777 $ERROR_LOG
chown $SYS_USER $ERROR_LOG

exec 10> $DEBUG_LOG
exec 2> $ERROR_LOG
export BASH_XTRACEFD=10

#starting debug mode, should pause when sesitive data operations starts
set -x


#for cloning, the start_mode will be "CLONE".
start_mode=$1

#Userdata variables
#mounting
tools_home=`getCriticalAttribute /storage_map/tools/mountpoint`
sys_user_home=${tools_home}/home/$SYS_USER
vm_script_home=$DIR

host_name=$(getMasterHostName)

componet_name=`getAttribute /artifacts/SERVICE_TOOLS`
#log file and marker file location
msaas_home=${tools_home}/${MSAAS_HOME_FOLDER}
log_home=${msaas_home}/${MSAAS_LOG_FOLDER}
log_file=$log_home/${MSAAS_PROVISIONING_LOG_NAME}
#service scripts location.
paas_root=${tools_home}/paas
platform_tooling_bin=${paas_root}/bin
tools_root=`getAttribute /toolsRoot`
service_tools_home=${tools_root}/${componet_name}
#preinstallation variables
##mysql configuration

mysql_client_conf_file=$sys_user_home/$MYSQL_CLIENT_CONF_FILE

mysqld_safe=${mysql_bin_dir}/mysqld_safe
mysql_port=`getAttribute /userdata/msaas_admin_port`
#mysql installer
zips_folder=${ZIPS_FOLDER}
mysql_version=`getAttribute /userdata/mysql_version`
#cloudKey_EM=`getAttribute /artifacts/MSAAS_EM/cloudKey`
#cloudKey_EM_agent=`getAttribute /artifacts/MSAAS_EM_AGENT/cloudKey`
mscsInstaller="${BINARIES_FOLDER}/mscs/${mysql_version}/*.zip"
#em_version=`echo $cloudKey_EM | cut -d / -f 2`
#em_zip_file="${BINARIES_FOLDER}/mscs_em/${em_version}/*.zip"
em_agent_zip_file="${BINARIES_FOLDER}/mscs_em_agent/${em_version}/*.zip"


#MEB option as selected by user
meb_option=`getAttribute /userdata/msaas_enterprise_backup`

#replication
mysql_bin_log_dir=${data_dir}/binlogs
mysql_bin_log=${data_dir}/binlogs/mysql01-bin

#MEM required or not
em_required=`getAttribute /userdata/msaas_enterprise_monitor`

#create instance from userbackup
create_instance_from_backup=`getAttribute /userdata/msaas_user_backup_dump_type`
create_instance_dump_path=`getAttribute /userdata/msaas_user_backup_dump_path`

#Cloned service
snapshot_name=`getAttribute /snapshot_name`
snapshot_source_name=`getAttribute /source_service_name`

#Initialize logger with log file and home and initial message
mkdir -p $msaas_home
chown -R $SYS_USER:$SYS_USER $msaas_home
createFile $log_file $log_home $SYS_USER
launchLogger $log_file "Starting continue-service-start.sh"

#Calling provisioning function
echo "Going to do mysql provisioning steps. see log at: $log_file "
log START "MSaaS provisioning"

declare -a cleanup_objects

operation="Mounting storage volumes"
operator start "$operation"
echo $operation "start" > $DEBUG_LOG

bin_home=`getAttribute /storage_map/bin/mountpoint`
bin_device=`getAttribute /storage_map/bin/device`
data_home=`getAttribute /storage_map/data/mountpoint`
data_device=`getAttribute /storage_map/data/device`

#Check for latency volume is mounted or not.
latency_volume_found=1
mysql_log_home=`getAttribute /storage_map/MySQLlog/mountpoint`
if test $? -ne 0; then log Warning "Latency volume mountpoint attribute is not available"; latency_volume_found=0; fi
mysql_log_device=`getAttribute /storage_map/MySQLlog/device`
if test $? -ne 0; then log Warning "Latency volume device attribute is not available"; latency_volume_found=0; fi

if [ "$meb_option" == "BOTH" ]; then
    backup_home=`getAttribute /storage_map/backup/mountpoint`
    backup_device=`getAttribute /storage_map/backup/device`
fi

# setting Error status
status=1
doTask "mountStorageVolume $bin_home $bin_device bin" "log"
if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
doTask "mountStorageVolume $data_home $data_device data" "log"
if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
if [ "$meb_option" == "BOTH" ]; then
    doTask "mountStorageVolume $backup_home $backup_device backup" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
fi

if test $latency_volume_found -eq 1; then
    doTask "mountStorageVolume $mysql_log_home $mysql_log_device log" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
else
    log ERROR "Couldnot find translog volume"
    log ERROR "operation $operation failed" 
    log FINISH "$operation"
    makeExit $status;
fi

#change permission of volumes
doTask "chown $SYS_USER:$SYS_USER $bin_home" "log"
if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
doTask "chown $SYS_USER:$SYS_USER $data_home" "log"
if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
if [ "$meb_option" == "BOTH" ]; then
    doTask "chown $SYS_USER:$SYS_USER $backup_home" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
fi
if test $latency_volume_found -eq 1; then
    doTask "chown $SYS_USER:$SYS_USER $mysql_log_home" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
else
    log ERROR "Couldnot find translog volume"
    log ERROR "operation $operation failed" 
    log FINISH "$operation"
    makeExit $status;
fi
operator stop "$operation"

if [ "${start_mode}" != "CLONE" ] ; then

    #Normal provisioning
    log "Normal provisioning"

    ##setEnviornments
    operation="Setting environment"
    operator start "$operation"


    base_dir="${bin_home}/mysql"
    mysql_bin_dir=${base_dir}/bin
    bash_login_template=$DIR/config/bash-login.template

    export PATH=$mysql_bin_dir:$PATH
    export MYSQL_HOME=$base_dir
    export MYSQL_UNIX_PORT=$MYSQL_HOME/mysql.sock
    runuser -l $SYS_USER -c "echo export PATH=$PATH >> ~/.bashrc"
    runuser -l $SYS_USER -c "echo export MYSQL_HOME=$MYSQL_HOME >> ~/.bashrc"
    runuser -l $SYS_USER -c "echo export MYSQL_UNIX_PORT=$MYSQL_HOME/mysql.sock >> ~/.bashrc"
    #uninstallMysqlLib
    createBannerForOpc "/home/opc/.bash_login" $bash_login_template $SYS_USER
    #changing the service script permissions to 750
    chmod 750 -R $service_tools_home
    operator stop "$operation"

    # pausing debg logging before going to fetch sensitive data(dbname)
    set +x
    # do Parameter Validations
    operation="Validations"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    db_name=`getAttribute /userdata/msaas_db_name`
    #TODO add checknull here depending on status move on
    if test -z $db_name; then
        log ERROR "provided db_name is null, not created any database"
        log ERROR "Provisioning Failed"
        makeExit 1
    fi
    # check is db name is a key word
    is_db_name_in_keywords $db_name
    if test $? -eq 0; then 
        log ERROR "db_name: $db_name is a keyword, Validation failed "; return 1;
        log ERROR "Provisioning Failed"
        makeExit 1
    fi
    operator stop "$operation"

    #starting debug logging again
    set -x

    ##do preinstallation steps
    operation="Preinstallation"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG

    msaasInstallerExtractLocation=/tmp/msaas-installers

    mebInstaller=${msaasInstallerExtractLocation}/meb/*.zip
    storage_container=`getAttribute /storageContainer`
    cloudKey_mscs=`getAttribute /artifacts/MSAAS/cloudKey`

    if test -e $mscsInstaller; then 
        log "Found MSCS installer in machine image at $mscsInstaller"
    else
        log "Not Found MSCS installer in machine image at $mscsInstaller"
        mkdir -p ${BINARIES_FOLDER}/mscs/${mysql_version}
        mscsInstaller="${BINARIES_FOLDER}/mscs/${mysql_version}/mscs_installer.zip"
        doTask "fetchArtifact $mscsInstaller $storage_container $cloudKey_mscs" "log"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    fi
    doTask "extractZipArtifact $mscsInstaller  $msaasInstallerExtractLocation $SYS_USER" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    operator stop "$operation"

    operation="Mysql Installation"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG

    old_mysql=""
    mysqlInstaller=${msaasInstallerExtractLocation}/mysql/*.tar.gz

    new_mysql=$(extractMysql $mysqlInstaller $mysql_version $bin_home $SYS_USER)
    if ! test $? -eq 0; then log ERROR "Failed to extract mysql "; log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit 1; fi
    doTask "changeSoftLink $base_dir \"$old_mysql\" $new_mysql" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "chown $SYS_USER:$SYS_USER $bin_home" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi

    data_dir="${data_home}/mysql"
    mysql_conf_template=$DIR/config/mysql-cnf.template
    mysql_notallowed_user_properties=$DIR/config/notallowed.properties
    mysql_conf_file=$base_dir/$MYSQL_CONF_FILE
    mysql_log_dir=$mysql_log_home/inno-bin-logs

    #user options
    msaas_mysql_variables=`getAttribute /userdata/msaas_mysqlVariables`
    #converttosemicolon seperated
    msaas_mysql_variables=$(echo $msaas_mysql_variables | tr -d ' ')
    msaas_mysql_variables=$(echo $msaas_mysql_variables | tr ',' ';')


    doTask "configureOS $OS_OPEN_FILE_LIMIT" "log"
    doTask "configureMysql $mysql_conf_file $data_dir $base_dir $SYS_USER $mysql_conf_template $host_name $mysql_log_dir $msaas_mysql_variables $mysql_notallowed_user_properties" "log" 
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "initializeMysql $base_dir $data_dir $SYS_USER $mysql_conf_file $mysql_log_dir" "log"
    if test $? -ne 0; then
        log ERROR "operation $operation failed";
        err_message=`getMysqlError $ERROR_LOG`
        message=("$err_message");
        log ERROR  "$err_message"
        log FINISH "$operation";
        makeExit $status "${message[@]}";
    fi
    #if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    export USER=root
    doTask "startMysql $SYS_USER" "log"
    if test $? -ne 0; then
        log ERROR "operation $operation failed";
        err_message=`getMysqlError`
        message=("$err_message");
        log ERROR  "$err_message"
        log FINISH "$operation";
        makeExit $status "${message[@]}";
    fi
    #if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "waitForMysqlToStart 3 10 oracle" "log"
    if test $? -ne 0; then
        log ERROR "operation $operation failed";
        err_message=`getMysqlError`
        message=("$err_message");
        log ERROR  "$err_message"
        log FINISH "$operation";
        makeExit $status "${message[@]}";
    fi
    #if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "copyMysqlServerFile $base_dir $data_dir" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    restrictMysqlAccess $base_dir 
    operator stop "$operation"

    # stoping debug for operation with sensitive data
    set +x

    operation="Mysql Configuration"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    isMaster=$(isAdmin)
    pwd_file=$ADMIN_CRED_FILE

    createDatabase "$db_name" $isMaster
    if test $? -eq 1; then
        log ERROR "create database operation failed"
        log ERROR "Provisioning Failed"
        makeExit 1
    fi
    log START "Mysql timezone configuration"
    doTask "configureMysqlTimezone $mysql_conf_file" "log"
    if test $? -ne 0; then log ERROR "Mysql timezone configuration failed"; log ERROR "Provisioning Failed"; makeExit 1; fi
    log FINISH "Mysql timezone configuration"

    doTask "waitForCredentialFile $ADMIN_CRED_FILE $isMaster 10 2" "log"

    log START "Mysql User configuration"
    dbuser_name=$(getMysqlUserNameFromCredFile $sys_user_home)
    db_password=$(getMysqlPasswordFromCredFile $sys_user_home)
    mem_manager_name=$(getMemManagerUserNameFromCredFile $sys_user_home)
    mem_manager_password=$(getMemManagerPasswordFromCredFile $sys_user_home)
    mem_agent_name=$(getMemAgentUserNameFromCredFile $sys_user_home)
    mem_agent_password=$(getMemAgentPasswordFromCredFile $sys_user_home)

    #create instance from backup
    user_backup_storage_uname=$(getUserBackupStorageUnameFromCredFile $sys_user_home)
    user_backup_storage_upassword=$(getUserBackupStorageUpasswordFromCredFile $sys_user_home)


    #Activate validate password plugin
    activateValidatePasswordPlugin

    #TODO Checknull here
    if test -z $db_password; then log ERROR "db_password is null"; log ERROR "Provisioning Failed"; makeExit 1; fi
    if test -z $dbuser_name; then log ERROR "db userame is null"; log ERROR "Provisioning Failed"; makeExit 1; fi
    if [ $isMaster -eq 1 ]; then
        doTask "mysqlUserCreation $dbuser_name $db_password"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        doTask "createAuthUser $SYS_USER $dbuser_name $db_password"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    fi
    shred -vzn 3 $pwd_file
    rm -rf $pwd_file
    rm -rf $SEMAPHORE_FILE
    log FINISH "Mysql User configuration"
    #starting debug logging again after sensitive data operations
    set -x

    doTask "configureMysqlDb $SYS_USER $vm_script_home" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "createMysqlClientConfigurationFile $mysql_client_conf_file $SYS_USER $base_dir" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    operator stop "$operation"

    #MEB installation
    operation="Enterprise Backup installation"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    meb_install_location=$bin_home
    doTask "installMEB $mebInstaller $meb_install_location $SYS_USER" "log"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    operator stop "$operation"


    # stoping debug loging 
    set +x

    #Downloading Enterprise monitor binaries
    log START "Enterprise Monitor installation"


    #Installing and Configuring Emterprise Monitor
    em_zip_file=${msaasInstallerExtractLocation}/mem/*.zip
    if [ $em_required == "Yes" ]; then
        if [ -f $em_zip_file ]; then
            log "Found Enterprise Monitor installer at $em_zip_file."
        else
            log "ERROR" "Not Found Enterprise Monitor installer at $em_zip_file."
            makeExit 1
            #em_zip_file=${msaasInstallerExtractLocation}/mem/em.zip
            #mkdir -p ${msaasInstallerExtractLocation}/mem/
            #doTask "downloadEnterpriseMonitor $em_zip_file $cloudKey_EM $storage_container $SYS_USER" "log"
            #if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        fi

        em_installer_dir=${msaasInstallerExtractLocation}/mem/
        em_option_file=${msaasInstallerExtractLocation}/mem/em_options.txt
        doTask "createEnterpriseMonitorOption $em_option_file $bin_home $dbuser_name $db_password $mysql_port $SYS_USER"
        doTask "installEnterpriseMonitor $em_installer_dir $bin_home $em_option_file $SYS_USER" "log"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        doTask "configureEnterpriseMonitor $mem_manager_name $mem_manager_password $mem_agent_name $mem_agent_password $SYS_USER" 
    else
        log "Skipping MEM Manager installation and going ahead with agent configuration"
        if [ -f $em_agent_zip_file ]; then
                log "Found Enterprise Monitor agent installer at $em_agent_zip_file."
            else
                log  "Not Found Enterprise Monitor agent installer at $em_agent_zip_file."
               # em_agent_zip_file=${BINARIES_FOLDER}/mscs_em_agent/${em_version}/em_agent.zip
               #mkdir -p ${BINARIES_FOLDER}/mscs_em_agent/${em_version}/
               # doTask "downloadEnterpriseMonitor $em_agent_zip_file $cloudKey_EM_agent $storage_container $SYS_USER"
               # if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        fi

    fi
    rm -rf $msaasInstallerExtractLocation
    log FINISH "Enterprise Monitor installation"

    #starting debug logging again after sensitive data operations
    set -x


    #Create cron job for purge
    log START "Create cron job for purge"
    binlog_dir="${mysql_bin_log_dir}"
    purge_cron_exec=mscs-cron.sh
    purge_task_template=$DIR/config/mscs-purge.txt.template
    purge_task_file=$base_dir/$MSCS_PURGE_SPEC_FILE
    purge_log_file=$data_dir/mscs_purge.log
    doTask "createMysqlPurgeFromTemplate $purge_task_file $purge_task_template $data_dir $binlog_dir" "log"
    cp $DIR/$purge_cron_exec $mysql_bin_dir
    chown $SYS_USER:$SYS_USER $mysql_bin_dir/$purge_cron_exec
    chown $SYS_USER:$SYS_USER $purge_task_file
    #install the cron job to start everyday at 4am
    (crontab -u $SYS_USER -l; echo "0 4 * * * $mysql_bin_dir/$purge_cron_exec $purge_task_file $purge_log_file") | crontab -u $SYS_USER -
    log FINISH "Create cron job for purge"

    #Add entries for mysql restart in init.d
    log START "Add init.d entries to runlevel scripts for start/shutdown of mysqld during VM shutdown/restart"
    chkconfig --list $SERVICENAME >/dev/null
    if test $? -ne 0; then
        SERVICENAMEFILE="/etc/init.d/$SERVICENAME"
        SCRIPTFILE="$DIR/mysql-vm-stop-start-script.sh"
        doTask "createInitRunlevelEntries $SERVICENAMEFILE $SCRIPTFILE $SERVICENAME $LOCKFILE $DIR" "log"
        status=$?
        if test $? -ne 0; then log ERROR "operation createInitRunlevelEntries failed"; log FINISH "createInitRunlevelEntries"; makeExit $status; fi
    fi
    log FINISH "Add init.d entries to runlevel scripts for start/shutdown of mysqld during VM shutdown/restart"

    #create instance from backup
    #log "create_instance_from_backup $create_instance_from_backup"
    #log "create_instance_dump_path $create_instance_dump_path"
    #log "user_backup_storage_uname $user_backup_storage_uname"
    #log "user_backup_storage_upassword $user_backup_storage_upassword"

    if [ $create_instance_from_backup == "Yes" ];  then
       log START "Starting MySQL instance creation from backup."
       operation="Mysql instance creation"
       #check if the backup path is abosolute
       #protocol=`echo ${create_instance_from_backup%%:/*}|awk '{print toupper($0)}'`
       protocol=`echo ${create_instance_dump_path%%:/*}|awk '{print toupper($0)}'`
       if [ $protocol != "HTTPS" -a $protocol != "HTTP" ]; then
          #https://storage.oraclecorp.com/v1/Storage-StorageEval01admin/JaaSProvisioning
          storage_url_without_container=${storage_container%/*}      
          #https://storage.oraclecorp.com/v1/Storage-StorageEval01admin
          storage_url_without_domain=${storage_url_without_container%/*}      
          #https://storage.oraclecorp.com/v1
          create_instance_dump_path=$storage_url_without_domain/$create_instance_dump_path
       fi
       log "Backup path $create_instance_dump_path"

       #check if backup enabled
       backup_enabled='False'
       if [ "$meb_option" == "BOTH" ]; then
          backup_enabled='True'
       fi
          
       #create json
       json_str="{ \"backupType\":\"$create_instance_from_backup\", \"backupPath\":\"$create_instance_dump_path\", \"dumpCloudUser\":\"$user_backup_storage_uname\",\"dumpCloudUserPassword\":\"$user_backup_storage_upassword\" , \"backupEnabled\":\"$backup_enabled\"}"

       #create json file
       json_file="/tmp/input.$$.json"
       echo $json_str > $json_file

       chown $SYS_USER:$SYS_USER $json_file
       doTask "createInstanceFromBackup $json_file $DIR $SYS_USER"
       if test $? -ne 0; then 
          log ERROR "operation $operation failed"; 
          err_message=`cat /tmp/create_instance_from_backup.err`
          message=("$err_message"); 
          log ERROR  "$err_message"
          log FINISH "$operation"; 
          makeExit $status "${message[@]}"; 
       fi
       operation="Forced user setup"
       message=("at user setup")
       doTask "mysqlForcedUserSetup $dbuser_name $db_password $SYS_USER $DIR/mysql-installation-utils.sh $mysql_log_dir $base_dir $data_dir"
       if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status "${message[@]}"; fi
       #cleanup the backup history
       runuser -l $SYS_USER -c "mysql -u$SYS_USER -e'TRUNCATE TABLE mysql.backup_history;'"
       runuser -l $SYS_USER -c "mysql -u$SYS_USER -e'TRUNCATE TABLE mysql.backup_progress;'"
       log FINISH "MySQL instance creation"
    fi

    #tight the security
    runuser -l $SYS_USER -c "chmod 600 $data_dir/*.pem"
    runuser -l $SYS_USER -c "chmod 600 $base_dir/*.pem"

else
    #For cloned service,
    # 1. start mysqld for automatic recovery, if not started already
    # 2. update some parameters
    # 3. remove old backups

    log "Cloned from snapshot: $snapshot_name; source service: $snapshot_source_name."

    base_dir="${bin_home}/mysql"
    data_dir="${data_home}/mysql"
    mysql_log_dir=$mysql_log_home/inno-bin-logs
    export MYSQL_HOME=$base_dir

    operation="Start Mysql"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    export USER=root
    export CLONE=yes
    mysql_status=$(getMysqlStatus $SYS_USER)
    if [ $mysql_status -eq 1 ] ; then
        doTask "startMysql $SYS_USER"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        # wait a little longer because recovery may take some time
        doTask "waitForMysqlToStart 3 40 $SYS_USER"
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    fi
    operator stop "$operation"

    operation="Update Mysql Configuration File"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    mysql_conf_file=$base_dir/$MYSQL_CONF_FILE
    doTask "updateMysqlDynamicParameters $mysql_conf_file $mysql_log_dir $host_name $SYS_USER"
    #remove auto.cnf under data directory. server will re-generate server-uuid
    rm -f ${data_dir}/auto.cnf
    operator stop "$operation"

    #restart mysqld to pickup configuration changes
    operation="Restart Mysql"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    doTask "bounceMysql $SYS_USER"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    doTask "waitForMysqlToStart 3 10 $SYS_USER"
    if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    operator stop "$operation"

    # stoping debug loging 
    set +x

    operation="Mysql User Configuration"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    isMaster=$(isAdmin)
    pwd_file=$ADMIN_CRED_FILE
    doTask "waitForCredentialFile $ADMIN_CRED_FILE $isMaster 10 2"

    dbuser_name=$(getMysqlUserNameFromCredFile $sys_user_home)
    db_password=$(getMysqlPasswordFromCredFile $sys_user_home)
    source_dbuser_name=`getAttribute /userdata/msaas_source_user_name`

    if test -z $db_password; then log ERROR "db_password is null"; log ERROR "Provisioning Failed"; makeExit 1; fi
    if test -z $dbuser_name; then log ERROR "db userame is null"; log ERROR "Provisioning Failed"; makeExit 1; fi
    if [ $isMaster -eq 1 ]; then
        mysqlUserCreation $dbuser_name $db_password $SYS_USER $source_dbuser_name
        if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
    fi
    shred -vzn 3 $pwd_file
    rm -rf $pwd_file
    rm -rf $SEMAPHORE_FILE
    operator stop "$operation"

    #starting debug logging again after sensitive data operations
    set -x


    operation="Mysql backup directory"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    backup_home=`getAttribute /storage_map/backup/mountpoint`
    if test $? -eq 0; then
        if [ -d "$backup_home" ]; then
            doTask "rm -rf $backup_home"
        fi

        if [ "$meb_option" == "BOTH" ]; then
            mkdir -p $backup_home
            chown $SYS_USER:$SYS_USER $backup_home
            if test $? -ne 0; then log ERROR "operation $operation failed"; log FINISH "$operation"; makeExit $status; fi
        fi
    fi
    runuser -l $SYS_USER -c "mysql -u$SYS_USER -e'TRUNCATE TABLE mysql.backup_history;'"
    runuser -l $SYS_USER -c "mysql -u$SYS_USER -e'TRUNCATE TABLE mysql.backup_progress;'"
    operator stop "$operation"

    operation="Cleanup Mysql files"
    operator start "$operation"
    echo $operation "start" > $DEBUG_LOG
    #remove old files associated with source service name
    source_host_name=${snapshot_source_name,,}-mysql-1
    rm -f ${data_dir}/${source_host_name}.*
    rm -f ${data_dir}/audit.log.corrupted.*
    rm -f ${mysql_log_dir}/${source_host_name}.*

    operator stop "$operation"
fi
# cleaning up binaries folder
rm -rf ${BINARIES_FOLDER}
log "cleaned up binaries folder : ${BINARIES_FOLDER}"
log FINISH "MSaaS provisioning"
makeExit 0
