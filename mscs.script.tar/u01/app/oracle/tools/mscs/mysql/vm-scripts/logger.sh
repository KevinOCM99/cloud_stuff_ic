#!/bin/bash
# Logger to log MYsql service #
# function to write the log to file
#launch logger takes log file check for existence add seperation line
#file wrtiter = takes filename?, and text;

logFile=""
level=0
levelDist=""
levelTab="...."

#echo "Took $(($diff / 60)) minutes and $(($diff % 60)) seconds"
declare -A startTime
getTime() {
	export TZ=$(date +%Z)
	timeFormat="%FT%T.%3N%:z"
	echo $(date  +"$timeFormat");
}

writeToLog () {
	logentry=$1
	echo $logentry >> $logFile
}

#
# fuction to make log entry and stdout
#
writeToLogAndStdout() {
	logentry=$1

	echo $logentry
	writeToLog "$logentry"
}

makeEntry () {
	type=$1
	text=$2
	#printf "%s[%s] $getTime: %s\n" $(getTime) $1 $2
	#echo "$(getTime) $levelDist [ $1 ] : $2"
#	printf " %s %s [  %-7.6s%s %s %s %s" $(date "+%s") "..."   $1   "]" ":"
	printf " %s %s %s  %-7.6s%s %s %s %s" $(getTime) "$levelDist" "["$type"]" ":" "$text"
}
makeFinishEntry () {

	entry=$(makeEntry "STAT"  "Took $(($2 / 60)) minutes and $(($2 % 60)) seconds")
	#echo $entry
	writeToLog "$entry"
	entry=$(makeEntry "FINISH"  "$1")
	#echo $entry
	writeToLog "$entry"
}
makeStartEntry () {
	entry=$(makeEntry "START"  "$1")
	#echo $entry
	writeToLog "$entry"
}
startTimer()
{
	startTime[$level]=$(date +"%s")
	#echo "start time of level $level = ${startTime[$level]}"
	currenttime=$(date +"%s")
	diff=$(($currenttime-${startTime[$level]}))
  #echo "diffinStartTimer = $diff"
}
endTimer()
{
	endTime=$(date +"%s")
 	diff=$(($endTime-${startTime[$level]}))
 	echo $diff
}

# for indentation to be worked uncomment levelDist
incrementLevel(){
	level=$((level+1))
	##echo " incremented level= $level"
	#levelDist="$levelDist$levelTab"
	##echo " incremented levelDist= $levelDist"
}

# for indentation to be worked uncomment levelDist calculation
decrementLevel(){
 	level=$((level-1))
	#len=${#levelDist}-${#levelTab}
	#levelDist=${levelDist:0:$len}
	#echo " decremented levelDist= $levelDist"
}

finishOperation() {
	decrementLevel
  timeTaken=$(endTimer)
  makeFinishEntry "$1" $timeTaken
}
startNewOperation() {
  startTimer
	makeStartEntry "$1"
	incrementLevel
}
preprocess () {
	count=1
	while [ $count -le $# ]
		do
			##echo "$count : "
			count=$((count+1))
		done
}
getEntryType () {
	if [ $# -eq 2 ] ; then
		entryType=$1
	else
		entryType="INFO"
  fi
echo $entryType
}

getText () {
	if [ $# -eq 2 ] ; then
		logText=$2
	else
		logText=$1
  fi
echo $logText
}

logLine() {
  writeToLog "$@"
}
 
log() {
#	preprocess $@
	madeEntry=0
  entryType=$(getEntryType "$@")
  text=$(getText "$@")
	if [ $entryType = "START" ] ; then
		startNewOperation "$text"
		madeEntry=1
	fi
	if [ $entryType = "FINISH" ] ; then
		finishOperation "$text"
		madeEntry=1
	fi
	if [ $madeEntry -eq 0 ] ; then
	#	echo "text = $text"
 	 	entry=$(makeEntry $entryType "$text")
		#entry="$(getTime) $entryType : $text"
		##echo $entry
		writeToLog "$entry"
	fi
}

#
# function to log in log file and stdout (for patching services)
#
log2() {
#	preprocess $@
	madeEntry=0
  entryType=$(getEntryType "$@")
  text=$(getText "$@")
	if [ $entryType = "START" ] ; then
		startNewOperation "$text"
		madeEntry=1
	fi
	if [ $entryType = "FINISH" ] ; then
		finishOperation "$text"
		madeEntry=1
	fi
	if [ $madeEntry -eq 0 ] ; then
	#	echo "text = $text"
 	 	entry=$(makeEntry $entryType "$text")
		#entry="$(getTime) $entryType : $text"
		##echo $entry
		writeToLogAndStdout "$entry"
	fi
}

launchLogger() {
	logFile=$1
	message=$2
	if [ ! -f $logFile ]; then
		touch $logFile
	fi
	writeToLog "*****............$message............*****"
	
}

useExistingLog() {
		logFile=$1
		
}

