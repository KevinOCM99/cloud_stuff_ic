#!/bin/bash
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
#
# This script  contains functions do the pre installation and configuration for Mysql
#

# Setting logger for this util functions - check for log command in environment,
#     use local log if not found

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#import
source $DIR/constants.sh
source $DIR/msaas-provisioning-utils.sh

log_command=log_local
type log > /dev/null 2> /dev/null
status=$?
if test $status -eq 0; then
    log_command=log
fi

getTime() {
    export TZ=$(date +%Z)
    timeFormat="%FT%T.%3N%:z"
    echo $(date  +"$timeFormat");
}

makeEntry () {
    type=$1
    text=$2
    if test $type == 'PLAIN'; then
        echo "$text"
    else
        printf " %s %s %s  %-7.6s%s %s %s %s" $(getTime) "$levelDist" "["$type"]" ":" "$text"
    fi
}

getEntryType () {
    if [ $# -eq 2 ] ; then
        entryType=$1
    else
        entryType="INFO"
    fi
echo $entryType
}

getText () {
    if [ $# -eq 2 ] ; then
        logText=$2
    else
        logText=$1
  fi
echo $logText
}

log_local(){
    entry_type=$(getEntryType "$@")
    text=$(getText "$@")

    log_entry=$(makeEntry $entry_type "$text")
    if test $entry_type == 'PLAIN'; then
        echo "   $log_entry"
    else
        echo $log_entry
    fi
}

#executes the sql statements given in the sql_file
executeSql(){
    sql_file=$1
    sys_user=$2
    delete=$3

    runuser -l $sys_user -c "cat $sql_file | mysql -u$sys_user"
    status=$?
    if test $delete -eq 1; then
        shred -vzn 3 $sql_file
        rm -rf  $sql_file
    fi
    return $status
}

#executes the sql statements given in the sql_file for current user.
#normal user does not have permission to run "runuser"
executeSqlForCurrentUser(){
    sql_file=$1
    sys_user=$2
    delete=$3

    mysql -u$sys_user < $sql_file
    status=$?
    if test $delete -eq 1; then
        shred -vzn 3 $sql_file
        rm -rf  $sql_file
    fi
    return $status
}

#read key:value pairs from a file; return the value associated with a key
getAssociatedValue() {
    declare -A array_key_value

    key_value_file=$1
    my_key=$2
    my_value=""

    while read line || [[ -n $line ]]; do
        if [[ ${line:0:1} != '#' ]]; then
            one_key=`echo $line | cut -s -d':' -f1`
            if [ -n "$one_key" ]; then
                one_value=`echo $line | cut -d':' -f2-`
                array_key_value["$one_key"]="$one_value"
            fi
        fi
    done < $key_value_file

    if [[ ${array_key_value[$my_key]} ]]; then
        my_value=${array_key_value[$my_key]};
    fi

    echo "$my_value"
}

#creat mysql configuration file from given template file
createMysqlConfFromTemplate() {
    mysql_conf_file=$1
    mysql_cnf_template=$2
    data_dir=$3
    base_dir=$4
    innodb_buff_pool_size=$5
    innodb_buff_pool_instances=$6
    innodb_flush_neighbours=$7
    innodb_iops_capacity=$8
    innodb_iops_max_capacity=$9
    host_name=`echo ${10}`
    sys_user=`echo ${11}`
    mysql_log_dir=`echo ${12}`

    component_name=`getAttribute /artifacts/SERVICE_TOOLS`
    tools_root=`getAttribute /toolsRoot`
    service_tools_home=${tools_root}/${component_name}
    default_collation_file=${service_tools_home}/${MYSQL_DEFAULT_COLLATION_FILE}
    collation_to_charset_file=${service_tools_home}/${MYSQL_COLLATION_TO_CHARSET_FILE}

    # Get server charset and collation
    mysql_charset=`getAttribute /userdata/msaas_charset`
    mysql_collation=`getAttribute /userdata/msaas_collation`
    if [ "$mysql_collation"  == "null" ] || [ "$mysql_collation" == "${NOT_FOUND}" ] ; then
        # Server collation is not set, get the default one
        mysql_collation=$( getAssociatedValue $default_collation_file $mysql_charset )
    else
        old_collation=$mysql_collation
        one_charset=$( getAssociatedValue $collation_to_charset_file $mysql_collation )
        if [ "$one_charset" != "$mysql_charset" ]; then
            mysql_collation=$( getAssociatedValue $default_collation_file $mysql_charset )
            $log_command ERROR "Server collation $old_collation is not valid for character set $mysql_charset; use the default collation $mysql_collation."
        fi
    fi

    #TODO remove below steps of assignment
    innodb_iops_capacity=200
    innodb_iops_max_capacity=400

    mysql_port=`getAttribute /userdata/msaas_admin_port`
    timezone=`getAttribute /userdata/msaas_timezone`
    if test $? -ne 0; then timezone=SYSTEM; fi

    #sed -n 's/\$base_dir/${base_dir}/gpw $mysql_conf_file' $mysql_cnf_template
    #TODcurl 192.0.0.192/latest/meta-data/instance-type
     while read line
     do
         if [[ ${line:0:1} == '#' ]]
        then
            echo "$line" >> $mysql_conf_file
        else
             eval echo "$line" >> $mysql_conf_file
         fi
     done < "$mysql_cnf_template"
}


#creat mysql purge task file from given template file
createMysqlPurgeFromTemplate() {
    purge_task_file=$1
    purge_task_template=$2
    data_dir=$3
    binlog_dir=$4

     while read line
     do
        if [[ ${line:0:1} == '#' ]]
        then
            echo "$line" >> $purge_task_file
        else
            eval echo "$line" >> $purge_task_file
         fi
     done < "$purge_task_template"
}


#function to calculate innodb buffer poolsize
calculateInnodbBuffPoolSize (){
    system_ram=$1
    pool_size=$((system_ram - 1024))

    pool_size=$([ $((system_ram*75/100))  -lt $pool_size ] && echo $(( system_ram*75/100 ))|| echo $pool_size)
    echo $pool_size
}

#function to calculate calculateInnodbBuffPoolInstances
calculateInnodbBuffPoolInstances(){
    pool_size=$1
    divider=32768;
    case $((pool_size/$divider)) in 
        0) echo 8
        ;;
        1) echo 16
        ;;
        *) echo 32
        ;;
    esac
}

#Sanitize the userinout properties
parseAndSanitizeUserVariables(){
   user_properties=$1
   notallowed_properties_file=$2
   sanitized_user_variables=""
   #replace ; with spaces
   $log_command  INFO "parseAndSanitizeUserVariables() user_properties $user_properties"
   singlespaced_user_properties=$(echo "$user_properties" | tr ';' ' ')   
   $log_command  INFO "parseAndSanitizeUserVariables() singlespaced_user_properties $singlespaced_user_properties"

   for keyvalue in $singlespaced_user_properties; do
     key=${keyvalue%%=*}
     value=${keyvalue##*=}
     $log_command  INFO "parseAndSanitizeUserVariables() key value notallowed_properties_file  $key $value $notallowed_properties_file"
     
     if [[ ! -z $value && ! -z $key ]]; then
        if [[ "$value" != "null" && "$value" != "metadatanotfoUnd" ]]; then  
           if ! grep --quiet ^$key $notallowed_properties_file; then
              sanitized_user_variables="$sanitized_user_variables $key=$value"
           else
              $log_command  INFO "Skipping $key=$value, not an user configurable property."
           fi
        fi
     fi
   done 
   echo $sanitized_user_variables
}

#insert a line after a specific line in a file
insertAfterSection(){
   file="$1" 
   new_line_to_insert="$2" 
   specific_line="$3" 
   $log_command INFO "insertAfterSection() file new_line_to_insert specific_line $file $new_line_to_insert $specific_line"
   sed -i -e "/^$specific_line$/a"$'\\\n'"$new_line_to_insert"$'\n' "$file"
}

#Add properties to mycnf file
addUserVariablesToCNF(){
   mysql_conf_file="$1"
   sanitized_user_variables="$2"
   mycnf_section="$3"
   for keyvalue in $sanitized_user_variables; do
       key=${keyvalue%%=*}
       value=${keyvalue##*=}
       line_to_insert="$key=$value" 
       insertAfterSection $mysql_conf_file $line_to_insert $mycnf_section
       $log_command INFO "insertAfterSection() file new_line_to_insert specific_line $mysql_conf_file $line_to_insert $mycnf_section"
   done
}

#Create configuration file and data directory
configureMysql(){
    mysql_conf_file=$1
    data_dir=$2
    base_dir=$3
    sys_usr=$4
    mysql_cnf_template=$5
    hostname=$6
    mysql_log_dir=$7

    mysql_user_variables=$8
    notallowed_properties_file=$9
    #sanitize
    $log_command  INFO "configureMysql() user properties $mysql_user_variables"
    sanitized_user_variables=`parseAndSanitizeUserVariables "$mysql_user_variables" $notallowed_properties_file`
    $log_command  INFO "configureMysql() sanitized_user_properties $sanitized_user_variables"

    system_ram=`getSystemRamInMB`
    #Enviornment setup 
    #temp need toremove my.cnf from image
    if [ -f /etc/my.cnf ]; then
        mv /etc/my.cnf /etc/my.cnf.old
    fi
    #Create Data Directory
    mkdir $data_dir
    /bin/chown -R $sys_usr:$sys_usr $data_dir
    chmod 700 $data_dir
    innodb_buff_pool_size_in_MB=`calculateInnodbBuffPoolSize $system_ram`
    innodb_buff_pool_instances=`calculateInnodbBuffPoolInstances $innodb_buff_pool_size_in_MB`
    innodb_buff_pool_size=$((innodb_buff_pool_size_in_MB/1000))G
    #Create configuration file
    createMysqlConfFromTemplate $mysql_conf_file $mysql_cnf_template $data_dir $base_dir $innodb_buff_pool_size $innodb_buff_pool_instances 0 200 400 $hostname $sys_usr $mysql_log_dir
    # echo [mysqld] > $mysql_conf_file
    # echo datadir=${data_dir} >> $mysql_conf_file
    # echo basedir=${base_dir} >> $mysql_conf_file

    #add user varibales to my.cnf
    if [[ ! -z $sanitized_user_variables ]]; then
       addUserVariablesToCNF "$mysql_conf_file" "$sanitized_user_variables" "\[mysqld\]"   
    fi

    chmod 600 $mysql_conf_file
    chown $sys_usr $mysql_conf_file
    return $?
}

#Update configuration file
updateMysqlDynamicParameters(){
    mysql_conf_file=$1
    mysql_log_dir=$2
    host_name=$3
    sys_usr=$4

    # reload system timezone info to mysql table
    runuser -l $sys_user -c "mysql_tzinfo_to_sql $TIMEZONE_INFO_FOLDER | mysql mysql"

    if [ -f $mysql_conf_file ]; then
        mv $mysql_conf_file ${mysql_conf_file}.old
    fi

    system_ram=`getSystemRamInMB`
    innodb_buff_pool_size_in_MB=`calculateInnodbBuffPoolSize $system_ram`
    innodb_buff_pool_instances=`calculateInnodbBuffPoolInstances $innodb_buff_pool_size_in_MB`
    innodb_buff_pool_size=$((innodb_buff_pool_size_in_MB/1000))G
    mysql_port=`getAttribute /userdata/msaas_admin_port`
    timezone=`getAttribute /userdata/msaas_timezone`
    if test $? -ne 0; then timezone=SYSTEM; fi

    #Update configuration file
    while read line
     do
        if [[ $line == innodb-buffer-pool-size* ]]
        then
            eval echo "innodb-buffer-pool-size=$innodb_buff_pool_size" >> $mysql_conf_file
            $log_command "Update innodb-buffer-pool-size to $innodb_buff_pool_size."
        elif [[ $line == innodb-buffer-pool-instances* ]]
        then
            eval echo "innodb-buffer-pool-instances=$innodb_buff_pool_instances" >> $mysql_conf_file
            $log_command "Update innodb-buffer-pool-instances to $innodb_buff_pool_instances."
        elif [[ $line == log-bin=* ]]
        then
            eval echo "log-bin=${mysql_log_dir}/${host_name}" >> $mysql_conf_file
            $log_command "Update log-bin to ${mysql_log_dir}/${host_name}."
        elif [[ $line == port=* ]]
        then
            eval echo "port=${mysql_port}" >> $mysql_conf_file
            $log_command "Update mysql server port to ${mysql_port}."
        elif [[ $line == default-time-zone=* ]]
        then
            eval echo "default-time-zone=${timezone}" >> $mysql_conf_file
            $log_command "Update mysql server timezone to ${timezone}."
        else
            echo "$line" >> $mysql_conf_file
        fi
     done < "${mysql_conf_file}.old"

    #cleanup
    if [ -f ${mysql_conf_file}.old ]; then
        rm ${mysql_conf_file}.old
    fi

    chmod 600 $mysql_conf_file
    chown $sys_usr:$sys_usr $mysql_conf_file
    return $?
}

#Configure MySQL timezone
#   load system timezone info to mysql table
#   update global server time zone value at runtime
#   update my.cnf file
configureMysqlTimezone(){
    mysql_conf_file=$1

    # load system timezone info to mysql table
    mysql_tzinfo_to_sql $TIMEZONE_INFO_FOLDER | mysql mysql
    status=$?

    timezone=`getAttribute /userdata/msaas_timezone`
    if test $? -ne 0; then timezone=SYSTEM; fi

    # set the global server time zone value at runtime 
    echo "SET GLOBAL time_zone = '${timezone}';" | mysql

    if [ -f $mysql_conf_file ]; then
        mv $mysql_conf_file ${mysql_conf_file}.old
    fi

    # update configuration file
    while read line
     do
        if [[ $line == default-time-zone* ]]
        then
            eval echo "default-time-zone=$timezone" >> $mysql_conf_file
            $log_command "Update default-time-zone to $timezone."
        else
            echo "$line" >> $mysql_conf_file
        fi
     done < "${mysql_conf_file}.old"

    #cleanup
    if [ -f ${mysql_conf_file}.old ]; then
        rm ${mysql_conf_file}.old
    fi

    return $status
}

#Extract Mysql tar
# extractMysql() {
#     bin_home=$1
#     mysqlTarFile=$2
#     sys_user=$3

#     cd $bin_home
#     tar zxvf ${mysqlTarFile}
#     ln -s ${bin_home}/mysql* mysql
#     log "    Extracted \"${mysqlTarFile}\" to \"${bin_home}/mysql\""
#     /bin/chown -R $sys_user:$sys_user ${bin_home}
# }

extractMysql(){
mysqlInstaller=$1
zipVersion=$2
extractLocation=$3
SYS_USER=$4

new_mysql=$extractLocation/mysql-$zipVersion
extract_status=$(extractTarGzArtifact $mysqlInstaller $extractLocation $SYS_USER)
status=$?
extractedTarFolderName=$(tar tzf $mysqlInstaller | sed -e 's@/.*@@' | uniq)
extractedTarFolder=$extractLocation/$extractedTarFolderName
mv $extractedTarFolder $new_mysql
result=$?
((status+=result))
echo "$new_mysql"
return $status
}

#initialize mysql using values in conf file
initializeMysql() {
    base_dir=$1
    data_dir=$2
    sys_user=$3
    conf_file=$4
    mysql_log_dir=$5

    # createsMysqlBinLog directory
    mkdir -p $mysql_log_dir
    chown -R $sys_user:$sys_user ${mysql_log_dir}
    # run mysqlinitialize command as sys_user
    runuser -l $sys_user -c "export MYSQL_HOME=$base_dir; ${base_dir}/bin/mysqld  --initialize-insecure --user=$sys_user"
    status=$?
    chown -R $sys_user . ${data_dir}
    chown -R $sys_user:$sys_user ${mysql_log_dir}
    $log_command "Initialize mysql server status: $status; using system user: $sys_user..."
    return $status
}

#setUPSSL
setUpSSL(){
    mysql_bin_dir=$1
    sys_usr=$2
    data_dir=$3

    runuser -l $sys_user -c "cd $mysql_bin_dir/..; ./bin/mysql_ssl_rsa_setup --datadir=$data_dir"
    return $?
}


#grep error from mysqld error log
getMysqlError(){
    error_file=$1
    base_dir=$MYSQL_HOME
    if [ -z $error_file ]; then
      error_file="$base_dir/../../data/mysql/*.err"
    fi
    echo `grep ERROR $error_file |head -1|cut -d' ' -f4-` 
}


#StartMysql
startMysql(){
    sys_user=$1
    arguments=$2

    result=0
    PID=/tmp/wpid
    base_dir=$MYSQL_HOME
    start_command="cd $base_dir; ./bin/mysqld_safe $arguments > /dev/null 2>&1 & echo $! "

    if ! test -x $base_dir/bin/mysqld_safe;then
        $log_command ERROR "NOT FOUND Executable \"mysqld_safe\" at $base_dir/bin/mysqld_safe "
        result=1
        echo $result
        return 1
    fi

    $log_command "Starting mysqld_safe..."
    if [ $USER == "$sys_user" ]; then
        pid=$(cd $base_dir; ./bin/mysqld_safe $arguments >$base_dir/mysql_start.log  2>$base_dir/mysql_start.err & echo $!; )
    else
        pid=$(runuser -l $sys_user -c "cd $base_dir; ./bin/mysqld_safe $arguments > ./mysql_start.log 2>./mysql_start.err & echo \$! ")
    fi

    # wait for mysqld process
        # log mysql starting output and errors if any
    slept_time=1
    sleep_step=3
    timeout=30
    found_mysqld=0
    sleep 1
    while (( slept_time < timeout && found_mysqld == 0 )); do
        mysqld_safe_pid=`pgrep -u oracle mysqld_safe`
        if test -e $mysqld_safe_pid; then
            $log_command ERROR "mysqld_safe process dead after $slept_time second(s)"
            $log_command INFO  "----mysqld_safe start messages----"
            while read -r line; do
                $log_command PLAIN "$line"
            done < $base_dir/mysql_start.log
            $log_command ERROR  "---- mysql err log ----"
            echo "----last 100 lines of mysql.errror messages----" >> $base_dir/mysql_start.err
            tail -n 100 $base_dir/../../data/mysql/*.err >> $base_dir/mysql_start.err
            while read line || [[ -n "$line" ]]; do
                $log_command PLAIN "$line"
            done < $base_dir/mysql_start.err
            return 1
        else
            mysqld_pid=`pgrep -P $mysqld_safe_pid`
            if test -e $mysqld_pid; then
                $log_command "Waiting for mysqld process to start...sleeping for $sleep_step secs"
                sleep $sleep_step
                slept_time=$((slept_time+sleep_step))
            else
                found_mysqld=1
                $log_command "Found mysqld process after $slept_time seconds"
            fi
        fi
    done


    # log start log created
    $log_command INFO  "----mysqld_safe start messages----"
    while read -r line; do
        $log_command PLAIN "$line"
    done < $base_dir/mysql_start.log
    #log mysql err log
    $log_command INFO  "----mysql.err messages----"
    echo "----last 100 lines of mysql.errror messages----" >> $base_dir/mysql_start.err
    tail -n 100 $base_dir/../../data/mysql/*.err >> $base_dir/mysql_start.err
    while read -r line; do
        $log_command PLAIN "$line"
    done < $base_dir/mysql_start.err
    return 0
}
#get status of mysql with username
getMysqlStatus(){
    sys_user=$1

    if [ "$CLONE" == "yes" ]; then
        runuser -l $sys_user -c "mysqladmin status -u${sys_user} > /dev/null 2>&1"
    elif [ "$USER" == "$sys_user" ]; then
        mysqladmin status -u${sys_user} > /dev/null 2>&1
    else
        mysqladmin status > /dev/null 2>&1
    fi

    if [ $? -ne 0 ] ; then
        echo 1
        return 1
    else
        echo 0
        return 0
    fi
    }

#get mysql version
getMysqlVersion(){
    sys_user=$1

    version=$(mysqladmin -u${sys_user} version | grep "Server version" | cut -d $'\t' -f 3 | cut -d '-' -f 1)
    echo $version
}



#check for pid file
doMySQLPidFileExist(){
  data_home=`getAttribute /storage_map/data/mountpoint`
  data_dir="${data_home}/mysql"
  hostname=$(hostname)
  pidfile="${data_dir}/${hostname}.pid"
  if [ -e "$pidfile" ]; then
     return 0
  else
     return 1
  fi
}

#shutdown Mysql
shutdownMysql(){
    sys_usr=$1
    clean_shutdown=${2:-1}

    $log_command "Going to shutdown mysql..."
    mysql_status=$(getMysqlStatus $sys_usr)
    $log_command "MySQL status $mysql_status"
    if [ $mysql_status -eq 0 ] ; then
        if [ $clean_shutdown -eq 1 ] ; then
            $log_command "Disable MySQL fast shutdown."
            if [ "$CLONE" == "yes" ]; then
                runuser -l $sys_usr -c "mysql -u${sys_usr} --execute='set global innodb_fast_shutdown=0' > /dev/null 2>&1"
            else
                mysql -u${sys_usr} --execute="set global innodb_fast_shutdown=0" > /dev/null 2>&1
            fi
        fi
        if [ "$CLONE" == "yes" ]; then
            runuser -l $sys_usr -c "mysqladmin shutdown -u${sys_usr} > /dev/null 2>&1"
        else
            mysqladmin shutdown -u${sys_usr} > /dev/null 2>&1
        fi
        #wait for shutdown the finish and clean up the pid file
        while doMySQLPidFileExist
        do
          SHUTDOWN_RETRY_COUNT=$((SHUTDOWN_RETRY_COUNT-1))
          sleep $SHUTDOWN_WAIT_TIME
          if [ $SHUTDOWN_RETRY_COUNT -le 0 && doMySQLPidFileExist ]; then
             return 1
          fi
        done
    else
        $log_command "No current mysql process found"
    fi

    return 0
}

#
#Wait for mysql to start with time in seconds and retries count
#$1 : time to wait in seconds
#$2 : maximum retry count
#$3 : authenticated OS user for mysql operations
#

waitForMysqlToStart(){
    sleepTime=$1
    max_retry_count=$2
    sys_user=$3

    $log_command "Waiting to start mysql..."
    sleep $sleepTime
    #((max_retry_count--))
    mysql_status=$(getMysqlStatus ${sys_user})
    count=0

    while (( max_retry_count > count && mysql_status != 0 ))
    do
        ((count++))
        $log_command "Waiting to start mysql...retry-$count"
        sleep $sleepTime
        mysql_status=$(getMysqlStatus ${sys_user})
    done
    if [ $mysql_status -eq 0 ]; then
        $log_command "Mysql Started...after waiting $((count*sleepTime+sleepTime))"
    else
        $log_command "Mysql is not started after waiting $((count*sleepTime+sleepTime)) seconds"
    fi
    echo $mysql_status
    return $mysql_status
}

#run Mysql upgrade
runMysqlUpgrade(){
    base_dir=$1
    mysql_username=$2
    options=$3

    cd $base_dir
    ./bin/mysql_upgrade -u$mysql_username $options > /dev/null 2>&1
    status=$?
    echo $status
}
#Update mysql conf file for replication purpose
updateMysqlConfigurationFile(){
    mysql_conf_file=$1
    mysql_bin_log=$2
    isMaster=$3
    ##Replication configuration
    #Get VM Numbering
    temp_file1=/tmp/temp_file1
    getAttribute /serviceVM > $temp_file1
    countVM=0
    while read LINE
    do
        vmNumbers[countVM]="$LINE"
        ((countVM++))
    done < "$temp_file1"
    rm -f $temp_file1

    #Assign serverIds for Master/Slave
    if [ $isMaster -eq 1 ] ; then
        echo server-id=1 >> $mysql_conf_file
    else
        slave=$(uname -a | awk '{print $2}')
        for i in "${vmNumbers[@]}"
        do  
            host=`getAttribute /serviceVM/$i/hostname`
            if [ "$slave" = ${host,,} ]; then
                echo server-id=$(($i+2)) >> $mysql_conf_file
            fi  
        done
    fi

    echo "log-bin=${mysql_bin_log}" >> $mysql_conf_file
    echo "binlog-format=MIXED" >> $mysql_conf_file
    echo "sync_binlog=1" >> $mysql_conf_file
    echo "max_binlog_size=1073741824" >> $mysql_conf_file
    echo "max_relay_log_size=0" >> $mysql_conf_file
    echo "innodb_flush_log_at_trx_commit=1" >> $mysql_conf_file
    $log_command "Created configuration file for replication"
}

#Create mysql client conf file for $sys_user
createMysqlClientConfigurationFile(){
    mysql_client_conf_file=$1
    sys_user=$2
    mysql_base_dir=$3

    echo "[client]" >> $mysql_client_conf_file
    echo "user=$sys_user" >> $mysql_client_conf_file
    echo "socket=$mysql_base_dir/mysql.sock" >> $mysql_client_conf_file
    $log_command "Created mysql client configuration file"
}

#createsMysqlBinLog directory
createMysqlBinLogDirectory()
{
    mysql_bin_log_dir=$1
    sys_user=$2
    mkdir $mysql_bin_log_dir
    chown -R $sys_user:$sys_user $mysql_bin_log_dir
}

#Mysql replication operations
doMysqlReplicationOperations()
{
    credential_file_admin=$1
    credential_file_ms=$2
    replication_user=$3
    master=$4
    replication_password=$5

    if [ $replication_user != "null" ] ; then
        #to be done on MASTER
        temp_file1=/tmp/temp1.txt
        temp_file2=/tmp/temp2.txt
        if [ $master -eq 1 ]; then
            echo "Adding replication user on MASTER..."
            echo "CREATE USER $replication_user@'%' IDENTIFIED BY '$replication_password';" > $temp_file1
            echo "GRANT REPLICATION SLAVE ON *.* TO '$replication_user'@'%';" >> $temp_file1
            echo "flush privileges;" >> $temp_file1
        else
            #to be done on SLAVE
            #if [ "uname -a | awk '{print $2}' | awk '{print substr($0,length,1)}'"!="1" ]; then
            echo "Adding MASTER configurations on SLAVE..."
            echo "CHANGE MASTER TO MASTER_HOST='$masterHost', MASTER_USER='$replication_user', MASTER_PASSWORD='$replication_password', MASTER_LOG_FILE='mysql01-bin.000001', MASTER_CONNECT_RETRY=5;" > $temp_file1
            echo "START SLAVE;" >> $temp_file1
            echo "SHOW SLAVE STATUS\G   " > $temp_file2
            echo "STOP SLAVE IO_THREAD;" >> $temp_file2
            echo "CHANGE MASTER TO MASTER_HOST='$masterHost', MASTER_USER='$replication_user', MASTER_PASSWORD='$replication_password', MASTER_LOG_FILE='mysql01-bin.000001', MASTER_CONNECT_RETRY=5;" >> $temp_file2
            echo "START SLAVE;" >> $temp_file2
            echo "SHOW SLAVE STATUS\G   " >> $temp_file2
        fi
        cat $temp_file1 | mysql --ssl=0
        if [ $? -eq 0 ]; then
            $log_command "Added replication user in master."
        fi
        if [ -f $temp_file2 ]; then
            cat $temp_file2 | mysql --ssl=0
            if [ $? -eq 0 ]; then
                $log_command "Added master configuration in slave."
            fi
            rm -f $temp_file2
        fi
        rm -f $temp_file1
    fi
}

#bounce the server
bounceMysql(){
    sys_user=$1

    $log_command "going to bounce mysql server..."
    shutdownMysql $sys_user
    status=$?
    if [ $status -ne 0 ]; then
        return 1
    fi
    sleep 5
    startMysql $sys_user
    status=$?
    return $status
}

# return 0 if db_name is in keywords
is_db_name_in_keywords (){
    local dbname=$1
    local dbname_keywords=('information_schema' 'mysql' 'performance_schema' 'sys')
    local e
    for e in "${dbname_keywords[@]}"; do [[ "$e" == "$dbname" ]] && return 0; done
     return 1
}

#Create User Databse if its a master node
createDatabase(){
    db_name=$1
    master=$2

    if [ $master -eq 1 ]; then
        createdb_sql=/tmp/db.sql
        echo "create database ${db_name};" >> $createdb_sql
        echo "use ${db_name};" >> $createdb_sql
        cat $createdb_sql | mysql --ssl=0
        echo database ${db_name} is created...
        $log_command "Created database ${db_name} in the mysql-master."
    fi
    rm -rf $createdb_sql
    return 0
}

# returns 0 if username is in username_keywords
is_user_name_in_keywords() {
    local username=$1
    local username_keywords=('mysql.sys' 'oracle' 'mysql' 'sys')
    for e in "${username_keywords[@]}"; do [[ "$e" == "$username" ]] && return 0; done
     return 1
}


#Resets root user password
#Creates management user "oracle"
 
mysqlForcedUserSetup(){
   dbuser_name=$1
   db_password=$2
   sys_user=$3
   auth_user=$3
   script_name=$4
   log_dir=$5
   base_dir=$6
   data_dir=$7
   

   ERROR_FILE=${data_dir}/`hostname`.err
   RETRY_COUNT=10
   WAIT_TIME=10

 
   resetpwd_sql=/tmp/reset_password.sql
   #sleep for a bit so that mysqld can get ready
   sleep 50
   echo "FLUSH PRIVILEGES;" > $resetpwd_sql
   echo "CREATE USER IF NOT EXISTS $dbuser_name@'%' IDENTIFIED BY '$db_password';" >> $resetpwd_sql
   echo "SET password for $dbuser_name@'%'='$db_password';" >> $resetpwd_sql
   echo "CREATE USER IF NOT EXISTS '$auth_user'@'localhost' IDENTIFIED WITH auth_socket;" >> $resetpwd_sql
   echo "GRANT ALL PRIVILEGES ON *.* TO '$auth_user'@'localhost' WITH GRANT OPTION;" >> $resetpwd_sql
   echo "FLUSH PRIVILEGES;" >> $resetpwd_sql
 
   chown  $sys_user:$sys_user $resetpwd_sql
   $log_command "runuser -l $sys_user -c cat $resetpwd_sql | mysql --ssl-mode=DISABLED -u$dbuser_name"
   runuser -l $sys_user -c "mysql --ssl-mode=DISABLED -u$dbuser_name < $resetpwd_sql > /tmp/out.txt 2>&1 "
   #/u01/bin/mysql/bin/mysql --ssl=0 -u$dbuser_name < $resetpwd_sql > /tmp/out.txt 2>&1 
   status=$?
   $log_command "====================================User Creation output==================================="
   while read LINE
   do
     logLine "$LINE"
   done < /tmp/out.txt
 
   $log_command " "
   $log_command "status=$status"
   if [ $status -eq 0 ]; then
       $log_command "Reset dbuser in master."
   else
       $log_command ERROR "dbuser reset in database failed"
       return $status
   fi

   $log_command " "
   #do a clean shutdown
   runuser -l $sys_user -c "source $script_name && shutdownMysql $sys_user 1"
   #switch to origin cnf file
   runuser -l $sys_user -c "mv $base_dir/my.cnf.bkp $base_dir/my.cnf"
   #start mysql
   runuser -l $sys_user -c "source $script_name && startMysql $sys_user"
   #lets wait for mysql to start
   runuser -l $sys_user -c "source $script_name && waitForMysqlToStart $WAIT_TIME $RETRY_COUNT $sys_user"
   
   $log_command "====================================MySQL Log=============================================="
   while read LINE
   do
     logLine "$LINE"
   done < $ERROR_FILE

   shred -vzn 3 $resetpwd_sql
   rm -rf  $resetpwd_sql
   return $status
} 

#
#Will crete mysql user and assign password
# $1 ismaster value: 1 if master node, 0 if slave
# $2 mysql user name
# $3 credential file of admin node
# $4 credential file of managed server node
#
mysqlUserCreation()
{
    dbuser_name=$1
    db_password=$2
    sys_user=$3
    source_dbuser_name=$4

    # check user given name is in keywords
    is_user_name_in_keywords $dbuser_name
    if test $? -eq 0; then 
        $log_command ERROR "username: $dbuser_name is a keyword"; return 1;
    fi

    #assign password if user is "root" else create the user and assign.
    assignpwd_sql=/tmp/assign_pwd.sql
    echo "adding pasword for dbuser $dbuser_name.."
    if [ "$CLONE" == "yes" ]; then
        if [ $source_dbuser_name == $dbuser_name ]; then
            echo "ALTER USER $dbuser_name IDENTIFIED BY \"$db_password\";" >> $assignpwd_sql
        else
            echo "CREATE USER $dbuser_name@'%' IDENTIFIED BY '$db_password';"  >> $assignpwd_sql
            echo "GRANT ALL PRIVILEGES ON *.* TO $dbuser_name@'%' WITH GRANT OPTION;"  >> $assignpwd_sql
            echo "DROP USER $source_dbuser_name@'%';" >> $assignpwd_sql
        fi
    elif [ $dbuser_name == "root" ] ; then
        echo "ALTER USER USER() IDENTIFIED BY \"$db_password\";" >> $assignpwd_sql
        echo "update mysql.user set host=\"%\" where user=\"root\";" >> $assignpwd_sql
    else
        echo "CREATE USER $dbuser_name@'%' IDENTIFIED BY '$db_password';"  >> $assignpwd_sql
        echo "GRANT ALL PRIVILEGES ON *.* TO $dbuser_name@'%' WITH GRANT OPTION;"  >> $assignpwd_sql
        echo "DROP USER root@'localhost';" >> $assignpwd_sql
    fi
    echo "FLUSH PRIVILEGES;" >> $assignpwd_sql

    if [ "$CLONE" == "yes" ]; then
        runuser -l $sys_user -c "mysql -u${sys_user} --ssl=0 < $assignpwd_sql"
    else
        cat $assignpwd_sql | mysql --ssl=0
    fi

    status=$?
    if [ $status -eq 0 ]; then
        $log_command "Created dbuser in master."
    else
        $log_command ERROR "dbuser Creation in database failed"
    fi
    shred -vzn 3 $assignpwd_sql
    rm -rf  $assignpwd_sql
    return $status
}

#
# will activate the validate password plugin for MySQL server with default MEDIUM policy
#
activateValidatePasswordPlugin()
{
    passwdPolicy_sql=/tmp/passwdPolicy.sql
    echo "INSTALL PLUGIN validate_password SONAME 'validate_password.so';" > $passwdPolicy_sql
    cat $passwdPolicy_sql | mysql --ssl=0
    status=$?
    if [ $status -eq 0 ]; then
        $log_command "Validate password plugin loaded and registered in mysql.plugins table"
    else
        $log_command ERROR "Couldn't load validate password plugin"
    fi
    shred -vzn 3 $passwdPolicy_sql
    rm -rf  $passwdPolicy_sql
    return $status
}

#
#will create system level authentication user for mysql
# $1 is auth user name
# $2 admin user
#
createAuthUser() {
    auth_user=$1
    admin_user=$2
    password=$3

    create_auth_sql=/tmp/create_auth.sql
    $log_command "Creating peer socket authenticated user."

    echo "CREATE USER '$auth_user'@'localhost' IDENTIFIED WITH auth_socket;" >> $create_auth_sql
    echo "GRANT ALL PRIVILEGES ON *.* TO '$auth_user'@'localhost' WITH GRANT OPTION;" >> $create_auth_sql
    echo "FLUSH PRIVILEGES;" >> $create_auth_sql

    cat $create_auth_sql | mysql --ssl=0 -u$admin_user -p$password
    status=$?
    if [ $status -eq 0 ]; then
        $log_command "Created authenticated in master."
    else
        $log_command ERROR "authenticated user Creation in database failed"
    fi
    shred -vzn 3 $create_auth_sql
    rm -rf  $create_auth_sql
    return $status
}


#
#copy mysql.ser ver file from support_files to mysql/bin directory
#
copyMysqlServerFile(){
    base_dir=$1
    data_dir=$2

    mysql_server=$base_dir/bin/mysql.server
    newline1="datadir=$data_dir"
    newline2="basedir=$base_dir"

    newline1=$(putEscapeCharacters "$newline1")
    newline2=$(putEscapeCharacters "$newline2")

    cp $base_dir/support-files/mysql.server $base_dir/bin
    
    line_number=$(awk '/datadir=/{ print NR; exit }' $mysql_server)
    replaceLine $line_number "$newline1" $mysql_server

    #line_number=$(awk '/basedir=/{ print NR; exit }' $mysql_server)
    ((line_number++))
    replaceLine $line_number "$newline2" $mysql_server
    return $?
}

restrictMysqlAccess(){
    base_dir=$1

    runuser -l opc -c " echo 'mysql(){ echo \"Please switch to \\\"oracle\\\" user to use mysql client\"; }' >> ~/.bashrc;"
    runuser -l opc -c " echo 'mysql.server(){ echo \"Please switch to \\\"oracle\\\" user to use mysql.server\"; }' >> ~/.bashrc;"
    runuser -l opc -c " echo 'mysqladmin(){ echo \"Please switch to \\\"oracle\\\" user to use mysqladmin\"; }' >> ~/.bashrc;"

    echo "mysql(){ echo \"Please switch to \\\"oracle\\\" user to use mysql client\"; }" >> ~/.bashrc
    echo "mysql.server(){ echo \"Please switch to \\\"oracle\\\" user to use mysql.server\"; }" >> ~/.bashrc
    echo "mysqladmin(){ echo \"Please switch to \\\"oracle\\\" user to use mysqladmin\"; }" >> ~/.bashrc

    chmod 754 $base_dir/bin/mysql*
}

#
# function to download mysql enterprise monitor binaries
#
downloadEnterpriseMonitor(){
    em_installer=$1
    cloudkey_em=$2
    storage_container=$3
    sys_user=$4

    curl -X GET -v -m 60 --retry 9 --fail "${storage_container}/${cloudkey_em}" --output "$em_installer"
    $log_command "downloaded  enterprise monitor from ${storage_container}/${cloudkey_em} to $em_installer."
    chown -R $sys_user:$sys_user $em_installer
}

createEnterpriseMonitorOption(){
    option_file=$1
    bin_home=$2
    mysql_user=$3
    mysql_password=$4
    mysql_port=$5
    sys_user=$6

    echo "mode=unattended" > $option_file
    echo "debugtrace=${bin_home}/enterprise/install.debugtrace.monitor.log" >> $option_file
    echo "installdir=${bin_home}/enterprise/monitor" >> $option_file
    echo "installer-language=en" >> $option_file
    echo "system_size=small" >> $option_file
    echo "tomcatport=18080" >> $option_file
    echo "tomcatsslport=18443" >> $option_file
    echo "mysql_installation_type=existing" >> $option_file
    echo "adminuser=$mysql_user" >> $option_file
    echo "adminpassword=$mysql_password" >> $option_file
    echo "dbhost=127.0.0.1" >> $option_file
    echo "dbname=mem" >> $option_file
    echo "dbport=$mysql_port" >> $option_file
    #echo "mysql_ssl=0" >> $option_file
    $log_command "created enterprise monitor option file: $option_file."
    chown -R $sys_user:$sys_user $option_file
}

#
# function to install mysql enterprise monitor
#
installEnterpriseMonitor(){
    em_installer_dir=$1
    bin_home=$2
    option_file=$3
    sys_user=$4
    
    mkdir -p ${bin_home}/enterprise/monitor
    chown $sys_user:$sys_user -R ${bin_home}/enterprise/monitor

    cd $em_installer_dir 
    unzip *.zip
    status=$?
    chown -R $sys_user:$sys_user $em_installer_dir 
    chmod +x ./*linux-x86_64-installer.bin
    chown -R $sys_user:$sys_user ${bin_home}/enterprise/
    runuser -l $sys_user -c "cd $em_installer_dir; ./*linux-x86_64-installer.bin --optionfile $option_file"
    status2=$?

    shred -vzn 3 $option_file
    rm -rf $option_file
    rm -rf $em_installer_dir/*.bin
    ((status+=status2))
    if test $status -ne 0; then
        $log_command "Failed to install Enterprise Monitor"
        return $status
    fi
    $log_command "started Enterprise Monitor"
}

#
# function to configure manager and agent users for  mysql enterprise monitor
#
configureEnterpriseMonitor(){
    mem_manager_name=$1
    mem_manager_password=$2
    mem_agent_name=$3
    mem_agent_password=$4
    sys_user=$5 

    mem_passwd_file=${bin_home}/enterprise/monitor/memPasswdFile.txt
 
    echo $mem_manager_password > $mem_passwd_file
    echo $mem_agent_password >> $mem_passwd_file
    chown -R $sys_user:$sys_user $mem_passwd_file

    runuser -l $sys_user -c "cd ${bin_home}/enterprise/monitor/bin; ./config.sh --sm-admin-user=$mem_manager_name --sm-agent-user=$mem_agent_name < $mem_passwd_file"

    shred -vzn 3 $mem_passwd_file
    rm -rf $mem_passwd_file
    $log_command "configured Enterprise Monitor"
}

#create instance from backup
# fucntion to cteate MySQL instance from user provided backup
#
createInstanceFromBackup(){
    json_file=$1
    tools_dir=$2
    sys_user=$3
 
    backupScriptDir="${tools_dir}/../service_scripts/python/backup"
    runuser -l $sys_user -c "cd ${backupScriptDir}; ./msaas_create_instance.py ${json_file} > /tmp/create_instance_tmp.out 2>&1 "
    status=$?
    shred -vzn 3 $json_file
    rm -rf $json_file
 
    $log_command "====================================Create Instance Output==================================="
    while read LINE
    do
      logLine "$LINE"
    done < /tmp/create_instance_tmp.out
 
    $log_command " "
    rm -f /tmp/create_instance_tmp.out
 
    if [ $status -eq 0 ]; then
        $log_command "Created instance."
    else
        $log_command ERROR "Instance creation from exiting backup failed."
    fi
    return $status
}

#
# function to install mysql enterprise backup
#
installMEB() {
    installer=$1
    location=$2
    sys_user=$3

    temp_location=/tmp/meb

    mkdir -p ${location}
    chown -R $sys_user:$sys_user ${location}
    mkdir -p ${temp_location}
    chown -R $sys_user:$sys_user ${temp_location}
    
    extractZipArtifact $installer $temp_location $sys_user
    status=$?
    extractTarGzArtifact $temp_location/meb*.tar.gz $location $sys_user
    status2=$?
    ((status += status2))
    runuser -l $sys_user -c "cd ${location}; ln -s $location/meb* meb"
    status2=$?
    ((status += status2))
    rm -rf $temp_location
    return $status

}

#
# function sets up runlevel scripts for shutdown and start of mysql during system startup/shutdown
#
createInitRunlevelEntries(){
    servicenamefile=$1
    scriptfile=$2
    servicename=$3
    lockfile=$4
    scriptlocation=$5
    #change the script path before copy
    sed -i "/REPLACE-SCRIPTPATH/c SCRIPTSDIR=${scriptlocation}" $scriptfile
    cp $scriptfile $servicenamefile
    cp_status=$?
    if test $cp_status -eq 0; then
       chkconfig --add $servicename 
       add_status=$?
       if test $add_status -eq 0; then
          chkconfig --level 345 $servicename on
          level_add_status=$?
       fi
    fi
    if [ "$cp_status" -ne 0 -o "$add_status" -ne 0 -o "$level_add_status" -ne 0 ]; then
       if [ "$cp_status" -ne 0 ]; then
          $log_command "Failed to copy the script file $scriptfile to $servicenamefile"
       fi
       if [ "$add_status" -ne 0 ]; then
          $log_command "Failed to add $servicename to init.d"
       fi
       if [ "$level_add_status" -ne 0 ]; then
          $log_command "Failed enable the service $servicename"
       fi
       return 1
    else
       touch $lockfile
       $log_command "Run level entries added."
       return 0
    fi  
}
 
#

#
#function to configure user defined encrypt functions 
#
createUserDefinedFunctions(){
    sys_user=$1
    sql_file_home=$2

    encryption_functions=$sql_file_home/encryptionFunctions.sql

    executeSql $encryption_functions $sys_user 0
    status=$?
    if [ $status -eq 0 ]; then
        $log_command "Created user defined encryption functions in mysql."
    else
        $log_command ERROR "Created user defined encryption functions in mysql."
    fi
    return $status
}

configureMysqlDb (){
    sys_user=$1
    vm_script_home=$2
    
    sql_file_home=$vm_script_home/sql-files
    
    createUserDefinedFunctions $sys_user $sql_file_home
    return $?
}

createBannerForOpc(){
    bash_login_file=$1
    bash_login_template=$2
    sys_user=$3

    sed -i s/sys_user/$sys_user/g $bash_login_template
    cp $bash_login_template $bash_login_file
    chown opc:opc $bash_login_file
    status=$?
    runuser -l opc -c " echo 'if [ -f $bash_login_file ]; then . ${bash_login_file}; fi' >> ~/.bash_profile "
    return $status
}

uninstallMysqlLib(){
    mysqlPackage=$(yum list installed | grep mysql | cut -d ' ' -f 1)
    yum remove $mysqlPackage -y
}
