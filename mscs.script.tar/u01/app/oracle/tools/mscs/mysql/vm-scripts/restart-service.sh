#!/bin/bash
#
#Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#

#
# This script will do the things needed when system or nimbula-orchestration is restarted
#

#Absolute path of current file
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#import
source $DIR/constants.sh
source $DIR/msaas-provisioning-utils.sh
source $DIR/mysql-installation-utils.sh
#logger used for logging msaas provisioning
source $DIR/logger.sh  --source_only
tools_home=`getCriticalAttribute /storage_map/tools/mountpoint`
sys_user_home=${tools_home}/home/$SYS_USER

componet_name=`getAttribute /artifacts/SERVICE_TOOLS`
#log file and marker file location
msaas_home=${tools_home}/${MSAAS_HOME_FOLDER}
log_home=${msaas_home}/${MSAAS_LOG_FOLDER}
log_file=$log_home/${MSAAS_PROVISIONING_RESTART_LOG_NAME}

#Initialize logger
if [ ! -f $log_file ]; then
        mkdir -p $log_home
        chown -R $SYS_USER:$SYS_USER $log_home
fi
launchLogger $log_file "Starting restart-service.sh"

log START "Restart Service"
log START "Add init.d entries to runlevel scripts for start/shutdown of mysqld during VM shutdown/restart"
chkconfig --list $SERVICENAME >/dev/null
if test $? -ne 0; then
   SERVICENAMEFILE=/etc/init.d/$SERVICENAME
   SCRIPTFILE="$DIR/mysql-vm-stop-start-script.sh"
   doTask "createInitRunlevelEntries $SERVICENAMEFILE $SCRIPTFILE $SERVICENAME $LOCKFILE $DIR" "log"
   status=$?
   if test $status -ne 0; then log ERROR "operation createInitRunlevelEntries failed"; log FINISH "createInitRunlevelEntries"; makeExit $status; fi
   $DIR/start-service.sh
fi
log FINISH "Add init.d entries to runlevel scripts for start/shutdown of mysqld during VM shutdown/restart"

log FINISH "Restart service"
