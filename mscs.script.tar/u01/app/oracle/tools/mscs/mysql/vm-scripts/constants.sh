#System Folders and files
BINARIES_FOLDER="/u01/binaries"



#Relative Path from Tools Home
MSAAS_HOME_FOLDER="msaas"
MSAAS_LOG_FOLDER="log"
MSCS_LOG_FOLDER="log"
PATCH_LOG_FILE="patch.log"

MSAAS_PROVISIONING_LOG_NAME="MsaasProvisioning.log"
MSAAS_PROVISIONING_RESTART_LOG_NAME="MsaasProvisioningRestart.log"
DEBUG_LOG=/tmp/prov_debug.log
ERROR_LOG=/tmp/prov_error.log

#MYSQL configuration file
MYSQL_CONF_FILE=my.cnf
MYSQL_CLIENT_CONF_FILE=.my.cnf
OS_OPEN_FILE_LIMIT=20000

MYSQL_DEFAULT_COLLATION_FILE=vm-scripts/config/default_collation.txt
MYSQL_COLLATION_TO_CHARSET_FILE=vm-scripts/config/collation_to_charset.txt

#MSCS purge specification file
MSCS_PURGE_SPEC_FILE=mscs-purge.txt

#MsaasProvisioning config
SYS_USER="oracle"
SEMAPHORE_FILE=/tmp/credentials.sem
ADMIN_CRED_FILE=/tmp/credentials_admin
MS_CRED_FILE=/tmp/credentials_ms
PROVISION_MARKER_FILE=/var/log/opc-compute/provisioningMarker.log
SERVICENAME=mysqlcsopr
LOCKFILE=/var/lock/subsys/${SERVICENAME}
MYSQLADMIN=/u01/bin/mysql/bin/mysqladmin
STARTSCRIPTNAME=start-service.sh
TIMEZONE_INFO_FOLDER=/usr/share/zoneinfo

#
SHUTDOWN_RETRY_COUNT=100
SHUTDOWN_WAIT_TIME=5
