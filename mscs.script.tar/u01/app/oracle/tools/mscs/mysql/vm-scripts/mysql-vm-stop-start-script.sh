#!/bin/bash
#
#
# chkconfig: - 99 1
# description:  Starts and stops process mysqld
# short-description:  Starts and stops process mysqld

### BEGIN INIT INFO
# Required-Start:
# Required-Stop:
# Provides: psacct
# Default-Start: 3 4 5
# Default-Stop: 0 1 2 6
# Description: Starts and stops process mysqld
# Short-Description: Starts and stops process mysqld
### END INIT INFO


# The location of the mysqld file
SCRIPTSDIR=/u01/app/oracle/tools/mscs/mysql/vm-scripts
attributes="http://192.0.0.192/latest/attributes"

getAttribute() {
    key=$1

    return_value=$(curl -w "%{http_code}" -m 30 --retry 3 --retry-delay 5 --retry-max-time 105 -s ${attributes}/"$key")
    result_code=${return_value:(-3)}
    user_data_value=${return_value::${#return_value}-3}
    if [ -z "$user_data_value" ] || [ $result_code != "200" ]
    then
        return 1
    else
        echo "$user_data_value"
        return 0
    fi
}

tools_root=`getAttribute /toolsRoot`
componet_name=`getAttribute /artifacts/SERVICE_TOOLS`
vm_script_home=${tools_root}/${componet_name}/vm-scripts
#check if the directory exists
#if not try the usual directories
#end try the find
if [ -f ${vm_script_home}/constants.sh ]; then
   SCRIPTSDIR=$vm_script_home
fi


source ${SCRIPTSDIR}/constants.sh

start() {
        touch $LOCKFILE
        ${SCRIPTSDIR}/${STARTSCRIPTNAME}
}

stop() {
        #shutdown mysql
        if [ -f $LOCKFILE ]; then
           rm $LOCKFILE
           runuser -l $SYS_USER -c "${MYSQLADMIN} shutdown"
           RETVAL=$?
        fi
}

# See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  *)
        # do not advertise unreasonable commands that there is no reason
        # to use with this device
        echo $"Usage: $0 {start|stop}"
        exit 2
esac

exit 0

