#current directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#import
. $DIR/constants2.sh

#url for attributes
attributes="http://192.0.0.192/latest/attributes"

#cloud
storage_container=`curl ${attributes}/storageContainer`

#tools path
bin_home=`curl -m 5 ${attributes}/storage_map/bin/mountpoint`
bin_device=`curl -m 5 ${attributes}/storage_map/bin/device`
data_home=`curl -m 5 ${attributes}/storage_map/data/mountpoint`
data_device=`curl -m 5 ${attributes}/storage_map/data/device`
tools_home=`curl -m 5 ${attributes}/storage_map/tools/mountpoint`
if test $? -ne 0 -o "No such metadata item" == "${tools_home}" ; then
  tools_home="$TOOLS_HOME_DEFAULT"
fi

#vm-scripts path
paas_root=${tools_home}/paas
platform_tooling_bin=${paas_root}/bin
vmScript_home=${platform_tooling_bin}/vm-scripts

#MsaaS files and folders in side the System image
u01=$U01
download_folder=$DOWNLOAD_FOLDER
zips_folder=$ZIPS_FOLDER
mysqlTarFile="${zips_folder}/${MYSQL_TAR_LOC}"

#log files
log_home=${tools_home}/${MSAAS_HOME_FOLDER}/${MSAAS_LOG_FOLDER}
log_file=$log_home/${MSAAS_PROVISIONING_LOG_NAME}

#mountingVariables
volume_group_bin=vg_bin
logical_volume_bin=lv_bin
device_path_bin=/dev/${volume_group_bin}/${logical_volume_bin}
volume_group_data=vg_data
logical_volume_data=lv_data
device_path_data=/dev/${volume_group_data}/${logical_volume_data}

#mysql
base_dir="${bin_home}/mysql"
data_dir="${data_home}/mysql"
mysql_bin_dir=${base_dir}/bin
mysqld_safe=${mysql_bin_dir}/mysqld_safe
mysql_bin_log_dir=${data_dir}/binlogs
mysql_bin_log=${data_dir}/binlogs/mysql01-bin
mysql_conf_file=${MYSQL_CONF_FILE}

#db creation
db_name=`curl ${attributes}/userdata/ms_db_name`
dbuser_name=`curl ${attributes}/userdata/ms_admin_user`
replication_user=`curl ${attributes}/userdata/ms_replication_user`

#MsaasProvisioning
oracle_user_home=${tools_home}/home/oracle
credential_file_admin=$ADMIN_CRED_FILE
credential_file_ms=$MS_CRED_FILE

	####if change,make change in the provisioning.json also
provisionMarkerforSlaves=${log_home}/provisionMarkerForSlaves.log
provisionMarkerforMaster=${log_home}/provisionMarkerForMaster.log
provisionMarkerFile=${PROVISION_MARKER_FILE}
