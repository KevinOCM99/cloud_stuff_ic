#
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#

"""
The check_logs script receives a map of servers and server types as input in a json format. The script then loads the
provisioningStatusCheck.json file and uses the log analyzers specified for each server type and checks the log files
for the presence of the success and failure markers (again specified in the provisioningStatusCheck.json). The script
returns a results map for each server and a status based on the presence / absence of the success/error markers in the
log files.
"""

import json
import glob
import sys
import base64

#Checks the log file for the present of the markers
def checkFileContains(filePath, markers):
    files = glob.glob(filePath)
    for fileName in files:
        with open(fileName) as logFile:
            for line in logFile:
                if any(m in line for m in markers):
                    return True
    return False

#Returns the lines containing the error marker in the file
def getErrors(filePath, errorMarker):
    errors=[]
    files = glob.glob(filePath)
    for fileName in files:
        with open(fileName) as logFile:
            for line in logFile:
                if any(m in line for m in errorMarker):
                    errors.append(line)

    return errors


results = []
result = {}

result["file"] = "/var/log/opc-compute/provisioningMarker.log"

success = checkFileContains("/var/log/opc-compute/provisioningMarker.log", ["started"])
error = checkFileContains("/var/log/opc-compute/provisioningMarker.log", ["failed"])

if success == error == False:
    result["status"] = "InProgress"
    result["error"] = ""
elif success == True and error == False:
    result["status"] = "Succeeded"
    result["error"] = ""
else:
    result["status"] = "Failed"
    result["error"] = getErrors("/var/log/opc-compute/provisioningMarker.log", ["failed"])
results.append(result)

print json.dumps(results)

