__author__= "balagopalan thampi"
__copyright__ = "Copyright (c) 2016-2017 Oracle and/or its affiliates. All rights reserved."
__email__ = "balagopalan.thampi@oracle.com"

import sys

##A simple class to do operations on a configutarion file
class ConfParser(object):
    #initialize configuration file object with give file
    def __init__(self, file):
        self.file = file
        self.H = {}
        #creating dictionary from property file
        section=''
        self.sections=[]
        self.sections.append(section)
        self.H[section]={}
        i=0
        for line in open(self.file):
            if line.startswith('['):
                section = line.split('[')[1].split(']')[0]
                self.sections.append(section)
                self.H[section]={}
            elif line.startswith('#'):
                self.H[section][i]=line.strip()
            elif '=' in line:
                prop = line.strip().split('=')[0]
                value = line.strip().split('=')[1]
                self.H[section][i]={}
                self.H[section][i][prop]=value
            else:
                self.H[section][i] = line.strip()
            i=i+1

    #write the configuration object to a file
    def writeToPropertyFile(self,newFile):
        file=open(newFile,'w')
        for section in self.sections:
            if section != '':
                file.write('['+section+']'+'\n')
            for index in self.H[section].keys():
                if isinstance(self.H[section][index], dict):
                    for key in self.H[section][index].keys():
                        file.write(key+'='+self.H[section][index][key]+'\n')
                else:
                    file.write(self.H[section][index]+'\n')

    #return ture if property is mentioned in the configuration file
    def ismentioned(self,section,prop):
        result=False
        if section not in self.sections:
            return False
        for index in self.H[section].keys():
            if isinstance(self.H[section][index], dict):
                if prop in self.H[section][index].keys():
                    result = True
        return result

    #check the valu is set for the property
    #TODO exception need to be added
    def isnone(self,section,prop):
        result=True
        found=False
        if section not in self.sections:
            return True
        if self.ismentioned(section,prop):
            found=True
        else:
            return False
        for index in self.H[section].keys():
            if isinstance(self.H[section][index], dict):
                if prop in self.H[section][index].keys():
                    if self.H[section][index][prop] == '':
                        result = True
                    else:
                        result = False
        return result

    #check wether property is set or not
    #TODO exception need to be added
    def isset(self,section,prop):
        result = False
        if section  not in self.sections:
            return False
        if self.isnone(section,prop):
            result=False
        else:
            result = True
        return result

    #set the given property under section with given value
    def setProperty(self,section,prop,value):
        try:
            found = False
            for index in self.H[section].keys():
                if isinstance(self.H[section][index], dict):
                    if prop in self.H[section][index].keys():
                        self.H[section][index][prop]=value
                        found=True
            self.writeToPropertyFile(self.file)
            return  found
        except KeyError as error:
            print('caught this error:'+ repr(error))
            return False

    #set none to the property
    def setNone(self,section,prop):
        value=''
        return self.setProperty(section,prop,value)

    #add property with value given
    def addProperty(self,section,prop,value):
        try:
            lastIndex=self.H[section].keys()[-1]
            lastIndex+=1
            self.H[section][lastIndex]={prop:value}
            self.writeToPropertyFile(self.file)
            return True
        except KeyError as error:
            print('caught this error:'+ repr(error))
            return False

    #return the effective value of the given property (if multiple time defined return the value of last assignment )
    def getProperty(self,section,prop):
        try:
            value = ''
            for index in self.H[section].keys():
                if isinstance(self.H[section][index], dict):
                    keys = self.H[section][index].keys()
                    if prop in keys:
                        value = self.H[section][index][prop]
            return value
        except KeyError as error:
            return ''
            print('caught this error:'+ repr(error))

#TODOfunctions to be implemented
'''
removeProperty

'''
