# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.

import framework,json
import sys,os,socket,time,string,subprocess
import re,pycurl,cStringIO
import logging

class Utils():

    curlRetries=5

    def __init__(self, pcontext, shellcommand):
        self.pcontext = pcontext
        self.shellcommand = shellcommand

    def check_for_file_on_cloudstorage(self,storageURL):
        command = 'curl -sI retry 5 --max-time 180 --retry-delay 3 --retry-max-time 720 {0}'.format(storageURL)
        self.patchlog("INFO","Running the command " +command)
        status=101
        curlRetry=0
        binary_size=0
        while status != 0 and curlRetry < self.curlRetries:
            curlRetry += 1
            status,stdout = self.shellcommand.run(command)
            if status == 0:
                self.patchlog("Command ran successfully")
                break
            else:
                time.sleep(1)
                self.patchlog("WARNING","Retrying the command again after a pause for 1 second.")

        if status == 0:
            self.patchlog("INFO","Verified that storageURL exists")
            curl_headers=stdout.split("\n")
            for str in curl_headers:
                if 'Content-Length: ' in str:
                    binary_size=str[len('Content-Length: '):]
        else:
            self.pcontext.addFailure("Can not verify if storageURL exists")
            self.patchlog("ERROR","Can not verify if storageURL exists")
            return self.pcontext.exit(30)

        return status, binary_size

    def download_zipbundle(self, hostname, storageURL,zip_bundle_path,chksum):
        command = 'rm -f {0}'.format(zip_bundle_path)
        self.shellcommand.run(command, host=hostname)
        status=101
        curlRetry=0
        command = 'curl -X GET -v -m 60 --retry 9 --fail {0} --output {1}'.format(storageURL,zip_bundle_path)
        while status != 0 and curlRetry < self.curlRetries:
            curlRetry += 1
            status,stdout = self.shellcommand.run(command, host=hostname)
            if status == 0:
                break
            else:
                time.sleep(1)

        if status == 0:
            self.pcontext.addMessage("Successfully downloaded storageURL")
            self.patchlog("INFO","Successfully downloaded storageURL")
            if chksum != 0:
                command='md5sum '+zip_bundle_path+' | cut -d" " -f1'
                status, stdout = self.shellcommand.run(command, host=hostname)
                if status == 0 and str(chksum) == stdout.strip("\n"):
                    self.pcontext.addMessage("Checksum Verification Successful")
                    self.patchlog("INFO","Checksum Verification Successful")
                else:
                    self.pcontext.addFailure("Checksum Verification Failed")
                    self.patchlog("ERROR","Checksum Verification Failed")
                    return self.pcontext.exit(35)
        else:
            self.pcontext.addFailure("Error downloading storageURL")
            self.patchlog("ERROR","Error downloading storageURL")
            return self.pcontext.exit(40)

    def patch_dir(self,install_dir,preserve_file,zip_bundle_path,tmp_dir,service_name,host='localhost'):
        hostname=socket.gethostname()

        preserve_file_dir=os.path.dirname(preserve_file)
        preserve_file_name=os.path.basename(preserve_file)
        zip_bundle_name=os.path.basename(zip_bundle_path)
        if '.zip' in zip_bundle_name:
            extract_command='unzip'
        elif '.tar.gz' in zip_bundle_name:
            extract_command='tar xvfz'
        elif '.tar' in zip_bundle_name:
            extract_command='tar xvf'
        else:
            return self.pcontext.exit(1)

        self.pcontext.addMessage("Performing Swap")
        # create temporary directory
        self.patchlog("INFO","Create "+tmp_dir)
        command='rm -rf {0}; mkdir -p {0}'.format(tmp_dir)
        status0,stdout0=self.shellcommand.run(command,host)

        # copy the file to be preserved to temporary directory
        self.patchlog("INFO","Copy Preserve file "+preserve_file)
        command='cp {0}/{1} {2}'.format(preserve_file_dir,preserve_file_name,tmp_dir)
        status1,stdout1=self.shellcommand.run(command,host)

        # make a backup of the current binary
        self.patchlog("INFO","Move binaries to .bkp directory")
        command='cd {0}; mv {2} {1}/{2}.bkp'.format(install_dir,tmp_dir,service_name)
        status2,stdout2=self.shellcommand.run(command,host)

        #copy the zip_bundle_path to remote VM if needed
        # scp command needs to be run locally
        # on local vm zip bundle is zip_bundle_path
        # on remove vm zip bundle is at tmp_dir/zip_bundle_name
        self.patchlog("INFO","Unzip the Bundle")
        if host.lower() == hostname.lower() or host.lower() == 'localhost':
            command='cd {0}; {2} {1}'.format(install_dir,zip_bundle_path,extract_command)
            status3,stdout3=self.shellcommand.run(command,host)
        else:
            command='scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no '+zip_bundle_path+' '+host+':'+tmp_dir
            status,stdout=self.shellcommand.run(command, host)
            command='cd {0}; {3} {1}/{2}'.format(install_dir,tmp_dir,zip_bundle_name,extract_command)
            status3,stdout3=self.shellcommand.run(command, host)

        # copy the files in the correct location
        self.patchlog("INFO","Move the files to install directory")
        command='cd {0}; mv {1}* {1}'.format(install_dir,service_name)
        self.shellcommand.run(command,host)

        # restore the file tobe preserved
        self.patchlog("INFO","Restore the Preserve File")
        command='rm -f {0}; cp {1}/{2} {3}'.format(preserve_file,tmp_dir,preserve_file_name,preserve_file_dir)
        status4,stdout4=self.shellcommand.run(command,host)

        self.pcontext.addMessage("Swap Completed")

    def rollback_dir(self, install_dir, tmp_dir, service_name, host='localhost'):
        self.pcontext.addMessage("Performing unswap")

        self.patchlog("INFO","Delete the current service directory")
        command='rm -rf {0}/{1}'.format(install_dir,service_name)
        self.shellcommand.run(command,host)

        self.patchlog("INFO","Restore .bkp directory")
        command='mv {1}/{2}.bkp {0}/{2} '.format(install_dir,tmp_dir,service_name)
        status2,stdout2=self.shellcommand.run(command,host)
        self.pcontext.addMessage("Rollback Completed")

    def getOrchestrationData(self,strURL):
        buffer = cStringIO.StringIO()
        c = pycurl.Curl()
        c.setopt(c.URL, strURL)
        c.setopt(c.WRITEFUNCTION, buffer.write)
        c.perform()
        c.close()

        ret=buffer.getvalue()
        buffer.close()

        return re.sub('[ \t\r\n]','',ret)

    @staticmethod
    def patchlog(message, level = 'INFO'):
        #self.result["status"] = level
        #self.result["statusMessage"] = message
        print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()) , level, message )
