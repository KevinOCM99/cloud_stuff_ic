    # Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
import framework
import os,sys
import json
import subprocess
import constants
import mysqlutils
from mysqlpatch import Patch

#function called by the metadata patch framework. service layer patching operations start from here
def execute(input_dict_args):
    pcontext=framework.PatchingContext(input_dict_args)
    patch=Patch(pcontext)
    operation = "Rollback"

    patch.add_message('Starting MySQL '+operation +' Process')  # will add to pcontext
    patch.log('Starting MySQL Process')         # will use mysql.patchlog
    patch.log('Start of Formated Input Json:----')
    framework.JSONUtil.print_dict_as_json(input_dict_args)
    patch.log('End of Formated Input Json:----')

    if patch.hasVmInstances():
    #Run the precheck operation before applying the rollback
        patch.log("Precheck function is being called","START")
        precheckLevelFlag=2
        result=patch.precheck(precheckLevelFlag)
        if result != 0:
            patch.add_failure("Precheck operation failed")
            patch.log("Precheck operation failed","ERROR")
            return patch.exit(result,constants.print_on_stdOut,"Precheck operation failed","Failure")
        else:
            patch.add_message("Precheck operation got successful")
            patch.log("Precheck operation got successful","INFO")

        #Apply the MySQL Rollback
        patch.add_message("MySQL "+operation +" being applied")
        patch.log("MySQL "+operation +" being applied","INFO")
        result=patch.apply_patch(operation)
        if result != 0:
            patch.log(operation +" operation got unsuccessful","ERROR")
            patch.add_failure("MySQL "+operation +" failed")
            return patch.exit(result,constants.print_on_stdOut,"MySQL "+operation +" failed","Failure")
        else:
            patch.log(operation +" got Successful")
            patch.add_message("MySQL "+operation +" succeeded")
            return patch.exit(result,constants.print_on_stdOut,"MySQL "+operation +" succeeded","Success")
    else:
        return patch.exit(0,constants.print_on_stdOut,"There is no VM instance","Warning")
