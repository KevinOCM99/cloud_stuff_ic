#
# Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
#

import json
import shlex
import subprocess
import socket
import urllib2
import os
import time
import sys
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)
import constants


#gets attributes from compute
def get_compute_attribute(url, retry=3, sleep_time=3):
    for retry_count in range(retry):
        try:
            return urllib2.urlopen(url).readline()
        except urllib2.HTTPError, e:
            if retry_count < retry:
                time.sleep(sleep_time) 
    return None

def addstorage(payload):

    toolsUrl = "http://192.0.0.192/latest/attributes/toolsRoot"
    toolsHome = get_compute_attribute(toolsUrl)

    myhost = socket.gethostname()
    print 'localhost=' + myhost
    failures = 0
    details = ""
    print "****input dictionary  from sm **** "
    print json.dumps(payload)
    print "****input dictionary  from sm **** "
    storageMap = payload["SM_OPERATION_INFO"]["ADDITIONAL_STORAGE"]
    storageVolumes=storageMap[myhost]
    for volumeName in storageVolumes:
        storageVolume = storageVolumes[volumeName]
        device=storageVolume["device"]
        volume=storageVolume["name"]
        componentName=payload["SM_OPERATION_INFO"]["COMPONENT_TYPE"]
        add_storage_script = constants.ADD_STORAGE_SCRIPT
        command = 'sudo {0}/{1}{4} {2} {3}'.format(toolsHome,
                                                   componentName,
                                                   volume,
                                                   device,
                                                   add_storage_script)
        command = shlex.split(command)
        print 'Extending storage volume '+volume +' on host '+myhost
        print command
        # shell = true, in oel sh -> bash
        # make file executable 
        script = toolsHome + '/' + componentName + add_storage_script
        os.system("sudo chmod +x " + script )
        proc = subprocess.Popen(command, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
        output, err = proc.communicate()
        return_code = proc.returncode
        print "****error****"
        print err
        print "****error****"
        print "****output****"
        print output
        print "****output****"
        if return_code == 0:
            message="Successfully expanded storage volume [{0}] on host [{1}]. ".format(volume, myhost)
            print message
            details = details + message
        else:
            message = 'Failed to expand storage volume [{0}] on host [{1}]'.format(volume,myhost)
            print message
            failures = failures + 1
            details = details + message

    result = {}
    if failures > 0:
        result["status"] = "Failure"
    else:
        result["status"] = "Success"
    result["statusMessage"] = details
    return result


def execute(data):
    """Execute function supported by sm."""
    SM_EXECUTION_RESULT = addstorage(data)

    print "<JsonResult>" + json.dumps(SM_EXECUTION_RESULT) + "</JsonResult>"


# NOTE: This is only for debugging purposes
if __name__ == '__main__':
    with open('./data_bag.json') as f:
        data = json.load(f)
        execute(data)
