__author__ = 'jnag'


import sys
from collectors import msaasLogCollector


if len(sys.argv) == 1:
    print 'Please provide the list of collectors that need to be used.'
    sys.exit(1)


collectors = sys.argv[1]
snapshotPath = sys.argv[2]

requestedPlugins = []
requestedPlugins = collectors.strip().split(",")

for requestedPlugin in requestedPlugins:
    if requestedPlugin == "msaasLogCollector":
        mysqlLogCollector = msaasLogCollector.msaasLogCollector()
        mysqlLogCollector.collect("msaasLogCollector", "msaasLogCollector", snapshotPath+"/msaasLogCollector")
