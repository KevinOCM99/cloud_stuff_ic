#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = "daniel, pradeep"
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'


class ModuleExecutionReturnClass(object):
    """
    The class which contains the return details of module execution in json object
    """
    import collections
    import json
    import sys

    #JSON_MARKER_START = "**JSON_MARKER_START**"
    #JSON_MARKER_END = "**JSON_MARKER_END**"
    #STATUS_LOG = "statusLog"
    #JOB_LOG = "jobLog"
    #OPERATION_TYPE = "operationType"

    JSON_MARKER_START = "<JsonResult>"
    JSON_MARKER_END = "</JsonResult>"
    STATUS_MESSAGE = "statusMessage"
    STATUS = "status"
    JOB_LOG = "jobLog"
    OPERATION_TYPE = "operationType"
    DETAILS = "Details"
    SERVICE_TYPE = "serviceType"
    SERVICE_NAME = "serviceName"
    RESULT_SECTION = "SM_EXECUTION_RESULT"
    NOT_DELETED_BACKUP_ID="notDeletedBackupIds"

    def __init__(self, logger=None):
        if not logger:
            import logging
            self.logger = logging.getLogger("ModuleExecutionReturnClass")
            logging.basicConfig()
            self.logger.setLevel(logging.DEBUG)
        else:
            self.logger = logger
        self.operation = ""
        self.status_log = ""
        self.job_log = ""
        self.service_type = ""
        self.service_name = ""
        self.operation_detail_dict = dict()
        self.postRestoreBackup_operation_detail_dict = dict()
        self.return_dict = dict()
        self.success = False
        self.status = False
        self.errorType = ""
        self.notDeletedIds = []

    def set_service(self, service_info):
        self.service_type = service_info.get(self.SERVICE_TYPE)
        self.service_name = service_info.get(self.SERVICE_NAME)

    def get_service_type(self):
        return self.service_type

    def get_service_name(self):
        return self.service_name

    def isSuccess(self):
        return self.success

    def set_success(self,value):
        self.success=value

    def set_operation_type(self, operation):
        self.operation = operation

    def get_operation_type(self):
        return self.operation

    def set_operation_detail(self, key, value):
        self.operation_detail_dict[key] = value

    def get_operation_return_detail_as_dict(self):
        return self.operation_detail_dict

    def set_status_log(self, status_log):
        self.status_log = status_log

    def append_status_log(self, status_log_to_be_appended):
        self.status_log += status_log_to_be_appended

    def get_status_log(self):
        return self.status_log

    def set_job_log(self, job_log):
        self.job_log = job_log

    def append_job_log(self, job_log_to_be_appended):
        self.job_log += job_log_to_be_appended

    def get_job_log(self):
        return self.job_log

    def set_bool_status(self, status):
        self.status = status

    def get_bool_status(self):
        return self.status

    def set_postRestoreBackup_operation_detail(self, key, value):
        self.postRestoreBackup_operation_detail_dict[key] = value

    def set_notDeletedBackupIds(self, notDeletedIds):
        self.notDeletedIds = notDeletedIds

    def get_notDeletedBackupIds(self):
        return self.notDeletedIds

    def set_errorType(self, errorType):
        self.errorType = errorType

    def get_errorType(self):
        return self.errorType

    def flush(self, file_descriptor=None):
        #self.return_dict[self.STATUS] = "Success" if self.get_status_log() else "Failure"
        #self.return_dict[self.STATUS] = "Success" if self.get_bool_status() else "Failure"
        if self.get_bool_status():
           self.return_dict[self.STATUS] = "Success"
        elif self.errorType == "Fatal":
           self.return_dict[self.STATUS] = "Fatal"
        else:
           self.return_dict[self.STATUS] = "Failure"

        self.return_dict[self.STATUS_MESSAGE] = self.get_status_log()
        # self.return_dict[self.JOB_LOG] = self.get_job_log()
        # self.return_dict[self.OPERATION_TYPE] = self.get_operation_type()

        self.return_dict[self.RESULT_SECTION] = dict()
        if self.get_operation_type() == "restore" :
           self.return_dict[self.RESULT_SECTION]["postRestoreBackup"] = dict()
           for key in self.postRestoreBackup_operation_detail_dict.keys():
               self.return_dict[self.RESULT_SECTION]["postRestoreBackup"][key] = self.postRestoreBackup_operation_detail_dict.get(key)
        
        self.return_dict[self.RESULT_SECTION][self.SERVICE_TYPE] = self.get_service_type()
        self.return_dict[self.RESULT_SECTION][self.SERVICE_NAME] = self.get_service_name()
        if self.get_operation_type() == "backup" :
           self.return_dict[self.RESULT_SECTION][self.NOT_DELETED_BACKUP_ID] = self.get_notDeletedBackupIds()

        operation_details = self.get_operation_type() + self.DETAILS
        self.return_dict[self.RESULT_SECTION][operation_details] = dict()

        for key in self.operation_detail_dict.keys():
            self.return_dict[self.RESULT_SECTION][operation_details][key] = self.operation_detail_dict.get(key)

        if file_descriptor:
            try:
                file_descriptor.write(self.JSON_MARKER_START + self.json.dumps(self.return_dict, indent=4) +
                                      self.JSON_MARKER_END)
            except Exception as e:
                self.logger.error(str(e))
        else:
            self.sys.stdout.write(self.JSON_MARKER_START + self.json.dumps(self.return_dict, indent=4) +
                                      self.JSON_MARKER_END)

                                                    
