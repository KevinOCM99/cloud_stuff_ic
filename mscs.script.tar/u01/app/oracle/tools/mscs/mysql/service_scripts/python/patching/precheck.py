# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.


import framework
import os,sys
import json
import subprocess
import constants
import json,time
import mysqlutils
from mysqlpatch import Patch

pcontext = None
"""
entry function for the metadaa patching framework
"""
def execute(input_dict_args):
    print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()) ,"INFO",  "Checking for MySQL patch pre-check Process" )
    print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()) ,"INFO", "Formatted input json : " )
    framework.JSONUtil.print_dict_as_json(input_dict_args)

    pcontext=framework.PatchingContext(input_dict_args)
    patch=Patch(pcontext)

    patch.add_message("Checking for MySQL patch pre-check Process")
    patch.log("Object for the class MySQL created successfully")
    if patch.hasVmInstances():
        patch.log("Precheck function is being called")
        result=patch.precheck(precheckLevelFlag=0)
        if result != 0:
            patch.log("Precheck operation failed","ERROR")
            failure_message = patch.context.getFailure()
            status_message = "Precheck operation failed : " + failure_message 
            return patch.exit(result,constants.print_on_stdOut,status_message,"Failure")
        else:
            patch.add_message("Precheck operation got successful")
            patch.log("Precheck operation got successful")
            return patch.exit(result,constants.print_on_stdOut,"Precheck operation got successful","Success")
    else:
        return patch.exit(0,constants.print_on_stdOut,"There is no VM instance","Warning")

if __name__ == '__main__':
    import json
    with open('./data_bag.json') as f:
        data = json.load(f)
    execute(data)