"""This script is used to check the provisioning status of a set of VMs.

a service. The script takes in a JSON formatted payload of hostnames and
servers.
Example:
python check_provisioning_status_rex.py '{"hosts":
                            [{"servers":[{"serverName":
                                "testService10 wls admin","usageType":"admin"},
                                  {"serverName":"testService10 wls 2",
                                  "usageType":"managed"}],
                            "hostName":"testService10-wls-1"}]}'

The script in turn calls the check_logs script on each of the VMs included
in the payload and consolidates the results of the check_logs script execution
on each VM and sends it to standard out in a json format.
"""

import sys
sys.path.append("/u01/app/oracle/tools/paas/bin/platform/python/")
import pythonUtils.execute as executeNew
import json
import os
import base64
import time
sys.path.append(os.path.join(os.path.dirname(__file__), "../utils/"))
import databag_utils
import glob
import urllib2
# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)
import constants


def get_mycnf_property(mysql_property):
    """Get properties from mycnf file."""
    mycnf_property = None
    try:
        with open(constants.MY_CNF) as myCNF:
            for line in myCNF:
                if line.strip().startswith(mysql_property):
                    mycnf_property = line.split('=')[1].strip()
                    break
    except EnvironmentError:
        pass
    return mycnf_property

#gets attributes from compute
def get_compute_attribute(url,retry=10,sleep_time=10):
    for retry_count in range(retry):
        try:
          return urllib2.urlopen(url).readline()
        except urllib2.HTTPError, e:
          if retry_count < retry:
             time.sleep(sleep_time * retry_count) 
    return None
def get_connect_string(payload):
    """Populates connect string."""
    db_name = get_compute_attribute('http://192.0.0.192/latest/attributes/userdata/msaas_db_name')
    hosts = payload["hosts"]
    # Expecting only one host, if more returning 1st one as connect descriptor
    return hosts[0]["publicIpAddress"] + ':' + payload['mysql_port'] + '/' + db_name

def get_component_execution_result(payload):
    """Polpulates Component execution results."""

    COMPONENT_EXECUTION_RESULT = {}
    VM_INSTANCES = {}

    COMPONENT_EXECUTION_RESULT["vmInstances"] = VM_INSTANCES
    COMPONENT_ATTRIBUTES = {}
    COMPONENT_EXECUTION_RESULT["attributes"] = COMPONENT_ATTRIBUTES

    #get the attributes from compute
    
    isCIB = get_compute_attribute('http://192.0.0.192/latest/attributes/userdata/msaas_user_backup_dump_type')
    #check if it is createinstancefrom backup
    if isCIB == 'Yes':
        #get mysql propties from the mycnf.
        #get character-set-server value
        database_char = get_mycnf_property('character-set-server')
        #get collation-server value
        database_collation = get_mycnf_property('collation-server')
        database_time_zone = get_mycnf_property('default-time-zone')

    hosts = payload["hosts"]
    for host in hosts:
        VM_INSTANCE = {}
        VM_INSTANCES[host["hostName"]] = VM_INSTANCE
        # send "MYSQL_CHARACTER_SET" and "MYSQL_COLLATION" only if it is createinstancefrom backup
        if isCIB == 'Yes':
            COMPONENT_ATTRIBUTES["MYSQL_CHARACTER_SET"] = database_char
            COMPONENT_ATTRIBUTES["MYSQL_COLLATION"] = database_collation
            COMPONENT_ATTRIBUTES["MYSQL_TIMEZONE"] = database_time_zone
        servers = host["servers"]
        VM_INSTANCE_SERVERS = {}
        VM_INSTANCE["servers"] = VM_INSTANCE_SERVERS
        for server in servers:
            VM_INSTANCE_SERVER = {}
            VM_INSTANCE_SERVERS[server["serverName"]] = VM_INSTANCE_SERVER
            SERVER_ATTRIBUTES = {}
            VM_INSTANCE_SERVER["attributes"] = SERVER_ATTRIBUTES
    return COMPONENT_EXECUTION_RESULT


def check_logs(payload):
    """For each host in the hostmap, the check logs script is executed.

    The result is then stored in the results array.
    """
    dir = os.path.dirname(os.path.abspath(__file__))
    hosts = payload["hosts"]
    CHECK_LOG_RESULT = {}
    CHECK_LOG_RESULT["SM_EXECUTION_RESULT"] = {}
    ATTRIBUTES = {}
    CHECK_LOG_RESULT["SM_EXECUTION_RESULT"]["attributes"] = ATTRIBUTES

    hosts_in_progress = 0
    hosts_failed = 0
    error = []
    hostsChecked = []

    for host in hosts:
        hostsChecked.append(host["hostName"])
        cmdTemplate = "cd {0}; python check_logs.py '{1}'"
        encodedJsonPayload = base64.b64encode(json.dumps(host))
        cmd = cmdTemplate.format(dir, encodedJsonPayload)
        print "Executing command " + cmd
        executeResult = executeNew.execute_cmd(cmd, host["hostName"], log_status_msgs=False)
        if executeResult.get_return_code() != 0:
            error.append("Failed to execute provisioning check on host "+ host["hostName"] + executeResult.get_err())
        else:
            serverResultJson = executeResult.get_output()
            serverResults = json.loads(serverResultJson)
            for logResult in serverResults:
                if logResult["status"] == "InProgress":
                    hosts_in_progress = hosts_in_progress + 1
                if logResult["status"] == "Failed":
                    errorMessageFormat = "Provisioning failed on host {0} . Following errors were found in the log {1} : [{2}]"
                    errorMessage = errorMessageFormat.format(host["hostName"],  logResult["file"], ";".join(logResult["error"]))
                    error.append(errorMessage)
                    hosts_failed = hosts_failed + 1
    if hosts_in_progress > 0:
        CHECK_LOG_RESULT["status"] = "InProgress"
    elif hosts_failed > 0:
        CHECK_LOG_RESULT["status"] = "Failure"
        CHECK_LOG_RESULT["statusMessage"] = ";".join(error)
    else:
        CHECK_LOG_RESULT["status"] = "Success"
        CHECK_LOG_RESULT["statusMessage"] = "Provisioning Succeeded on hosts: "+",".join(hostsChecked)
    return CHECK_LOG_RESULT


def printLog(filePath, status='Success'):
    files = glob.glob(filePath)
    for fileName in files:
        with open(fileName) as logFile:
            for line in logFile:
                if(status == 'Failure'):
                    print line.strip()
                else:
                    if '[DEBUG]' in line:
                        pass
                    else:
                        print line.strip()
    return True

def print_log_file(filePath):
    try:
        files = glob.glob(filePath)
        for fileName in files:
            with open(fileName) as logFile:
                for line in logFile:
                    print line.strip()
    except Exception as e: 
        print "exceprion " + str(e)





def calculate_time_to_sleep(wait_time_remaining, last_sleep_time, max_wait_time = 3600, min_sleep_time = 5, average_provisioning_time = 103, max_sleep_time = 60):
    """ return time_to_sleep based on average_provisioning_time , iteration_count,
     max_wait_time, last_sleep_time and min_sleep_time
     LOGIC : keep more retries near average time, if average time is crossed return min_sleep_time.
    """
    time_took = max_wait_time - wait_time_remaining

    next_sleep_time = min_sleep_time

    if(time_took < average_provisioning_time):
        next_sleep_time = last_sleep_time / 2 
        avg_time_remainig = average_provisioning_time - time_took
        if (avg_time_remainig < next_sleep_time):
            next_sleep_time = min_sleep_time
        else:
            next_sleep_time = (avg_time_remainig / 2 )
    else:
        next_sleep_time = min_sleep_time

    # make sure to return a sleep time between min and max
    if next_sleep_time < min_sleep_time:
        next_sleep_time = min_sleep_time
    if next_sleep_time > max_sleep_time:
        next_sleep_time = max_sleep_time

    return next_sleep_time


def execute(data): 
    """LOGIC: minimize the delay in provisioning by reducing wait in provisioning check. 
        So return a result as fast as possible keeping less frequency of polling. 
        Average  waiting time during testing was 103 seconds. So initializing initial wait in loop to be 60 sec. 
    """ 
    simplifiedPayload = databag_utils.simplify_payload(data)
    componentName = databag_utils.get_component_name(data)

    max_wait_time = 3600 
    waiting_time_remaining = max_wait_time
    iteration_count = 0
    min_sleep_time = 5
    max_sleep_time = 60
    time_to_sleep = max_sleep_time

    while (waiting_time_remaining > 0):
        iteration_count = iteration_count + 1
        CHECK_LOG_RESULT = check_logs(simplifiedPayload)
        # check status
        if CHECK_LOG_RESULT["status"] != "InProgress":
            status = CHECK_LOG_RESULT["status"]
            # print mscs provisioning log
            mount_point = get_compute_attribute("http://192.0.0.192/latest/attributes/storage_map/tools/mountpoint")
            msaas_log_file = mount_point + "/" + constants.MSAAS_HOME_FOLDER + "/" + \
                            constants.MSAAS_LOG_FOLDER + "/" + constants.MSAAS_PROVISIONING_LOG_NAME
            print "-------OUTPUT From VM Provisioning Log-------"
            printLog(msaas_log_file, status)
            print "-------OUTPUT From VM Provisioning Log-------"
            #service attribute list
            SERVICE_ATTRIBUTES = {}

            #logic to create Component Execution Result
            COMPONENT_EXECUTION_RESULTS = {}
            COMPONENT_EXECUTION_RESULT = get_component_execution_result(simplifiedPayload)
            COMPONENT_EXECUTION_RESULT["attributes"]['CONNECT_STRING'] = get_connect_string(simplifiedPayload)
            COMPONENT_EXECUTION_RESULTS[componentName] = COMPONENT_EXECUTION_RESULT
            SM_EXECUTION_RESULT = CHECK_LOG_RESULT
            SM_EXECUTION_RESULT["SM_EXECUTION_RESULT"]["components"] = \
                COMPONENT_EXECUTION_RESULTS
            SM_EXECUTION_RESULT["SM_EXECUTION_RESULT"]['attributes'] = SERVICE_ATTRIBUTES

            # print error and debug log(on Failure)
            print "----OUTPUT FROM error log continue-service-start.sh----"
            print_log_file(constants.ERROR_LOG)
            print "----OUTPUT FROM error log continue-service-start.sh----"

            if(status == "Failure"):
                print "----OUTPUT FROM debug log continue-service-start.sh----"
                print_log_file(constants.DEBUG_LOG)
                print "----OUTPUT FROM debug log continue-service-start.sh----"
            try:
                os.remove(constants.DEBUG_LOG)
                os.remove(constants.ERROR_LOG)
            except Exception as e:
                print "error in deleting logs " + str(e)

            # json result for SM
            print "<JsonResult>" + json.dumps(SM_EXECUTION_RESULT) + "</JsonResult>"
            break
        else:
            print 'Provisioning is still in progress, retrying status check after {0}Seconds'.format(time_to_sleep)
            time.sleep(time_to_sleep)
            waiting_time_remaining = waiting_time_remaining - time_to_sleep
            time_to_sleep = calculate_time_to_sleep(waiting_time_remaining, time_to_sleep)

# NOTE: This is only for debugging purposes
if __name__ == '__main__':
    import json
    with open('./data_bag.json') as f:
        data = json.load(f)
    execute(data)
