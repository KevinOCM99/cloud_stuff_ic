
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import abc
import os
import constants
import shutil
import urlparse
import time
import msaas_common_lib as common_lib


#
##
###
def clock(func):
    """
    Decorator function for decorating functions that need timing information
    """
    from datetime import  datetime

    def clocked(*args):
        name = func.__name__
        common_lib.logger("INFO","Entering {name}.".format(name=name))
        startTime = datetime.now()
        result = func(*args)
        duration = datetime.now() - startTime
        duration = duration.seconds * 1000 + duration.microseconds / 1000.0
        common_lib.logger("INFO","Leaving {name}.".format(name=name))
        common_lib.logger("INFO","Total time spent on {name} in milliseconds {duration}".format(name=name, duration=duration))
        return result
    return clocked

def extractMEBBackupBMC(mebCloudStorageUser, mebCloudStoragePassword, mebCloudStorageURI, cloudStorageContainer, cloudObject, backupDir ):
    executor = common_lib.Executor()
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER  +  " "
               "--cloud-service=openstack "
               " --cloud-user-id='" + mebCloudStorageUser + "'"
               " --cloud-password='" + mebCloudStoragePassword + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(mebCloudStorageURI) + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --backup-dir=" + backupDir + "/temp "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-  extract  " )

    extractCmdForPrint = extractCmd.replace(mebCloudStoragePassword, "XXXXXXXX")

    common_lib.logger("INFO","Executing extract command: {extractCommand}"\
                                            .format(extractCommand=extractCmdForPrint))
    exe_result = executor.execute_cmd(commandline=extractCmd, command_for_print=extractCmdForPrint)
    common_lib.logger("INFO","===============Output from mysqlbackup (extract) ================")
    std_out = exe_result.get_std_out()
    std_err = exe_result.get_std_err()
    print exe_result.get_std_out()
    print exe_result.get_std_err()

    if exe_result.get_return_code() != 0:
       common_lib.logger("ERROR","Extract backup from cloud failed.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20814>: Extract backup from cloud failed.")
       
       return op_return_obj

    common_lib.logger("INFO","Extracting backup from cloud storage succeeded.")

    return op_return_obj

def extractMEBBackup(mebCloudStorageUser, mebCloudStoragePassword, mebCloudStorageURI, cloudStorageContainer, cloudObject, backupDir ):
    executor = common_lib.Executor()
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER  +  " "
               "--cloud-service=openstack "
               " --cloud-user-id='" + mebCloudStorageUser + "'"
               " --cloud-password='" + mebCloudStoragePassword + "'"
               " --cloud-tempauth-url=" + mebCloudStorageURI + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --backup-dir=" + backupDir + "/temp "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-  extract  " )

    extractCmdForPrint = extractCmd.replace(mebCloudStoragePassword, "XXXXXXXX")

    common_lib.logger("INFO","Executing extract command: {extractCommand}"\
                                            .format(extractCommand=extractCmdForPrint))
    exe_result = executor.execute_cmd(commandline=extractCmd, command_for_print=extractCmdForPrint)
    common_lib.logger("INFO","===============Output from mysqlbackup (extract) ================")
    std_out = exe_result.get_std_out()
    std_err = exe_result.get_std_err()
    print exe_result.get_std_out()
    print exe_result.get_std_err()

    if exe_result.get_return_code() != 0:
       common_lib.logger("ERROR","Extract backup from cloud failed.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20814>: Extract backup from cloud failed.")
       
       return op_return_obj

    common_lib.logger("INFO","Extracting backup from cloud storage succeeded.")

    return op_return_obj

def logErrorParser(logStream):
    """
	
    Parses the log stream from meb for error and concatenates the multi line errors into single line
    """
    import re
    #Read  the log stream
    logLines =  logStream.split('\r\n')
    errorMessage = ' ERROR'
    for line in logLines:
        if "ERROR:" in line:
           errorMessage = errorMessage + ':' + re.search('ERROR:(.*)',line).group(1)
    return errorMessage
              
def isPartial(backupDir):
    with open(backupDir + '/temp/meta/backup_variables.txt') as file:
       for line in file:
         if 'is_partial=1' in line:
            common_lib.logger("INFO","Backup indentified as TTS partial")
            return True

    common_lib.logger("INFO","Backup indentified as Full")
    return False



class CreateInstanceFactory():
    """
    CreateInstance factory class
    """

    def __init__(self, dictionaryData):
        self.dictionaryData = dictionaryData

    def get_CreateInstanceObject(self):
        """
        Returns createInstance object based on the extension of the backup file provided.
        """
        try:
           uriTokens = urlparse.urlparse(self.dictionaryData['backupPath'])
           path = uriTokens.path
           isBMC = True if self.dictionaryData['backupPath'].startswith("https://swiftobjectstorage") else False
           if path.endswith('.sql.gz') :
              common_lib.logger("INFO","The backup file identified as mysqldump file.")
              return CreateInstanceFromSQLDump(self.dictionaryData)
           elif path.endswith('.mbi') :
              common_lib.logger("INFO","The backup file identified as MEB single image backup file.")
              #download and extract
              backupEnabled = True if self.dictionaryData['backupEnabled'] == 'True' else False
              cloudStorageUser=self.dictionaryData['dumpCloudUser']
              cloudStoragePassword=self.dictionaryData['dumpCloudUserPassword']
              backupPath=self.dictionaryData['backupPath']
              uriTokens = urlparse.urlparse(backupPath)
              path = uriTokens.path
              pathTokens = path.split('/')

              cloudStorageURI = uriTokens.scheme + "://" + uriTokens.netloc
              cloudStorageURIBMC = uriTokens.scheme  + "://" + uriTokens.netloc + '/'.join(pathTokens[0:4])
              cloudStorageContainer = pathTokens[3]
              cloudStorageServiceInstance = pathTokens[2]
              cloudStorageObjectPath = '/'.join(pathTokens[4:])
              mebCloudStorageUser=cloudStorageServiceInstance  + ":" +  cloudStorageUser
              if isBMC:
                 extract_return_obj = extractMEBBackupBMC(cloudStorageUser, cloudStoragePassword, cloudStorageURIBMC, cloudStorageContainer, cloudStorageObjectPath, constants.MYSQLDUMP_TEMP_LOCATION_BACKUP if backupEnabled else constants.MYSQLDUMP_TEMP_LOCATION_DATA )
              else:
                 extract_return_obj = extractMEBBackup(mebCloudStorageUser, cloudStoragePassword, cloudStorageURI, cloudStorageContainer, cloudStorageObjectPath, constants.MYSQLDUMP_TEMP_LOCATION_BACKUP if backupEnabled else constants.MYSQLDUMP_TEMP_LOCATION_DATA )
              if not extract_return_obj.get_bool_status():
                 common_lib.logger("ERROR", "Extraction of backup from Oracle cloud storage failed.")
                 raise ValueError("Extraction of backup from Oracle cloud storage failed.")
 
              #check if backup is partial or full
              if isPartial(constants.MYSQLDUMP_TEMP_LOCATION_BACKUP if backupEnabled else constants.MYSQLDUMP_TEMP_LOCATION_DATA ):
                 return CreateInstanceFromMEBTTSBackupImageBMC(self.dictionaryData) if isBMC else CreateInstanceFromMEBTTSBackupImage(self.dictionaryData)
              else:
                 return CreateInstanceFromMEBFullBackupImageBMC(self.dictionaryData) if isBMC else CreateInstanceFromMEBFullBackupImage(self.dictionaryData)
           else:
              return None
        except KeyError as e:
           common_lib.logger("ERROR","Expected backupPath key missing in the input JSON.")
           raise KeyError
        except ValueError as e:
           common_lib.logger("ERROR",e.args)
           raise ValueError

class CreateInstance:
    """
    An abstact restore class
    """

    __metaclass__  = abc.ABCMeta

    def __init__(self, dictionaryData):
        try:
           self.dictionaryData = dictionaryData
           self.backupEnabled = True if self.dictionaryData['backupEnabled'] == 'True' else False
           self.backupPath = dictionaryData['backupPath']
           self.cloudStorageUser = dictionaryData['dumpCloudUser']
           self.cloudStoragePassword = dictionaryData['dumpCloudUserPassword']
           #ToDo make sure this is correct
           uriTokens = urlparse.urlparse(self.backupPath)
           path = uriTokens.path
           pathTokens = path.split('/')

           #check if path has version, serviceInstance,container and object path assumes 'https:/storage.oracle.com/vi/serviceInstance-domain/container/objectPath'
           if len(pathTokens) < 4:
              raise ValueError

           self.cloudStorageURI = uriTokens.scheme + "://" + uriTokens.netloc
           self.cloudStorageURIBMC = uriTokens.scheme  + "://" + uriTokens.netloc + '/'.join(pathTokens[0:4])
           self.cloudStorageContainer = pathTokens[3]
           self.cloudStorageServiceInstance = pathTokens[2]
           self.cloudStorageObjectPath = '/'.join(pathTokens[4:])
           self.logDir = common_lib.get_logDir()

           #from contsants.py
           #is there a way to get the following from
           self.mebLocation = constants.MEB_LOC
           self.mySQLClientLocation = constants.MSQLPATH
           self.MySQLUser = constants.MYSQL_USER
           self.tempBackupDirectory = constants.MYSQLDUMP_TEMP_LOCATION_BACKUP if self.backupEnabled else constants.MYSQLDUMP_TEMP_LOCATION_DATA
           self.dataDirectory = constants.DATA_DIR

           if not self.logDir:
              self.logDir = self.dataDirectory

        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing in the input JSON.")
           raise KeyError
        except ValueError as e:
           common_lib.logger("ERROR","The absolute backup URL is not well formed.")
           raise ValueError("The absolute backup URL is not well formed.")


    @abc.abstractmethod
    def createInstancePreCheck(self):
        return None

    @abc.abstractmethod
    def preCreateInstanceSetup(self):
        return None

    @abc.abstractmethod
    def createInstance(self):
        return None

    @abc.abstractmethod
    def cleanUp(self):
        return None

    @abc.abstractmethod
    def postCreateInstanceSetup(self):
        return None

    def get_dictionaryData(self):
        return self.dictionaryData

    def get_backupPath(self):
        return self.backupPath

    def get_cloudStorageUser(self):
        return self.cloudStorageUser

    def get_cloudStoragePassword(self):
        return self.cloudStoragePassword

    def get_cloudStorageURI(self):
        return self.cloudStorageURI
  
    def get_cloudStorageURIBMC(self):
        return self.cloudStorageURIBMC

    def get_cloudStorageContainer(self):
        return self.cloudStorageContainer

    def get_cloudStorageServiceInstance(self):
        return self.cloudStorageServiceInstance

    def get_cloudStorageObjectPath(self):
        return self.cloudStorageObjectPath

    def get_logDir(self):
        return self.logDir

    def get_MEBLocation(self):
        return self.mebLocation

    def get_mySQLClientLocation(self):
        return self.mySQLClientLocation

    def get_MySQLUser(self):
        return self.MySQLUser

    def get_tempBackupDirectory(self):
        return self.tempBackupDirectory

    def get_dataDirectory(self):
        return self.dataDirectory

    def get_pathToMySQLInstallScript(self):
        """
        Gets mysqlInstallScript(provisioning) path
        """
        #get the script directory
        tools_path=os.path.realpath(__file__)
        #build path to the mysql-instalation-utils.sh
        mysql_install_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"
        return mysql_install_script

    def get_host(self):
        """
        Gets the hostname of the VM
        """
        import socket
        return socket.gethostname()

    @clock
    def stopMySQL(self):
        """
        Runs shutdownMysql function with in the mysql-installation-utils.sh
        ToDo : May be this should go to common lib
        """
        common_lib.logger("INFO","Executing stopMySQL(), shuting down mysql server.")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()

        cmd = "source {mysql_install_script} && shutdownMysql {mysqluser}".format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser())
        common_lib.logger("INFO","Running command " + cmd)
        cmd_result = executor.execute_cmd(cmd)
        print cmd_result.std_out
        if cmd_result.get_return_code() == 0:
           common_lib.logger("INFO","MySQL server is shutdown.")
           op_return_obj.set_bool_status(True)
           op_return_obj.set_status_msg("MySQL server is shutdown.")
        else:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20903>: MySQL server has failed to shutdown.")

        return op_return_obj

    @clock
    def startMySQL(self, argument=""):
        """
        Runs startMysql function with in the mysql-installation-utils.sh
        ToDo : May be this should go to common lib
        """
        common_lib.logger("INFO","Executing startMySQL(), starting mysql server.")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()

        cmd = "source {mysql_install_script} && startMysql {mysqluser} {args} "\
                        .format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser(), args=argument)
        common_lib.logger("INFO","Running command " + cmd)
        cmd_result = executor.execute_cmd(cmd)
        print cmd_result.std_out
        if cmd_result.get_return_code() == 0:
           common_lib.logger("INFO","MySQL server started.")
           op_return_obj.set_bool_status(True)
           op_return_obj.set_status_msg("MySQL server started.")
        else:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20904>: MySQL server has failed to start.")

        return op_return_obj


    @clock
    def checkMySQLStatus(self):
        """
        Confirms if the MySQL is up and accepting connections.
        Invokes getMysqlStatus function in mysql-installation-utils.sh
        Returns execution result an instance of CMDExecutionResultClass() in common lib.
        ToDo : May be this should go to common lib
        """
        common_lib.logger("INFO","Verifying connection to MySQL")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        cmd = "source {mysql_install_script} && getMysqlStatus {mysqluser}"\
                         .format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser())
        common_lib.logger("INFO","Running command " + cmd)
        result = executor.execute_cmd(cmd)
        if result.get_return_code() != 0:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("MySQL server not started yet.")

        return  op_return_obj

    def cleanUp(self):
        """
        Cleans up the temporary work directory created during the instance creation
        """
        import shutil

        common_lib.logger("INFO","Deleting the temporary work directory {tmpDir}".format(tmpDir=self.get_tempBackupDirectory()))
        shutil.rmtree(self.get_tempBackupDirectory(), ignore_errors=True)



class CreateInstanceFromSQLDump(CreateInstance):
    """
    Class implements the CreateInstance class
    Provides behaviour for instance creation from mysqldump file
    """
    def __init__(self, dictionaryData):
        CreateInstance.__init__(self, dictionaryData)

    @clock
    def createInstancePreCheck(self):
        """
        Performs pre-check for instance creation using mysqldump file.
        """
        common_lib.logger("INFO","Performing pre-check for instance creation, if backup files provided exists and followed the naming convention.")
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        op_return_obj.set_status_msg("Create instance pre-check successfull.")
        executor = common_lib.Executor()
        #Check if the dump file exists in the oracle cloud storage
        #obtain the cloud attributes
        source = self.get_backupPath()
        credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()

        #verify the mysql dump file on oracle storage
        common_lib.logger("INFO","Checking if backup file {file} exists in the cloud storage.".format(file=source))
        verify_return_obj = common_lib.verifyObjectOnCloud(source, credential);
        if not verify_return_obj.get_bool_status():
           common_lib.logger("ERROR","Backup file could not be verified on the cloud. {error}".format(error=verify_return_obj.get_status_msg()))
           op_return_obj.set_status_msg("<MSCS-ERR-20714>: Backup file could not be verified on the cloud. " + verify_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj
        common_lib.logger("INFO","Backup file {file} exists in the cloud storage.".format(file=source))

        return op_return_obj

    def isFileASCII(self, file):
        """
          Checks the file type.
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        executor = common_lib.Executor()
        common_lib.logger("INFO","Checking if the mysqldump file {file} is an ASCII file.".format(file=file))
        file_check_command = "file {file}|grep -i ASCII".format(file=file)
        exe_result = executor.execute_cmd(file_check_command)
        if exe_result.get_return_code() != 0:
           return False
        return True


    @clock
    def unzipFile(self, file):
        """
          Unzip the backup gzip file.
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        executor = common_lib.Executor()
        common_lib.logger("INFO","Un-compressing the backup gzip file {file}".format(file=file))
        file_check_command = "gunzip {file}".format(file=file)
        exe_result = executor.execute_cmd(file_check_command)
        if exe_result.get_return_code() != 0:
           common_lib.logger("ERROR","Un-compressing the backup gzip file {file} failed, make sure it is a gzip file".format(file=file))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20718>: Unable to uncompress the backup gzip file {file} failed, make sure it is a gzip file".format(file=file))
           return op_return_obj
        return op_return_obj

    @clock
    def downLoadSQLDump(self):
        """
          Downloads backup file from url supplied to a temp location

        """

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        executor = common_lib.Executor()
        #get the mysqldump source
        source = self.get_backupPath()
        target = self.get_tempBackupDirectory()
        #if temp directory does not exist create one

        if not os.path.isdir(target):
           common_lib.logger("INFO","Creating the temporary work directory {mysqldump_dir}. ".format(mysqldump_dir=target))
           executor = common_lib.Executor()
           exe_result = executor.execute_cmd("mkdir -p {mysqldump_dir}".format(mysqldump_dir=target))
           if exe_result.get_return_code() != 0:
              common_lib.logger("ERROR","Unable to create temp directory {tempDir}. Reason: {reason}"
                                          .format(reason=exe_result.get_detail(),tempDir=target))
              op_return_obj.set_status_msg("<MSCS-ERR-20716>: Unable to create temp directory")
              op_return_obj.set_bool_status(False)
              return op_return_obj
        common_lib.logger("INFO","Temporary work directory {mysqldump_dir} created. ".format(mysqldump_dir=target))

        target = os.path.join(self.get_tempBackupDirectory(), "backup.sql.gz")
        #obtain the cloud attributes
        credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()

        #download the mysql dump
        common_lib.logger("INFO","Downloading {source} into {target}. ".format(source=source, target=target))
        download_return_obj = common_lib.downloadObjectFromCloud(source, target, credential);

        return download_return_obj



    @clock
    def preCreateInstanceSetup(self):
        """
        Perfotm presetup for instance creation.
          1. download backup file from cloudStorage
          2. shutdown MySQL
          2. startup MySQL with mysql_engine enabled
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        #perform pre-check
        precheck_return_obj = self.createInstancePreCheck()
        if not precheck_return_obj.get_bool_status():
           op_return_obj.set_status_msg(precheck_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        download_return_obj = self.downLoadSQLDump()
        if not download_return_obj.get_bool_status():
           common_lib.logger("ERROR", "Downloading {source} into {target} failed. {reason} ".format(source=source, target=target, reason=download_return_obj.get_status_msg()))
           op_return_obj.set_status_msg("<MSCS-ERR-20717>: Downloading backup dump file from Oracle Cloud Storage failed.")
           op_return_obj.set_bool_status(False)
           return op_return_obj

        #unzip the file
        unzip_return_obj =  self.unzipFile(os.path.join(self.get_tempBackupDirectory(), "backup.sql.gz"))
        if not unzip_return_obj.get_bool_status():
           op_return_obj.set_status_msg(unzip_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj


        #check if the downloaded file is ASCII
        ascii_file = self.isFileASCII(os.path.join(self.get_tempBackupDirectory(), "backup.sql"))
        if not ascii_file:
           common_lib.logger("ERROR", "The mysqldump file is not an ASCII file.")
           #op_return_obj.set_status_msg("<MSCS-ERR-20715>: The mysqldump file is not an ASCII file.")
           #op_return_obj.set_bool_status(False)
           #return op_return_obj

        return_obj = self.stopMySQL()
        if not return_obj.get_bool_status():
           common_lib.logger("ERROR", "MySQL server has failed to shutdown")
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return_obj = self.startMySQL("--skip-networking --disabled-storage-engines=")
        if not return_obj.get_bool_status():
           common_lib.logger("ERROR", "MySQL server has failed to start.")
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        common_lib.logger("INFO", "Checking MySQL status.")
        check_result = self.checkMySQLStatus()
        for iter in range(1,6):
            if check_result.get_bool_status():
               common_lib.logger("INFO","MySQL server accepting connection.")
               break
            common_lib.logger("INFO", "MySQL is not ready yet, will check again in %i seconds." % (iter * 10))
            time.sleep(iter * 10 )
            check_result = self.checkMySQLStatus()
        else:
            if not check_result.get_bool_status():
               common_lib.logger("ERROR","MySQL could not be started")
               op_return_obj.set_status_msg("<MSCS-ERR-20718>: MySQL server is not accepting connections.")
               op_return_obj.set_bool_status(False)
            return op_return_obj

        return op_return_obj

    @clock
    def createInstance(self):
        """
          1.Performs preCreateSetup
          2.Performs the import
          3.Performs the postCreateSetup
        """

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        preCreate_return_obj = self.preCreateInstanceSetup()
        if not preCreate_return_obj.get_bool_status():
           op_return_obj.set_status_msg(preCreate_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        importMySQLDump_return_obj = self.importMySQLDump()
        if not importMySQLDump_return_obj.get_bool_status():
           op_return_obj.set_status_msg("<MSCS-ERR-20719>: Could import the mysqldump.")
           op_return_obj.set_bool_status(False)
           return op_return_obj

        postCreate_return_obj = self.postCreateInstanceSetup()
        if not postCreate_return_obj.get_bool_status():
           op_return_obj.set_status_msg(postCreate_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj


    @clock
    def postCreateInstanceSetup(self):
        """
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        return_obj = self.stopMySQL()
        if not return_obj.get_bool_status():
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return_obj = self.startMySQL("--skip-grant-tables")
        if not return_obj.get_bool_status():
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj


    @clock
    def importMySQLDump(self):
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        common_lib.logger("INFO","Starting to apply the mysqldump.")
        reset_master_command = self.get_ResetMasterCommand()
        exe_result = executor.execute_cmd(reset_master_command, command_for_print=reset_master_command)
        if exe_result.get_return_code() != 0 :
           common_lib.logger("ERROR","Failed to run the command {command}.".format(command=reset_master_command))
           common_lib.logger("ERROR",exe_result.get_std_out() + exe_result.get_std_err())
           op_return_obj.set_status_msg(exe_result.get_std_out() + exe_result.get_std_err())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        import_dump_command = self.get_CreateInstanceCommand()
        exe_result = executor.execute_cmd(import_dump_command, successful_return_code_list=[1840,0],command_for_print=import_dump_command)
        if exe_result.get_return_code() != 0 :
           common_lib.logger("ERROR","Failed to run the command {command}.".format(command=import_dump_command))
           common_lib.logger("ERROR",exe_result.get_std_out() + exe_result.get_std_err())
           op_return_obj.set_status_msg(exe_result.get_std_out() + exe_result.get_std_err())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        common_lib.logger("INFO","Finished applying the mysqldump.")
        return op_return_obj

    def get_ResetMasterCommand(self):
        """
        Generates the mysql command for resetting master
        """
        reset_master_command = self.get_mySQLClientLocation() + "/mysql -u" + self.get_MySQLUser() + " -e 'RESET MASTER;'"

        return reset_master_command

    def get_CreateInstanceCommand(self):
        """
        Generates the mysql command for restoring from mysqldump
        """
        dumpFileLocation = os.path.join(self.get_tempBackupDirectory(), "backup.sql")

        import_dump_command = self.get_mySQLClientLocation() + "/mysql -u" + self.get_MySQLUser() + " -f < " + dumpFileLocation

        return  import_dump_command


class CreateInstanceFromMEBBackup(CreateInstance):

    """
    user data distribution could be total different than
    innodb data
    data dir
    log dir
    any non system tablespaces using symbolic link

    Class implement the CreateInstance class
    Provides behaviour for instance creation from mysqldump file
    """
    def __init__(self, dictionaryData):
        CreateInstance.__init__(self, dictionaryData)

    @clock
    def MEBBackupValidate(self):
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        validateCommand, validateCommandForPrint = self.get_ValidateBackupCommand()
        common_lib.logger("INFO","Executing validate backup command: {validateCommand}"\
                                            .format(validateCommand=validateCommandForPrint))
        exe_result = executor.execute_cmd(commandline=validateCommand, command_for_print=validateCommandForPrint)
        common_lib.logger("INFO","===============Output from mysqlbackup (restore) ================")
        std_out = exe_result.get_std_out()
        std_err = exe_result.get_std_err()
        print exe_result.get_std_out()
        print exe_result.get_std_err()

        #if restore fails exit with error
        if exe_result.get_return_code() != 0:
           common_lib.logger("ERROR","Validation of backup image file {file} on Oracle Cloud Storage failed.".format(file=self.get_backupPath()))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20720>: Validation of backup image file on Oracle Cloud Storage failed. Make sure the back is a compressed single file created using MySQL Enterprise Backup.")
           return op_return_obj

        common_lib.logger("INFO","Validation of backup image file {file} on Oracle Cloud Storage succeeded.".format(file=self.get_backupPath()))

        return op_return_obj

    @clock
    def createInstancePreCheck(self):
        """
        Performs pre-check for instance creation using  MEB backup image file.
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        #Validate the backup on cloud
        validate_return_obj = self.MEBBackupValidate()
        if not validate_return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg(validate_return_obj.get_status_msg())
           return op_return_obj


        common_lib.logger("INFO","Pre-checks completed successfully.")
        return op_return_obj


    @clock
    def mySQLMEBRestore(self):
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        restoreCommand, restoreCommandForPrint = self.get_CreateInstanceCommand()
        common_lib.logger("INFO","Executing restore command: {restoreCommand}"\
                                            .format(restoreCommand=restoreCommandForPrint))
        exe_result = executor.execute_cmd(commandline=restoreCommand, command_for_print=restoreCommandForPrint)
        common_lib.logger("INFO","===============Output from mysqlbackup (restore) ================")
        std_out = exe_result.get_std_out()
        std_err = exe_result.get_std_err()
        print exe_result.get_std_out()
        print exe_result.get_std_err()

        #if restore fails exit with error
        if exe_result.get_return_code() != 0:
           mebError = logErrorParser(exe_result.get_std_err())   
           common_lib.logger("ERROR","Restore backup from cloud failed." + mebError)
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20804>: Restoring backup from cloud failed." + mebError)
           return op_return_obj

        common_lib.logger("INFO","Restoring backup from cloud storage succeeded.")

        return op_return_obj



    @clock
    def createInstance(self):
        """
          1.Performs preCreateSetup
          2.Performs the import
          3.Performs the postCreateSetup
        """

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        preCreate_return_obj = self.preCreateInstanceSetup()
        if not preCreate_return_obj.get_bool_status():
           op_return_obj.set_status_msg(preCreate_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        mySQLMEBRestore_return_obj = self.mySQLMEBRestore()
        if not mySQLMEBRestore_return_obj.get_bool_status():
           op_return_obj.set_status_msg(mySQLMEBRestore_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        postCreate_return_obj = self.postCreateInstanceSetup()
        if not postCreate_return_obj.get_bool_status():
           op_return_obj.set_status_msg(postCreate_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj



    def get_ValidateBackupCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        validateCommand =(   self.get_MEBLocation() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageServiceInstance() + ":" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_cloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- validate " )

        validateCommandForPrint = validateCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return validateCommand, validateCommandForPrint

class CreateInstanceFromMEBTTSBackupImage(CreateInstanceFromMEBBackup):

    def __init__(self, dictionaryData):
        CreateInstanceFromMEBBackup.__init__(self, dictionaryData)

    @clock
    def preCreateInstanceSetup(self):
        """
        """

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        precheck_return_obj = self.createInstancePreCheck()
        if not precheck_return_obj.get_bool_status():
           op_return_obj.set_status_msg(precheck_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj

    @clock
    def postCreateInstanceSetup(self):
        """
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        self.cleanUp()
        
        return_obj = self.stopMySQL()
        if not return_obj.get_bool_status():
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        #start with skip gants
        return_obj = self.startMySQL("--skip-grant-tables")
        if not return_obj.get_bool_status():
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj


    def get_CreateInstanceCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        restoreCommand =(   self.get_MEBLocation() + " --user="  + self.get_MySQLUser() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageServiceInstance() + ":" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_cloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --backup-dir=" + self.get_tempBackupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --datadir=" + self.get_dataDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return restoreCommand, restoreCommandForPrint

class CreateInstanceFromMEBTTSBackupImageBMC(CreateInstanceFromMEBTTSBackupImage):

    def __init__(self, dictionaryData):
        CreateInstanceFromMEBTTSBackupImage.__init__(self, dictionaryData)

    def get_ValidateBackupCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        validateCommand =(   self.get_MEBLocation() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.get_cloudStorageURIBMC()) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- validate " )

        validateCommandForPrint = validateCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return validateCommand, validateCommandForPrint

    def get_CreateInstanceCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        restoreCommand =(   self.get_MEBLocation() + " --user="  + self.get_MySQLUser() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.get_cloudStorageURIBMC()) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_tempBackupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --datadir=" + self.get_dataDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return restoreCommand, restoreCommandForPrint

class CreateInstanceFromMEBFullBackupImage(CreateInstanceFromMEBBackup):

    def __init__(self, dictionaryData):
        CreateInstanceFromMEBBackup.__init__(self, dictionaryData)
        self.fileExclusionList = constants.FILE_EXCLUSION_LIST
        self.dirExclusionList = constants.DIR_EXCLUSION_LIST

    def get_fileExclusionList(self):
        return self.fileExclusionList

    def get_dirExclusionList(self):
        return self.dirExclusionList    


    @clock
    def preCreateInstanceSetup(self):
        """
        """

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        precheck_return_obj = self.createInstancePreCheck()
        if not precheck_return_obj.get_bool_status():
           op_return_obj.set_status_msg(precheck_return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return_obj = self.stopMySQL()
        if not return_obj.get_bool_status():
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        delete_return_obj = common_lib.remove_file_with_same_pattern(self.get_logDir(),".*")
        if not delete_return_obj.get_bool_status():
           common_lib.logger("ERROR","Failed to delete innodb redo logs in {dir}".format(dir=self.get_logDir()))
           op_return_obj.set_status_msg("Failed to delete innodb redo logs.")
           op_return_obj.set_bool_status(False)
           return op_return_obj

        #data directory cleanup
        self.doPreRestoreCleanUp()

        return op_return_obj

    @clock
    def doPreRestoreCleanUp(self):
        """
        This function cleansup the datadirectory of MySQL before retoring to the datadirectory
        If any files are directories need to be excluded ftom the cleanup the same should be
        specified in constants.py as below
        # Exclusion list for datadir cleanup
        #File exclusion list
        FILE_EXCLUSION_LIST = [".pem",".pid",".index"]
        #Directory exclusion list
        DIR_EXCLUSION_LIST = ["donotDeleteDir"]
        """
        import shutil
        import re

        host=self.get_host()

        common_lib.logger("INFO","Executing doPreRestoreCleaup(), will cleanup {target} with the exception of files with extension {extension}."\
                                .format(target=self.get_dataDirectory(), extension=self.get_fileExclusionList()))
        #list of files to be deleted
        files_to_delete=filter(lambda name:not name.endswith(tuple(self.get_fileExclusionList())) and not name.startswith(host),
                                filter(lambda name: os.path.isfile(os.path.join(self.get_dataDirectory(), name)),
                                       (os.listdir(self.get_dataDirectory()))))

        #list of directories to be deleted
        dirs_to_delete=filter(lambda name: not name.startswith(tuple(self.get_dirExclusionList())),
                              filter(lambda name: not os.path.isfile(os.path.join(self.get_dataDirectory(), name)),
                                     (os.listdir(self.get_dataDirectory()))))
        #Delete files
        for file in files_to_delete:
            common_lib.logger("INFO","Removing file " + os.path.join(self.get_dataDirectory(), file))
            try:
               os.remove(os.path.join(self.get_dataDirectory(), file))
            except OSError:
               pass

        #Delete directories
        for dir in dirs_to_delete:
            common_lib.logger("INFO","Removing directory " + os.path.join(self.get_dataDirectory(), dir))
            shutil.rmtree(os.path.join(self.get_dataDirectory(), dir), ignore_errors=True)
        common_lib.logger("INFO","Finished executing doPreRestoreCleaup().")

    @clock
    def postCreateInstanceSetup(self):
        """
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        #we need to remove clean up translog
        #delete_return_obj = common_lib.remove_file_with_same_pattern("/u01/translog/inno-bin-logs",".*")
        #if not delete_return_obj.get_bool_status():
        #   common_lib.logger("ERROR","Failed to delete innodb redo logs in {dir}".format(dir="/u01/translog/inno-bin-logs"))
        #   op_return_obj.set_status_msg("Failed to delete innodb redo logs.")
        #   op_return_obj.set_bool_status(False)
        #   return op_return_obj

        #change configuration file
        self.change_configuration_file()

        self.cleanUp()

        #remove UUID file create a new incarnation
        uuid_file = os.path.join(self.get_dataDirectory(),"auto.cnf")
        try:
             os.remove(os.path.join(self.get_dataDirectory(),"auto.cnf"))
        except OSError:
             pass

        return_obj = self.startMySQL("--skip-grant-tables")
        if not return_obj.get_bool_status():
           common_lib.logger("ERROR",return_obj.get_status_msg())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           op_return_obj.set_bool_status(False)
           return op_return_obj

        return op_return_obj

    def change_configuration_file(self):
        """
        Change the current my.cnf to include the values from the backup-my.cnf
        """
        import shutil

        backupmycnfdict={}
        servermycnfdict={}
        changelist=constants.MYCNF_CHANGE_PROPERTIES
        BACKUPMYCNF=self.get_tempBackupDirectory() + "/temp/backup-my.cnf"
        SERVERMYCNF=self.get_tempBackupDirectory() + "/temp/server-all.cnf"
        SYSTEMCNF='/u01/bin/mysql/my.cnf'
        BACKEDUPMYCNF='/u01/bin/mysql/my.cnf.bkp'
        BACKEDUPMYCNFTMP='/u01/bin/mysql/my.cnf.bkp.tmp'
        #make a backup of system cnf
        shutil.copyfile(SYSTEMCNF, BACKEDUPMYCNFTMP)

        #load the properties into a dictionary from backup-my.cnf file        
	with open(BACKUPMYCNF) as infile:
  	   for line in infile:
    	      if not ( (line.strip()).startswith('#') or (line.strip()).startswith('[')):
       	         keyvalue = line.split('=')
                 if not line.strip() == '' :
                    backupmycnfdict[keyvalue[0].replace('-','_')] = keyvalue[1]

        #load the properties into a dictionary from server-my.cnf file        
	with open(SERVERMYCNF) as infile:
  	   for line in infile:
              # a hack to take care of commented time_zone property in server-all.cnf
              line = "default_" + line[1:].lstrip() if (line[1:].strip()).startswith('time_zone')  else line

    	      if not ( (line.strip()).startswith('#') or (line.strip()).startswith('[')):
       	         keyvalue = line.split('=')
                 if not line.strip() == '' :
                    servermycnfdict[keyvalue[0].replace('-','_')] = keyvalue[1]

        #now change the properties in system cnf based on backup cnf for restore
        common_lib.logger("INFO","Updating my.cnf for restore.")
        outfile = open(SYSTEMCNF,'wb')
        with open(BACKEDUPMYCNFTMP) as infile:
           for line in infile:
              if not ( (line.strip()).startswith('#') or (line.strip()).startswith('[') or line.strip() == '' ):
                 keyvalue = line.split('=')
                 if len(keyvalue) > 1:
                    if (( keyvalue[0].replace('-','_') in backupmycnfdict ) or ( keyvalue[0].replace('-','_') in changelist )):
		       if keyvalue[0].replace('-','_') in servermycnfdict:
                          outfile.write(keyvalue[0]+'='+servermycnfdict[keyvalue[0].replace('-','_')])
                       else:
                          outfile.write(keyvalue[0]+'='+keyvalue[1])
                    else:
                       outfile.write(keyvalue[0]+'='+keyvalue[1])
                 else:
                    outfile.write(line)
              else:
                 outfile.write(line)
        outfile.close() 

        #now change the properties in system cnf based on change list 
        mycnf = open(BACKEDUPMYCNF,'wb')
        #change the property 
        with  open(BACKEDUPMYCNFTMP) as infile:
           for line in infile:
              if not ( (line.strip()).startswith('#') or (line.strip()).startswith('[') or line.strip() == '' ):
                 keyvalue = line.split('=')
                 if len(keyvalue) > 1:
                    if keyvalue[0].replace('-','_') in changelist and keyvalue[0].replace('-','_') in servermycnfdict:
                       mycnf.write(keyvalue[0]+'='+servermycnfdict[keyvalue[0].replace('-','_')])                  
                    else:
                       mycnf.write(keyvalue[0]+'='+keyvalue[1])
                 else:
                    mycnf.write(line)
              else:
                 mycnf.write(line)
        mycnf.close()

        #remove the temp file
        os.remove(BACKEDUPMYCNFTMP)


    def get_CreateInstanceCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        restoreCommand =(   self.get_MEBLocation() +  " --defaults-file=" + self.get_tempBackupDirectory() + "/temp/backup-my.cnf "
                                 " --user="  + self.get_MySQLUser() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageServiceInstance() + ":" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_cloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --backup-dir=" + self.get_tempBackupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --datadir=" + self.get_dataDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return restoreCommand, restoreCommandForPrint

class CreateInstanceFromMEBFullBackupImageBMC(CreateInstanceFromMEBFullBackupImage):

    def __init__(self, dictionaryData):
        CreateInstanceFromMEBFullBackupImage.__init__(self, dictionaryData)

    def get_ValidateBackupCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        validateCommand =(   self.get_MEBLocation() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.get_cloudStorageURIBMC()) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- validate " )

        validateCommandForPrint = validateCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return validateCommand, validateCommandForPrint

    def get_CreateInstanceCommand(self):
        """
        Generates the meb command for restoring from backup
        """
        restoreCommand =(   self.get_MEBLocation() +  " --defaults-file=" + self.get_tempBackupDirectory() + "/temp/backup-my.cnf "
                                 " --user="  + self.get_MySQLUser() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.get_cloudStorageURIBMC()) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudStorageObjectPath() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_tempBackupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 " --datadir=" + self.get_dataDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_logDir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        return restoreCommand, restoreCommandForPrint

