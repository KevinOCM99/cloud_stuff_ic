
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#

"""
This script is used to check the reachability of a component. The script takes in a JSON formatted
payload of hostnames and servers and component attributes.
Example:
python check_provisioning_status.py '{"hosts":[{"servers":[{"serverName":"testService10 wls admin","usageType":"admin"},
{"serverName":"testService10 wls 2","usageType":"managed"}],"hostName":"testService10-wls-1"}]}'

"""

import sys
import json
import urllib2
import os
import time
sys.path.append(os.path.join(os.path.dirname(__file__), "../utils/"))
import databag_utils
tools_path = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(1, tools_path + "/../python/scaling/")
print(sys.path)
import conf_parser
import subprocess


def mysql_status():
    try:
        tools_path = os.path.realpath(__file__)
        mscs_const = conf_parser.ConfParser(tools_path[:tools_path.index("service_scripts")] + "service_scripts/mscs.cnf")
        sysuser = mscs_const.getProperty('', 'sys_user')
        mysql_install_script = tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"
        command = "source {mysql_install_script} && getMysqlStatus {sys_user}".format(
                      mysql_install_script=mysql_install_script,
                      sys_user=sysuser)
        status = subprocess.call(command, shell=True)

        if status == 0:
            print "mysql running status : UP"
            return True
        else:
            print "mysql running status : Down"
            return False
    except Exception as e:
        print "Failed toverify mysql status" + str(e)
        return False


def reachabilityCheck(payload, port):

    #Load the payload from the arg
    hosts = payload["hosts"]

    error = ""
    statusMessage = ""
    sleep_timeout_in_seconds = 600
    reachability_flag = 0
    host=hosts[0]
    url = "http://" + host["hostName"] + ":" + port
    retry_count = 0
    sleep_time_total = 0
    sleep_interval = 10
    while sleep_time_total <= sleep_timeout_in_seconds:
        try:
            retry_count = retry_count + 1
            mysql = urllib2.urlopen(url)
            status = mysql.getcode()
            if status == 200:
                message = ("Successfully validated that {0} returned a"
                           "status of 200 on retry {1}, waited {2}seconds;"
                           ).format(
                    host["hostName"],
                    retry_count,
                    sleep_time_total)
                statusMessage = statusMessage + message
                reachability_flag =  1
                break
            else:
                errMessage = "%s returned a status of %s in retry %s" % (
                    host["hostName"],
                    status,
                    retry_count)
                time.sleep(sleep_interval)
                sleep_time_total = sleep_time_total + sleep_interval
                print errMessage
                error = errMessage
        except Exception as e:
            errMessage = (" Reachability check failed for "
                          "%s %s on retry %s waited %s seconds;"
                          ) % (url, str(e), retry_count, sleep_time_total)
            error = errMessage
            print errMessage
            time.sleep(sleep_interval)
            sleep_time_total = sleep_time_total + sleep_interval

        if not mysql_status():
            reachability_flag = 0
            errMessage = ("Mysql is not up reachability check failed, "
                          "after waiting %s seconds;"
                          ) % (sleep_time_total)
            error = error + errMessage

    result = {}
    if reachability_flag == 1:
        result["status"] = "Success"
        result["statusMessage"] = statusMessage
    else:
        result["status"] = "Failure"
        result["statusMessage"] = error

    return result


def execute(data):

    print json.dumps(data)
    simplifiedPayload = databag_utils.simplify_payload(data)
    port = databag_utils.get_mysql_port(data)
    SM_EXECUTION_RESULT = reachabilityCheck(simplifiedPayload, port)
    print "<JsonResult>" + json.dumps(SM_EXECUTION_RESULT) + "</JsonResult>"



#NOTE: This is only for debugging purposes

if __name__ == '__main__':
    import json
    with open('./data_bag.json') as f:
        data = json.load(f)
    execute(data)

