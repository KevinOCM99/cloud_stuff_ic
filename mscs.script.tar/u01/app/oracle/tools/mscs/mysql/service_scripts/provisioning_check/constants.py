__author__ = 'balagopalan thampi'
__copyright__ = 'Copyright (c) 2017 Oracle and/or its affiliates. All rights reserved.'

DEBUG_LOG = '/tmp/prov_debug.log'
ERROR_LOG = '/tmp/prov_error.log'
MY_CNF = '/u01/bin/mysql/my.cnf'
MSAAS_HOME_FOLDER = "msaas"
MSAAS_LOG_FOLDER = "log"
MSAAS_PROVISIONING_LOG_NAME = "MsaasProvisioning.log"
