#!/usr/bin/env python

import sys
import os
import time
import hmac
from hashlib import sha1

def main():
   if len(sys.argv) < 7:
      print "Please provide"
      sys.exit(1)

   filename=sys.argv[1]
   container=sys.argv[2]
   url=sys.argv[3]
   serviceinstance=sys.argv[4]
   objectpath=sys.argv[5]
   username=sys.argv[6]
   password=sys.argv[7]
   tempurlPUT = getTempURL(url,serviceinstance,container,objectpath, 60000,"PUT",username,password)
   print "For Upload : " + tempurlPUT
   tempurlGET = getTempURL(url,serviceinstance,container,objectpath, 60000,"GET",username,password)
   print "For download : " + tempurlGET
   downloadFile(filename,tempurlGET)

def getSecretKey(url,username,password):
   import urllib2, base64
   import urllib
   print url
   request =urllib2.Request(url)
   base64string = base64.encodestring('%s:%s' % (username, password)).replace('\n', '')
   request.add_header("Authorization", "Basic %s" % base64string)
   result = urllib2.urlopen(request).info().headers
   for tagValue in result:
      tag,value=tagValue.split(':', 1)
      if tag == 'X-Account-Meta-Temp-Url-Key':
         return (value.lstrip(' ')).replace('\r\n','')
   #if key is not there
   secretKey=setSecretKey()
   data=urllib.urlencode({})
   request.add_header("X-Account-Meta-Temp-Url-Key", secretKey)
   urllib2.urlopen(request,data)
   return secretKey

def setSecretKey():
   import random
   random.seed()
   s=""
   for i in range(30):
      s += str(format(int(random.random()*100000),'x'))
   return s

def getTempURL(url,serviceinstance,container,objectpath,durationInSeconds,method,username,password):
   key=getSecretKey(url+serviceinstance,username,password)
   expires = int(time.time() * 1000 + durationInSeconds)
   path = serviceinstance + "/" + container + objectpath
   hmac_body = '%s\n%s\n%s' % (method, expires, path)
   sig = hmac.new(key, hmac_body, sha1).hexdigest()
   s = '{host}/{path}?temp_url_sig={sig}&temp_url_expires={expires}'
   url = s.format(host=url,path=path, sig=sig, expires=expires)
   return url

