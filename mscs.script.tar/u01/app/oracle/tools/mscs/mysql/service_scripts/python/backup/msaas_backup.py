#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import sys
import os
import atexit

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import backup
import constants
import msaas_common_lib as common_lib
from module_exe_util import ModuleExecutionReturnClass

module_exe_result = ModuleExecutionReturnClass()
module_exe_result.set_operation_type("backup")
backupObj=None


#
##
###main
def main(input_dict_args):
    """
    Returns a function execute_backup if the input JSON validates with out error.
    """
    return_obj = common_lib.OperationReturnObj()

    #parsing input JSON into a python dictionary
    input_dict_args = common_lib.JSONUtil.decode_from_json_str(sys.argv[1])

    if not input_dict_args:
        common_lib.logger("ERROR","Invalid json argumentr, exiting backup operation")
        return_obj.set_bool_status(False)
        return_obj.append_status_msg("Exiting backup operation. Invalid JSON arguments...")
        return return_obj

    print "The JSON args passed in are:"
    common_lib.JSONUtil.print_dict_as_json(input_dict_args)


    #backup_result = do_backup(input_dict_args)

    #if backup_result.get_bool_status():
    #   common_lib.logger("INFO","Finished backing up mysql")
    #   module_exe_result.set_success(True)

    #return_obj.set_bool_status(backup_result.get_bool_status())
    #return_obj.append_status_msg(backup_result.get_status_msg())

    return execute_backup(input_dict_args)

#
##
###
def execute(input_dict_args):
    """
    Calls execute backup to perform backup operation
    Returns the status code "0" for success and "1" for failure
    """
    #common_lib.JSONUtil.print_dict_as_json(input_dict_args)
    input_dict_args = common_lib.decode_secure_params(input_dict_args)
    result = execute_backup(input_dict_args)
    return 0 if result.get_bool_status() else 1


#
##
###
def execute_backup(input_dict_args):
    """
    Calls do_backup function
    If the returned backup status indicate failure a clean up is performed
    on sucess the operation details are flushed to the logs to consumed by the platform.
    Opertion details returned are
    <JsonResult>{
    	"status": "Success", 
   	"SM_EXECUTION_RESULT": {
          "backupDetails": {
              "checksum": "<checkSum>", 
              "backedUpHosts": "<backedUpHosts>", 
              "archiveFileName": "/u01/backup/MSCS/<serviceName>/<backupType>/backupID/<backup_image_name>", 
              "size": in bytes
        	}, 
          "serviceType": "<serviceType>", 
          "serviceName": "<serviceName>"
                               }, 
       "statusMessage": "Backed up mysql database on [test-cloudbr-mysql-1]..."
              }
    </JsonResult>
    Return:
      rtype: OperationReturnObj
    """ 
    import copy
    import delete
    global module_exe_result
    common_lib.logger("INFO","Formated input JSON dump.")

    #obfuscate password before dumping
    input_dict_args_for_print = copy.deepcopy(input_dict_args)
    if input_dict_args_for_print.has_key('SM_OPERATION_INFO') and input_dict_args_for_print['SM_OPERATION_INFO'].has_key('cloudStoragePassword'):
       input_dict_args_for_print['SM_OPERATION_INFO']['cloudStoragePassword'] = 'XXXXXXXX'

    common_lib.JSONUtil.print_dict_as_json(input_dict_args_for_print)

    #set service info
    service_info = input_dict_args.get(constants.SERVICE_INFO)
    if service_info:
        module_exe_result.set_service(service_info)

    #print "Backing up the elastic search..."
    common_lib.logger("INFO","Backing up the mysql")

    backup_result = do_backup(input_dict_args)

    #cleanup the backup directory and cloud backup objects
    if not backup_result.get_bool_status() and ( backupObj and backupObj.isCleanupRequired() ) :
       backupObj.doCleanUp()

    if backup_result.get_bool_status():
       module_exe_result.set_bool_status(True)
       notDeletedBackupIds = delete_expired_backup(input_dict_args)
       module_exe_result.set_notDeletedBackupIds(notDeletedBackupIds)

    status_message=backup_result.get_status_msg()
    status_message=(status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
    module_exe_result.set_status_log(status_message)
    module_exe_result.set_errorType(backup_result.get_error_type())
    module_exe_result.flush()

    module_exe_result = None

    return backup_result

#
##
###performs backup operation
def do_backup(dictionary_data):
    """
    Gets a backup object from the backup factory
    Performs precheck, backup, validate.
    If precheck, backup and validate succeed the operation details are set in an instance of ModuleExecutionReturnClass. This object flushes the
    operation details in the form of a JSON to be consumed by the platform.
    Return:
      rtype: OperationReturnObj
    """  
    import constants
    import socket

    op_return_obj = common_lib.OperationReturnObj()
    #get backup object
    global backupObj
    try:
       backupObj = backup.BackupFactory(dictionary_data).get_backupObject()
    except KeyError as e:
       common_lib.logger("ERROR","Some keys missing in the Input JSON, failing with key error while parsing error: {err}".format(err=e))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20901>: Unable to obtain the backup object.")
       return op_return_obj

    if not backupObj:
       common_lib.logger("ERROR","Unable to obtain a backup object from the factory, JSON input BACKUP_DESTINATION and/or isFull does not have correct values")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20901>: Unable to obtain the backup object.")
       return op_return_obj

    #perform precheck
    preCheckResults = backupObj.doPreCheck()
    #check if all precheck passed
    for preCheck in preCheckResults.iterkeys():
        if not preCheckResults[preCheck]["status"] :
           common_lib.logger("ERROR","Following pre-check(s) failed, exiting backup operation. ")
           break

    #print the precheck details.
    for preCheck in preCheckResults.iterkeys():
        if not preCheckResults[preCheck]["status"] :
           common_lib.logger("ERROR",preCheckResults[preCheck]["message"])
           op_return_obj.set_bool_status(False)
           op_return_obj.append_status_msg(preCheckResults[preCheck]["message"] + " ")
    if not op_return_obj.get_bool_status():
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20201>: Pre-check(s) failed. " + op_return_obj.get_status_msg())
       return op_return_obj  

    common_lib.logger("INFO","All pre-checks passed, continuing with backup operation. ")

    #perform backup and backup validation
    backup_return_obj = backupObj.doBackupAndValidate()
    if not backup_return_obj.get_bool_status() :
       op_return_obj.set_bool_status(backup_return_obj.get_bool_status())
       op_return_obj.set_status_msg(backup_return_obj.get_status_msg())
       return op_return_obj

    # Loop on hosts_list
    backed_up_hosts=""
    for host in backupObj.get_hostList():
        backed_up_hosts += "{host} ".format(host=host)

    backupMetaData=common_lib.BackupMetaData() 
    backupMetaData, backup_return_obj = backupObj.get_backupMetaData()
    if not backup_return_obj.get_bool_status() :
       op_return_obj.set_bool_status(backup_return_obj.get_bool_status())
       op_return_obj.set_status_msg(backup_return_obj.get_status_msg())
       return op_return_obj

    common_lib.logger("INFO","Printing backup metadata")
    common_lib.logger("INFO","Backup Start time : {starttime}".format(starttime=backupMetaData.getStartTime()))
    common_lib.logger("INFO","Backup End time : {endtime}".format(endtime=backupMetaData.getEndTime()))
    common_lib.logger("INFO","Backup Start LSN : {startlsn}".format(startlsn=backupMetaData.getStartLSN()))
    common_lib.logger("INFO","Backup End LSN : {endlsn}".format(endlsn=backupMetaData.getEndLSN()))
    common_lib.logger("INFO","Latest Binary Log parsed for the backup : {binlog}".format(binlog=backupMetaData.getBinLogFile()))
    common_lib.logger("INFO","Latest Binary Log parsed till offset : {pos}".format(pos=backupMetaData.getBinLogPos()))
 
    backupAttributes = ( '{"startTime"' + ':' + '{startTime}'.format(startTime=backupMetaData.getStartTime()) + ','
                       '"endTime"' + ':' + '{endTime}'.format(endTime=backupMetaData.getEndTime()) + ','
                       '"startLSN"' + ':' + '{startLSN}'.format(startLSN=backupMetaData.getStartLSN()) + ','
                       '"endLSN"' + ':' + '{endLSN}'.format(endLSN=backupMetaData.getEndLSN()) + ','
                       '"lastBinLog"' + ':' + '"{lastBinLog}"'.format(lastBinLog=backupMetaData.getBinLogFile()) + ','
                       '"lastBinLogPos"' + ':' + '{lastBinLogPos}'.format(lastBinLogPos=backupMetaData.getBinLogPos()) + ','
                       '"triggeredBy"' + ':' + '"{triggeredBy}"'.format(triggeredBy=dictionary_data['SM_OPERATION_INFO']['backup']['initiatedBy']) + '}')

    module_exe_result.set_operation_detail(constants.BACKED_UP_HOSTS_LIST_JSON_KEY, backed_up_hosts.strip())
    module_exe_result.set_operation_detail(constants.BACKUP_ARCHIVE_JSON_KEY, backupObj.get_backupCloudObject())
    module_exe_result.set_operation_detail(constants.BACKUP_TAG_JSON_KEY, backupAttributes)
    credential = backupObj.get_cloudStorageUser() + ":" + backupObj.get_cloudStoragePassword()
    module_exe_result.set_operation_detail(constants.SIZE_JSON_KEY,
                                           int(common_lib.get_file_size(backupObj.get_backUpImageFullName(),credential=credential )))
    module_exe_result.set_operation_detail(constants.CHECKSUM_JSON_KEY,
                                           common_lib.get_file_md5_checksum(backupObj.get_backUpImageFullName(),credential=credential ))

    op_return_obj.set_bool_status(True)
    op_return_obj.set_status_msg("<MSCS-INFO-20100>: Backup and backup image validation completed successfully.")
    #op_return_obj.set_status_msg("<MSCS-INFO-20100>: Backup and backup image validation completed successfully on [{hosts_list}]..."
    #                             .format(hosts_list=str(backed_up_hosts.strip())))

    return op_return_obj

def delete_expired_backup(dictionary_data):
    """
    Deletes the local and cloud storage backups based on expiredLocalBackups and expiredBackups.
    Return:
      rtype: OperationReturnObj
    """

    import urlparse
    common_lib.logger("INFO","Looking for expired backups to delete.")
    notDeletedBackupIds = []
    
    expired_cloudbackups = get_expired_backup(dictionary_data, False)
    expired_localbackups = get_expired_backup(dictionary_data, True)
    expired_backups = []
    expired_backups.extend(expired_cloudbackups)
    expired_backups.extend([backup for backup in expired_localbackups if backup not in expired_cloudbackups ])
	
    #get cloud credential to delete from storage
    credential = backupObj.get_cloudStorageUser() + ":" + backupObj.get_cloudStoragePassword()
	
    backupDestination = dictionary_data['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
    if backupDestination == 'BOTH':
       backupVolumeMount = dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']

    for backupToDelete in expired_backups:
        backupAttribute = backupToDelete
        backupId = backupAttribute["backupId"]
        storageURI = backupAttribute["backupStorageURI"] if  backupAttribute["backupStorageURI"].endswith('/') else backupAttribute["backupStorageURI"] + '/'

        if backupDestination == 'BOTH':
           backupArchive = get_local_archivename(backupAttribute, backupVolumeMount)
   	   couldObjectURI = get_cloud_archivename(storageURI, backupVolumeMount, get_local_archivename, backupAttribute, backupVolumeMount)
        else:
           backupArchive = backupAttribute["archiveFileName"] if backupAttribute["archiveFileName"].startswith(storageURI) else urlparse.urljoin(storageURI, backupAttribute["archiveFileName"])
           couldObjectURI = backupArchive
        
        common_lib.logger("INFO","Deleting backup backup ID {backupId}, image {backupArchive}.".format(backupId=backupId, backupArchive=backupArchive))
        #delete from the disk
        if os.path.isfile(backupArchive):
           remove_backup_from_disk(backupArchive)
        #delete from cloud
	if backupToDelete in expired_cloudbackups:
	   delete_return_obj = remove_backup_from_cloud(couldObjectURI, credential)
	   if not delete_return_obj.get_bool_status():
              notDeletedBackupIds.append(backupId)
    return notDeletedBackupIds

	
def get_expired_backup(dictionary_data, isLocalbackup):
    """
    Returns the backup list expiredLocalBackups or expiredBackups based on isLocalbackup flag.
    """
    return list(dictionary_data.get("SM_OPERATION_INFO").get("expiredLocalBackups",[])) if isLocalbackup else list(dictionary_data["SM_OPERATION_INFO"]["expiredBackups"])
	
def get_local_archivename(backupAttribute, backupVolumeMount):
    """
    Returns the disk backup filename. 
    """
    return backupAttribute["archiveFileName"] if backupAttribute["archiveFileName"].startswith(backupVolumeMount) else os.path.join(backupVolumeMount, backupAttribute["archiveFileName"])
	
def get_cloud_archivename(storageURI, backupVolumeMount, getLocalArchiveName, *args):
    """
    Returns the cloud backup object URL. 
    """
    import urlparse
		
    backupArchive=getLocalArchiveName(*args)
    cloudObject=backupArchive.replace(backupVolumeMount,"", 1) if not backupArchive.replace(backupVolumeMount,"", 1).startswith('/') else backupArchive.replace(backupVolumeMount,"", 1)[1:]
    return urlparse.urljoin(storageURI, cloudObject)

def remove_backup_from_disk(fileObject):
    import shutil
    try:
       shutil.rmtree(os.path.dirname(fileObject))
       common_lib.logger("INFO","Backup {backup} deleted from disk.".format(backup=fileObject))
    except IOError, e:
       common_lib.logger("ERROR","Could not delete backup from disk {backup}.".format(backup=fileObject))
       

def remove_backup_from_cloud(fileObjectURI, credential):
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    
    #check for SLO
    get_object_info_result, response = common_lib.GetCloudObjectinfo(fileObjectURI, credential)
    if not get_object_info_result.get_bool_status(): 
       common_lib.logger("ERROR","Backup image {image} info could not be found.".format(image=fileObjectURI))
       if response.get_http_code() == 404:
          common_lib.logger("INFO","Backup image {image} assumed to be deleted.".format(image=fileObjectURI))
          return op_return_obj
       else:
       	  op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("Backup image info could not be found.")
          return op_return_obj
       
    if dict(response.get_http_response().info()).get('x-static-large-object',None):
       delete_return_obj = common_lib.deleteObjectFromCloud(fileObjectURI + '?multipart-manifest=delete', credential)
    else:
       target = backupObj.cloudStorageURI + '?prefix=' + fileObjectURI.replace(backupObj.cloudStorageURI + '/','',1) + '&&format=json'
       delete_return_obj = common_lib.deleteObjectFromCloudDLO(target, credential)

    if not delete_return_obj.get_bool_status():
       common_lib.logger("ERROR","Backup image {image} could not be deleted from cloud storage.".format(image=fileObjectURI))
    else:
       common_lib.logger("INFO","Backup image {image} deleted from cloud storage.".format(image=fileObjectURI))
    return delete_return_obj

 

@atexit.register
def at_exit():
    """
    This function will get invoked when script exits
    :return:
    """

    if module_exe_result:
       module_exe_result.flush()

if __name__ == "__main__":
    result = main()
    sys.exit(0 if result.get_bool_status() else 1)


