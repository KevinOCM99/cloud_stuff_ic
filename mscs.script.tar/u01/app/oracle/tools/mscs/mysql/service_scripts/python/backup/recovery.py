#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep, calvin'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'


import msaas_common_lib as common_lib
import os
import shutil
import time
import constants
from datetime import datetime
skip_extract = False

def applyBinaryLogs(recoveryBinaryLog, user, binLogPos, PITRTimeInEpoch):
   """
     Applies binary logs to the database, starting from binlog position to the recovery time.
     input:
            recoveryBinaryLog, a coma seperated string of binary logs
            user, mysql user for applying the binary logs
            binLogPos, the binary log offset from where to apply the binary logs
            PITRTimeInEpoch, epoch to which the binary losg should be applied (recovery time)
     return:
             CMDExecutionResultClass object
   """
   #recoveryTime=common_lib.getDateFromEpoch(PITRTimeInEpoch, "%Y-%m-%d %H:%M:%S")
   recoveryTime=common_lib.getDateFromEpoch(PITRTimeInEpoch, "%Y-%m-%d %H:%M:%S", localTime=True)
   cmd='{mblpath}/mysqlbinlog --skip-gtids --start-position={start_position} --stop-datetime="{stop_datetime}" {recovery_bin_log}|{MSQLPATH}/mysql -u{USER} '.format(MSQLPATH=constants.MSQLPATH, mblpath=constants.MBLPATH,start_position=binLogPos,stop_datetime=recoveryTime, recovery_bin_log=recoveryBinaryLog, USER=user)
   #create executer
   executor = common_lib.Executor()
   common_lib.logger("INFO", "Applying binary log {cmd}".format(cmd=cmd))
   cmd_execution_result = executor.execute_cmd(cmd)
   return cmd_execution_result

def getBinaryLogsStarttime(binLogFile):
   """
     Parses the binary log header for binary log start time and serverID.
     input:
           binLogFile, binary log file
     return:
           binarylog's start time converted yo epoch
           serverID
           Operation object
   """
   op_return_obj = common_lib.OperationReturnObj()
   op_return_obj.set_bool_status(True)


   executor = common_lib.Executor()
   cmd ="{mblpath}/mysqlbinlog  --start-position=4 --stop-position=12 {binLogFile}|grep 'log created'".format(mblpath=constants.MBLPATH, binLogFile=binLogFile)
   exec_result=executor.execute_cmd(cmd)
   if exec_result.get_return_code() != 0:
      common_lib.logger("Error","Unable to get start start time and server id from binary log {binlog}".format(binlog=binLogFile))
      op_return_obj.set_bool_status(False)
      op_return_obj.set_error_type("Fatal")
      op_return_obj.set_status_msg("<MSCS-ERR-20808>: Unable to get start start time and server id from the binary log.")
      return None,None,op_return_obj

   #get standard out
   stdOut = exec_result.get_std_out()
   #normalize the blank space
   stdOut = " ".join(stdOut.split())
   words=stdOut.split()
   #Format the time and get the epoch
   wdatetime="20" + words[0].strip("#") + " " + words[1]
   #sepoch = int(time.mktime(time.strptime(wdatetime,"%Y%m%d %H:%M:%S")))
   try:
      datetime.strptime(wdatetime, '%Y%m%d %H:%M:%S')
   except ValueError:
      common_lib.logger("ERROR", "Invalid date format, format should be in '%Y%m%d %H:%M:%S'")
      op_return_obj.set_bool_status(False)
      op_return_obj.set_error_type("Fatal")
      op_return_obj.set_status_msg("<MSCS-ERR-20808>: Unable to get start start time and server id from the binary log.")
      return None,None,op_return_obj

   sepoch = common_lib.getEpoch(wdatetime,"%Y%m%d %H:%M:%S",localTime=True)
   wserverid= words[4]
   return sepoch, wserverid,op_return_obj

def filterBinaryLogsForPITR(binLogs, lepoch, repoch, serverid):
    """
      Filter out binary logs based on the time for recovery
      input:
            binLogs, a list of binary logs
            lepoch, the start time in epoch for selecting the binary logs
            serverid, the serverId (only specific servers binary logs will be selected
      return:
            dict of selected binary logs with starttime in epoch as the key
    """
    rbinlogs={}
    for binlog in binLogs:
        wepoch, wserverid, result_obj = getBinaryLogsStarttime(binlog)
        if wepoch >= lepoch and wepoch <= repoch and wserverid==serverid :
           rbinlogs.update({wepoch : binlog})
    return rbinlogs

def checkCurrentBinaryLogsForRecover(binLogDir):
    #get the binary logs
    #
    #
    #copy binary logs to temp directory
    import re
    import os
    import shutil
    import socket

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    #make directory
    if not os.path.isdir(binLogDir):
       try:
          os.makedirs(binLogDir)
       except OSError:
          common_lib.logger("ERROR","Could not create the temp directory {binLogDir}".format(binLogDir=binLogDir))
          op_return_obj.set_status_msg("Could not create the temp directory")
          op_return_obj.set_bool_status(False)
          return op_return_obj

    #copy bin logs
    host = socket.gethostname()
    current_binLogDir = common_lib.get_logDir()
    current_binLogFiles = [os.path.join(current_binLogDir,bfile) for bfile in os.listdir(current_binLogDir) if re.match(r'.*\.[0-9]+$', bfile) and bfile.startswith(host)]

    binlogsFound = False
    for binLog in current_binLogFiles:
        if (os.path.isfile(binLog)):
           binlogsFound = True
           try:
              shutil.copy(binLog, binLogDir)
           except IOError, e:
              common_lib.logger("ERROR","Could not copy the binary logs to the temp directory, error {error}".format(error=e))
              op_return_obj.set_status_msg("Could not copy the binary logs to the temp directory.")
              op_return_obj.set_bool_status(False)
              return op_return_obj


    if not binlogsFound:
       common_lib.logger("ERROR","No binary logs found for recovery")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("No binary logs found for recovery")
       return op_return_obj

    global skip_extract
    skip_extract = True
    return op_return_obj




def getBackupsForRecovery(PITRTimeInEpoch, dictionary_data ,binLogDir):
    """
      Discover the backups needed for recovery
      input:
            PITRTimeInEpoch, recovery time in epoch
            dictionary_data, input JSON
      return:
            Metadata for the selected backups and operation object
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    # only doing PITR from backups initiated by "scheduled" or "restore"
    backups = [backup for backup in dictionary_data['SM_OPERATION_INFO']['backups']
               if backup['initiatedBy'] == "scheduled" or backup['initiatedBy'] == "restore"]

    # initialize
    fullBackupStartTime = 0
    fullBackupEndTime = 0
    fullBackupArchive = None

    incrBackupStartTime = 0
    incrBackupEndTime = 0
    incrBackupArchive = None

    binLogBackupStartTime = 0
    binLogBackupEndTime = 0
    binLogBackupArchive = None

    for backup in backups:
        backupIsFull = backup["isFull"]
        backupAttrib = common_lib.JSONUtil.decode_from_json_str(backup["tag"])

        if backupIsFull and backupAttrib["endTime"] < PITRTimeInEpoch and  backupAttrib["endTime"] > fullBackupEndTime:
            fullBackupArchive = backup["archiveFileName"]
            fullBackupBackupId = backup["backupId"]
            fullBackupStorageURI = backup["backupStorageURI"]
            fullBackupStartTime = backupAttrib["startTime"]
            fullBackupEndTime = backupAttrib["endTime"]
            fullBackupStartLSN = backupAttrib["startLSN"]
            fullBackupEndLSN = backupAttrib["endLSN"]
            fullBackupBinLog = backupAttrib["lastBinLog"]
            fullBackupBinPos = backupAttrib["lastBinLogPos"]

        if not backupIsFull and backupAttrib["endTime"] < PITRTimeInEpoch and  backupAttrib["endTime"] > incrBackupEndTime:
            incrBackupArchive = backup["archiveFileName"]
            incrBackupBackupId = backup["backupId"]
            incrBackupParentBackupId = backup["fullBackupId"]
            incrBackupStorageURI = backup["backupStorageURI"]
            incrBackupStartTime = backupAttrib["startTime"]
            incrBackupEndTime = backupAttrib["endTime"]
            incrBackupStartLSN = backupAttrib["startLSN"]
            incrBackupEndLSN = backupAttrib["endLSN"]
            incrBackupBinLog = backupAttrib["lastBinLog"]
            incrBackupBinPos = backupAttrib["lastBinLogPos"]

        if backupAttrib["endTime"] > PITRTimeInEpoch and (backupAttrib["endTime"] < binLogBackupEndTime or binLogBackupEndTime == 0):
            binLogBackupArchive = backup["archiveFileName"]
            binLogBackupBackupId = backup["backupId"]
            binLogBackupIsFull = backup["isFull"]
            binLogBackupStorageURI = backup["backupStorageURI"]
            binLogBackupStartTime = backupAttrib["startTime"]
            binLogBackupEndTime = backupAttrib["endTime"]
            binLogBackupStartLSN = backupAttrib["startLSN"]
            binLogBackupEndLSN = backupAttrib["endLSN"]
            binLogBackupBinLog = backupAttrib["lastBinLog"]
            binLogBackupBinPos = backupAttrib["lastBinLogPos"]
            binLogBackupTriggeredBy = backupAttrib["triggeredBy"]

    #check if the incremental has the startDate after the selected full backup end date
    #if not, then there is no incremental backup needed for recovery
    if fullBackupArchive and incrBackupStartTime < fullBackupEndTime :
        incrBackupArchive = None

    if not binLogBackupArchive :
       #check if the current binary logs could be used
       #copy binary logs to extact directory
       #skip extraction if the bin logs are vailable locally
       checkCurrentBinaryLogs_result = checkCurrentBinaryLogsForRecover(binLogDir)

       if not checkCurrentBinaryLogs_result.get_bool_status():
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type("Fatal")
          op_return_obj.set_status_msg(checkCurrentBinaryLogs_result.get_status_msg())
          return None, None, None, op_return_obj

    """
    Check if recovery is possible.
    Recovery not possible
        if no full backup is available
        if backup discovered for binary logs is the one triggered by restore binLogBackupTriggeredBy = "restore"
        if no backup is discovered for binary logs
        if the incremental backup discovered is not the child of the full backup discovered
    """
    if not fullBackupArchive or (binLogBackupArchive and binLogBackupTriggeredBy == "restore") or (incrBackupArchive and incrBackupParentBackupId != fullBackupBackupId ):
        restoreId = dictionary_data["SM_OPERATION_INFO"]["requestAttributes"]["restoreId"]
        #more specific error message
        if not fullBackupArchive:
           common_lib.logger("ERROR", "No scheduled full backup found for recovery time {recvtime}".format(recvtime=restoreId))
           op_return_obj.set_status_msg("<MSCS-ERR-20845>: No scheduled full backup found for recovery time.")
        elif binLogBackupArchive and binLogBackupTriggeredBy == "restore":
           common_lib.logger("ERROR", "Full backup triggered by previous restore operation cannot be used for recovery as they donot contain binary logs for recovery time {recvtime}".format(recvtime=restoreId))
           op_return_obj.set_status_msg("<MSCS-ERR-20846>: Full backup triggered by previous restore operation cannot be used for recovery as they donot contain binary logs for recovery time.")
    #    elif not binLogBackupArchive:
    #       common_lib.logger("ERROR", "No backup found containing binary logs for recovery time {recvtime}".format(recvtime=restoreId))
    #       op_return_obj.set_status_msg("<MSCS-ERR-20847>: No backup found containing binary logs for recovery time.")
        elif incrBackupArchive and incrBackupParentBackupId != fullBackupBackupId:
           common_lib.logger("ERROR", "The corresponding full backup for the incremental backup {incrbackup} not found".format(incrbackup=incrBackupArchive))
           op_return_obj.set_status_msg("<MSCS-ERR-20848>: No backups found for recovery time.")
        else:
           common_lib.logger("ERROR", "No backups found for recovery time {recvtime}".format(recvtime=restoreId))
           op_return_obj.set_status_msg("<MSCS-ERR-20805>: No backups found for recovery time.")

        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type("Fatal")
        return None, None, None, op_return_obj

    fullBackupMetaData = common_lib.BackupMetaData("full",fullBackupArchive,fullBackupStartTime,fullBackupEndTime,fullBackupStartLSN,fullBackupEndLSN,fullBackupBinLog,fullBackupBinPos,fullBackupStorageURI)
    if incrBackupArchive:
        incrBackupMetaData = common_lib.BackupMetaData("incr",incrBackupArchive,incrBackupStartTime,incrBackupEndTime,incrBackupStartLSN,incrBackupEndLSN,incrBackupBinLog,incrBackupBinPos,incrBackupStorageURI)
    else:
        incrBackupMetaData = None

    binLogBackupMetaData = common_lib.BackupMetaData("full" if binLogBackupIsFull else "incr",binLogBackupArchive,binLogBackupStartTime,binLogBackupEndTime,binLogBackupStartLSN,binLogBackupEndLSN,binLogBackupBinLog,binLogBackupBinPos,binLogBackupStorageURI) if not skip_extract else None
    return fullBackupMetaData, incrBackupMetaData, binLogBackupMetaData, op_return_obj


def getExtractCommandBMC(dictionary_data, backupMetaData,localBackupVolume,backupDestination):
    """
      Generates the MEB commands for extraction from BMC cloud
      input:
            dictionary_data, input JSON
            backupMetaData, metadata of the backup to be used for extraction of binary logs.
      return:
            MEB command for extraction.
    """
    import urlparse
    import os

    #localBackupVolume = dictionary_data["SM_SERVICE_INFO"]["attributes"]["LOCAL_BACKUP_VOLUME_MOUNT"]
    backupDir = os.path.join(localBackupVolume, "extractTemp")
    dataDir = os.path.join(backupDir, "datadir")
    cloudStorageURL = backupMetaData.getBackupStorageURI()
    diskArchive = backupMetaData.getBackupImage();
    if backupDestination != 'OSS':
       cloudObject = diskArchive.replace(localBackupVolume,"", 1) if not diskArchive.replace(localBackupVolume,"", 1).startswith('/') else diskArchive.replace(localBackupVolume,"", 1)[1:]
    else:
       cloudObject = diskArchive.replace(cloudStorageURL,"",1)
       cloudObject = cloudObject[1:] if cloudObject.startswith('/') else cloudObject

    cloudStorageUser = dictionary_data['SM_OPERATION_INFO']['cloudStorageUser']
    cloudStoragePassword = dictionary_data['SM_OPERATION_INFO']['cloudStoragePassword']

    cloudStorageServiceInstanceContainer = common_lib.get_Container_from_Storage_URL(cloudStorageURL)
    cloudStorageContainer = cloudStorageServiceInstanceContainer.split('/')[1]
    if backupMetaData.getBackupType() == "full":
       extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + cloudStorageUser + "'"
               " --cloud-password='" + cloudStoragePassword + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(cloudStorageURL) + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --backup-dir=" + backupDir + " "
               " --datadir=" + dataDir + " "
               " --innodb_log_group_home_dir=" + dataDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  --uncompress --force copy-back-and-apply-log  " )
    else:
        extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER  +  " "
               "--cloud-service=openstack "
               " --cloud-user-id='" + cloudStorageUser + "'"
               " --cloud-password='" + cloudStoragePassword + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(cloudStorageURL) + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --backup-dir=" + backupDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  extract  " )
    extractCmdToPrint = extractCmd.replace(cloudStoragePassword, "XXXXXXXX")
    return extractCmd, extractCmdToPrint

def getExtractCommand(dictionary_data, backupMetaData,localBackupVolume,backupDestination):
    """
      Generates the MEB commands for extraction
      input:
            dictionary_data, input JSON
            backupMetaData, metadata of the backup to be used for extraction of binary logs.
      return:
            MEB command for extraction.
    """
    import urlparse
    import os

    #localBackupVolume = dictionary_data["SM_SERVICE_INFO"]["attributes"]["LOCAL_BACKUP_VOLUME_MOUNT"]
    backupDir = os.path.join(localBackupVolume, "extractTemp")
    dataDir = os.path.join(backupDir, "datadir")
    cloudStorageURL = backupMetaData.getBackupStorageURI()
    diskArchive = backupMetaData.getBackupImage();
    if backupDestination != 'OSS':
       cloudObject = diskArchive.replace(localBackupVolume,"", 1) if not diskArchive.replace(localBackupVolume,"", 1).startswith('/') else diskArchive.replace(localBackupVolume,"", 1)[1:]
    else:
       cloudObject = diskArchive.replace(cloudStorageURL,"",1)
       cloudObject = cloudObject[1:] if cloudObject.startswith('/') else cloudObject

    cloudStorageUser = dictionary_data['SM_OPERATION_INFO']['cloudStorageUser']
    cloudStoragePassword = dictionary_data['SM_OPERATION_INFO']['cloudStoragePassword']

    cloudStorageServiceInstanceContainer = common_lib.get_Container_from_Storage_URL(cloudStorageURL)
    mebCloudStorageUser = cloudStorageServiceInstanceContainer.split('/')[0] + ":" + cloudStorageUser
    uriTokens = urlparse.urlparse(cloudStorageURL)
    mebCloudStorageURI = uriTokens.scheme + "://" + uriTokens.netloc
    cloudStorageContainer = cloudStorageServiceInstanceContainer.split('/')[1]
    if backupMetaData.getBackupType() == "full":
       extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + mebCloudStorageUser + "'"
               " --cloud-password='" + cloudStoragePassword + "'"
               " --cloud-tempauth-url=" + mebCloudStorageURI + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --backup-dir=" + backupDir + " "
               " --datadir=" + dataDir + " "
               " --innodb_log_group_home_dir=" + dataDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  --uncompress --force copy-back-and-apply-log  " )
    else:
        extractCmd = ( constants.MEB_LOC  +  " " +  " --user=" + constants.MYSQL_USER  +  " "
               "--cloud-service=openstack "
               " --cloud-user-id='" + mebCloudStorageUser + "'"
               " --cloud-password='" + cloudStoragePassword + "'"
               " --cloud-tempauth-url=" + mebCloudStorageURI + " "
               " --cloud-container=" + cloudStorageContainer + " "
               " --cloud-object=" + cloudObject + " "
               " --backup-dir=" + backupDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  extract  " )
    extractCmdToPrint = extractCmd.replace(cloudStoragePassword, "XXXXXXXX")
    return extractCmd, extractCmdToPrint

def getBinLogsForPITR(fullBackupMetaData, incrBackupMetaData, binLogDir, PITRTimeInEpoch):
    """
      Discovers the binary logs required for the recovery and the binlog offset from where the binlog appliaction should start.
    """
    import socket
    import re

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    #apply binary logs
    binlogFile = fullBackupMetaData.getBinLogFile()
    binlogPos = fullBackupMetaData.getBinLogPos()
    if incrBackupMetaData:
    # if there is an incremnat backup, the first binary log will be from this incremental
        binlogFile = incrBackupMetaData.getBinLogFile()
        binlogPos = incrBackupMetaData.getBinLogPos()

    binlogFile = os.path.join(binLogDir, binlogFile )
    recovery_binary_log=""
    #get start time from the binary log

    if os.path.isfile(binlogFile):
    #get the start time and server id for the first binary log
       sepoch, serverid, result_obj =  getBinaryLogsStarttime(binlogFile)
       if not result_obj.get_bool_status():
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type(result_obj.get_error_type())
          op_return_obj.set_status_msg(result_obj.get_status_msg())
          return None, op_return_obj

       #get the list of binary logs
       host = socket.gethostname()
       binlogDir = os.path.dirname(binlogFile)
       binlogList=[os.path.join(binlogDir,bfile) for bfile in os.listdir(binlogDir) if re.match(r'.*\.[0-9]+$', bfile) and bfile.startswith(host)]
       binary_logfiles=filterBinaryLogsForPITR(binlogList, sepoch, PITRTimeInEpoch, serverid )
       #Apply binary logs
       #recovery_binary_log=[]
       #for key in sorted(binary_logfiles):
       #    recovery_binary_log.append( binary_logfiles.get(key))
           #common_lib.logger("INFO", "==========Binary logs:" + binary_logfiles.get(key))
       #apply_exe_result = applyBinaryLogs(recovery_binary_log, USER,binlogPos,PITRTimeInEpoch)
       # check result
    else:
        #missing binary log
       common_lib.logger("ERROR","No Binary logs available for recovery")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("No Binary logs available for recovery")
       return None, None, op_return_obj

    return binary_logfiles, binlogPos, op_return_obj

def do_recovery(dictionary_data):
    """
      Performs recovery operation
    """
    import os
    import urlparse
    import restore
    import re
    import socket


    common_lib.logger("INFO", "Staring recovery process.")
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    USER = constants.MYSQL_USER

    backupDestination = dictionary_data["SM_SERVICE_INFO"]["attributes"]["BACKUP_DESTINATION"]
    localBackupVolume = dictionary_data["SM_SERVICE_INFO"]["attributes"]["LOCAL_BACKUP_VOLUME_MOUNT"] if backupDestination != 'OSS' else os.path.dirname(constants.DATA_DIR)
    backupDir = os.path.join(localBackupVolume, "extractTemp")
    binLogDir = os.path.join(backupDir, "datadir")

    cloudUser = dictionary_data["SM_OPERATION_INFO"]["cloudStorageUser"]
    cloudPassword = dictionary_data["SM_OPERATION_INFO"]["cloudStoragePassword"]
    cloudStorageURI = dictionary_data["SM_OPERATION_INFO"]["storageURI"] + "/"
    restoreId = dictionary_data["SM_OPERATION_INFO"]["requestAttributes"]["restoreId"]

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    executor = common_lib.Executor()

    #convert to epoch
    common_lib.logger("INFO", "Getting backups for recovery process.")
    PITRTimeInEpoch  = common_lib.getEpoch(restoreId, '%m/%d/%Y %H:%M:%S')
    fullBackupMetaData, incrBackupMetaData, binLogBackupMetaData, pitr_result_obj = \
        getBackupsForRecovery(PITRTimeInEpoch, dictionary_data, binLogDir)
    if not pitr_result_obj.get_bool_status():
        common_lib.logger("ERROR", "Point in time recover not possible for the selected time {pitrTime}."
                          .format(pitrTime=restoreId))
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type(pitr_result_obj.get_error_type())
        op_return_obj.set_status_msg(pitr_result_obj.get_status_msg())
        return None, op_return_obj

    if not skip_extract:
       common_lib.logger("INFO", "Extracting backup from cloud to obtain the binary logs for recovery process.")
       extract_return_obj = extractBinlogFromBackupImage(dictionary_data, binLogBackupMetaData, localBackupVolume,backupDestination)

       if not extract_return_obj.get_bool_status():
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type(extract_return_obj.get_error_type())
          op_return_obj.set_status_msg(extract_return_obj.get_status_msg())
          #remove the extract directory
          shutil.rmtree(backupDir, ignore_errors=True)
          return None, op_return_obj

    common_lib.logger("INFO", "Getting binary logs for recovery process.")
    recovery_bin_logs, binLogPos, getBinLog_exec_restult = getBinLogsForPITR(fullBackupMetaData, incrBackupMetaData, binLogDir, PITRTimeInEpoch)

   #apply_exe_result = applyBinaryLogs(recovery_binary_log, USER,binlogPos,PITRTimeInEpoch)
       # check result
   # else:
   #missing binary log
    if not getBinLog_exec_restult.get_bool_status():
       common_lib.logger("ERROR","No Binary logs available for recovery")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type(getBinLog_exec_restult.get_error_type())
       op_return_obj.set_status_msg("No Binary logs available for recovery")
       #remove the extract directory
       shutil.rmtree(backupDir, ignore_errors=True)
       return None, op_return_obj

    #if recovery_bin_logs is empty exit
    if not recovery_bin_logs:
       common_lib.logger("ERROR","No Binary logs available for recovery")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("No Binary logs available for recovery")
       #remove the extract directory
       shutil.rmtree(backupDir, ignore_errors=True)
       return None, op_return_obj

    #print the artifacts needed for recovery
    common_lib.logger("INFO","Following artifacts will be used for recovery")
    common_lib.logger("INFO","Full backup {backup}".format(backup=fullBackupMetaData.getBackupImage()))
    if incrBackupMetaData :
       common_lib.logger("INFO","Differential backup {backup}".format(backup=incrBackupMetaData.getBackupImage()))
    #binary logs
    recoveryBinaryLog=""
    for key in sorted(recovery_bin_logs):
        recoveryBinaryLog = recoveryBinaryLog + " " + recovery_bin_logs.get(key)
        common_lib.logger("INFO", "==========Binary logs:" + recovery_bin_logs.get(key))

    common_lib.logger("INFO", "Starting restore.")
    restoreObj, restore_return_obj = doRestore(dictionary_data,fullBackupMetaData,incrBackupMetaData,backupDestination )
    if not restore_return_obj.get_bool_status():
       common_lib.logger("ERROR","Restore of MySQL failed.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type(restore_return_obj.get_error_type())
       op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
       #remove the extract directory
       shutil.rmtree(backupDir, ignore_errors=True)
       return None, op_return_obj

    apply_exec_result = applyBinaryLogs(recoveryBinaryLog, USER, binLogPos, PITRTimeInEpoch)
    if apply_exec_result.get_return_code() != 0:
       common_lib.logger("ERROR","Applying binary logs to MySQL database failed.")
       common_lib.logger("ERROR",apply_exec_result.get_std_out())
       common_lib.logger("ERROR",apply_exec_result.get_std_err())
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20806>: Applying binary logs to MySQL database failed.")
       #remove the extract directory
       shutil.rmtree(backupDir, ignore_errors=True)
       #switch the data directory to what was before the restore and binlog apply
       common_lib.logger("INFO","Reverting the database to a state before restore.")
       switch_result = switch_directory(restoreObj)
       return restoreObj, op_return_obj

    shutil.rmtree(backupDir, ignore_errors=True)
    op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
    return restoreObj, op_return_obj

def doRestore(dictionary_data, fullBackupMetaData, incrBackupMetaData, backupDestination):
    """
      Performs restore operation
    """
    import restore

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    try:
       dictionaryDataForRestore = generateJSONForRestore(dictionary_data, fullBackupMetaData, incrBackupMetaData)
       isBMC = True if dictionaryDataForRestore['SM_OPERATION_INFO']['backup']['backupStorageURI'].startswith("https://swiftobjectstorage") else False
       if  backupDestination != 'OSS':
           if incrBackupMetaData :
              restoreObj = restore.IncrementalCloudRestoreBMC(dictionaryDataForRestore) if isBMC else restore.IncrementalCloudRestore(dictionaryDataForRestore)
           else:
              restoreObj = restore.FullCloudRestoreBMC(dictionaryDataForRestore) if isBMC else restore.FullCloudRestore(dictionaryDataForRestore)
       else:
           if incrBackupMetaData :
              restoreObj = restore.IncrementalCloudOnlyRestoreBMC(dictionaryDataForRestore) if isBMC else restore.IncrementalCloudOnlyRestore(dictionaryDataForRestore)
           else:
              restoreObj = restore.FullCloudOnlyRestoreBMC(dictionaryDataForRestore) if isBMC else restore.FullCloudOnlyRestore(dictionaryDataForRestore)

    except KeyError as e:
       common_lib.logger("ERROR","Some keys missing in the Input JSON, failing with key error while parsing error: {err}".format(err=e))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20902>: Unable to obtain the restore object.")
       return op_return_obj


    restore_return_obj = restoreObj.doRestore()
    if not restore_return_obj.get_bool_status() :
       if not restoreObj.isDataDirFlipped() and os.listdir(restoreObj.get_restoreDirectory()):
          common_lib.logger("ERROR","Restore operation failed, but trying to start mysql on the current data directory (data before retore operation).")
          # do it only when the server is down
          checkResult=restoreObj.checkMySQLStatus()
          if checkResult.get_return_code() != 0:
             #start the server
             restoreObj.startMySQL()
          #cleanup
          if os.path.exists(restoreObj.get_restoredLogdir()) or os.path.exists(restoreObj.get_restoredDirectory()) :
             common_lib.logger("INFO","Removing temp restore directory")
             shutil.rmtree(restoreObj.get_restoredLogdir(), ignore_errors=True)
             shutil.rmtree(restoreObj.get_restoredDirectory(), ignore_errors=True)


       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type(restore_return_obj.get_error_type())
       op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
       return restoreObj, op_return_obj

    op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
    return restoreObj, op_return_obj

def switch_directory(restoreObj):
    """
      Will switch the data and log directory to what it was before the restore
    """

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    # If database is up shotdown the database
    checkResult=restoreObj.checkMySQLStatus()
    if checkResult.get_return_code() == 0:
       stop_return_obj = restoreObj.stopMySQL()
       if not stop_return_obj.get_bool_status():
          common_lib.logger("ERROR","Could not stop MySQL server.")
          op_return_obj.set_bool_status(stop_return_obj.get_bool_status())
          op_return_obj.set_status_msg(stop_return_obj.get_status_msg())
          return op_return_obj
       common_lib.logger("INFO","Stopped MySQL server.")


    #switch data directory
    fromDirectory=restoreObj.get_restoredDirectory() + '-tmp'
    toDirectory=restoreObj.get_restoreDirectory()
    shutil.rmtree(toDirectory, ignore_errors=True)
    common_lib.logger("INFO","Renaming  {datadir} to {datadirnew} ".format(datadir = fromDirectory, datadirnew=toDirectory))
    try:
       shutil.move(fromDirectory, toDirectory)
    except OSError as e:
       common_lib.logger("ERROR","Unable to rename data directory OS.OSError.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("Unable to rename data directory OSError.")
       return op_return_obj

    #switch logdirectory
    if restoreObj.get_restoreLogdir() != restoreObj.get_restoreDirectory():
       fromDirectory = restoreObj.get_restoredLogdir() + '-tmp'
       toDirectory = restoreObj.get_restoreLogdir()
       shutil.rmtree(toDirectory, ignore_errors=True)
       common_lib.logger("INFO","Renaming  {datadir} to {datadirnew} ".format(datadir = fromDirectory, datadirnew=toDirectory))
       try:
          shutil.move(fromDirectory, toDirectory)
       except OSError as e:
          common_lib.logger("ERROR","Unable to rename log directory OS.OSError.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("Unable to rename log directory OSError.")
          return op_return_obj

    #Now start MySQL server
    common_lib.logger("INFO", "Starting MySQL.")
    return_obj = restoreObj.startMySQL()
    if not return_obj.get_bool_status() :
       common_lib.logger("ERROR","Unable to start MySQL.")
       op_return_obj.set_bool_status(return_obj.get_bool_status())
       op_return_obj.set_status_msg(return_obj.get_status_msg())
       return op_return_obj

def generateJSONForRestore(dictionary_data, fullBackupMetaData, incrBackupMetaData):
    """
      Generates dictionary/JSON for retore opertaion
      input:
           dictionary_data, input JSON
           fullBackupMetaData, metadata of the full backup to be used for restore
           incrBackupMetaData, metadata of the incremental backup to be used for restore
      return:
            dictionary containing information for restore operation
    """
    try:
       dictionaryDataForRestore = dict()
       dictionaryDataForRestore["SM_OPERATION_INFO"] = dict()
       dictionaryDataForRestore["SM_OPERATION_INFO"]["cloudStoragePassword"] = dictionary_data["SM_OPERATION_INFO"]["cloudStoragePassword"]
       dictionaryDataForRestore["SM_OPERATION_INFO"]["cloudStorageUser"] = dictionary_data["SM_OPERATION_INFO"]["cloudStorageUser"]
       dictionaryDataForRestore["SM_OPERATION_INFO"]["storageURI"] = dictionary_data["SM_OPERATION_INFO"]["storageURI"]
       dictionaryDataForRestore["SM_OPERATION_INFO"]["backupId"] = dictionary_data["SM_OPERATION_INFO"]["nextBackupId"]
       dictionaryDataForRestore["SM_SERVICE_INFO"] = dict()
       dictionaryDataForRestore["SM_SERVICE_INFO"]["serviceName"] = dictionary_data["SM_SERVICE_INFO"]["serviceName"]
       dictionaryDataForRestore["SM_SERVICE_INFO"]["serviceType"] = dictionary_data["SM_SERVICE_INFO"]["serviceType"]
       dictionaryDataForRestore["SM_SERVICE_INFO"]["attributes"] = dict()
       if dictionary_data["SM_SERVICE_INFO"]["attributes"]["BACKUP_DESTINATION"] == 'BOTH':
          dictionaryDataForRestore['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']=dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
       dictionaryDataForRestore['SM_SERVICE_INFO']['attributes']['CLOUD_STORAGE_CONTAINER']=dictionary_data['SM_SERVICE_INFO']['attributes']['CLOUD_STORAGE_CONTAINER']
       dictionaryDataForRestore["SM_SERVICE_INFO"]["components"] = dict()
       dictionaryDataForRestore["SM_SERVICE_INFO"]["components"]["mysql"] = dict()
       dictionaryDataForRestore["SM_SERVICE_INFO"]["components"]["mysql"]["vmInstances"] = dictionary_data["SM_SERVICE_INFO"]["components"]["mysql"]["vmInstances"]

       dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"] = dict()
       dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["fullBackup"] = dict()
       dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["initiatedBy"] = "pitr"

       if incrBackupMetaData:
          dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["isFull"] = False
          dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["backupStorageURI"] = incrBackupMetaData.getBackupStorageURI()
          if dictionary_data["SM_SERVICE_INFO"]["attributes"]["BACKUP_DESTINATION"] == 'BOTH':
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["archiveFileName"] =  incrBackupMetaData.getBackupImage().replace(dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT'], '',1)
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["fullBackup"]["archiveFileName"] = fullBackupMetaData.getBackupImage().replace(dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT'], '',1)
          else:
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["archiveFileName"] =  incrBackupMetaData.getBackupImage().replace(incrBackupMetaData.getBackupStorageURI() + '/' if not (incrBackupMetaData.getBackupStorageURI()).endswith('/') else incrBackupMetaData.getBackupStorageURI(), '',1)
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["fullBackup"]["archiveFileName"] = fullBackupMetaData.getBackupImage().replace(fullBackupMetaData.getBackupStorageURI() + '/' if not (fullBackupMetaData.getBackupStorageURI()).endswith('/') else fullBackupMetaData.getBackupStorageURI(), '',1)

       else:
          dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["isFull"] = True
          dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["backupStorageURI"] = fullBackupMetaData.getBackupStorageURI()
          dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["fullBackup"]["archiveFileName"] = None
          if dictionary_data["SM_SERVICE_INFO"]["attributes"]["BACKUP_DESTINATION"] == 'BOTH' :
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["archiveFileName"] =  fullBackupMetaData.getBackupImage().replace(dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT'], '',1)
          else:
             dictionaryDataForRestore["SM_OPERATION_INFO"]["backup"]["archiveFileName"] =  fullBackupMetaData.getBackupImage().replace(fullBackupMetaData.getBackupStorageURI() + '/' if not (fullBackupMetaData.getBackupStorageURI()).endswith('/') else fullBackupMetaData.getBackupStorageURI(), '',1)

    except KeyError as e:
       raise KeyError

    return dictionaryDataForRestore



def extractBinlogFromBackupImage(dictionary_data, backupMetaData, localBackupVolume, backupDestination):
    """
      Extract the binary logs from downloaded image uses mysqlbackup
      input:
            backupMetaData, metadata of the brackup from which binary logs to be extracted
            dictionary_data, input JSON
      return:
            operation object
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    executor = common_lib.Executor()

    isBMC = True if dictionary_data['SM_OPERATION_INFO']['storageURI'].startswith("https://swiftobjectstorage") else False
    extractCommand, extractCommandForPrint  = getExtractCommandBMC(dictionary_data, backupMetaData, localBackupVolume, backupDestination) if isBMC else  getExtractCommand(dictionary_data, backupMetaData, localBackupVolume, backupDestination)

    common_lib.logger("INFO","Executing extract command: {extractCommand}"\
                                        .format(extractCommand=extractCommandForPrint))
    exe_result = executor.execute_cmd(commandline=extractCommand, command_for_print=extractCommandForPrint)
    common_lib.logger("INFO","===============Output from mysqlbackup (restore) ================")
    std_out = exe_result.get_std_out()
    std_err = exe_result.get_std_err()
    print exe_result.get_std_out()
    print exe_result.get_std_err()

    #check for 'mysqlbackup completed OK!' to conform the success
    #if restore fails exit with error
    if exe_result.get_return_code() != 0:
       common_lib.logger("ERROR","Extracting backup from cloud failed.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20804>: Extracting backup from cloud failed.")
       return op_return_obj

    common_lib.logger("INFO","Extracting backup from cloud storage succeeded.")
    return op_return_obj


def validateRecoveryTime(rtime):
    """
    This function validates the recovery time for format
    and also for it the recovery time is in future.
    Returns:
       rtype: OperationReturnObj
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    # Check the date format
    try:
        datetime.strptime(rtime, '%m/%d/%Y %H:%M:%S')
    except ValueError:
        common_lib.logger("ERROR", "Invalid date format, format should be in '%m/%d/%Y %H:%M:%S'")
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type("Fatal")
        op_return_obj.set_status_msg("<MSCS-ERR-20802>: Invalid date format, format should be in '%m/%d/%Y %H:%M:%S'")
        return op_return_obj

    # Check if the recovery time is in future
    recovery_time_epoch = common_lib.getEpoch(rtime, '%m/%d/%Y %H:%M:%S')
    current_time_epoch = common_lib.getEpoch(time.strftime("%m/%d/%Y %H:%M:%S"),"%m/%d/%Y %H:%M:%S",localTime=True)

    if recovery_time_epoch > current_time_epoch :
        common_lib.logger("ERROR", "Cannot recover to a future time.")
        common_lib.logger("ERROR", "Current time in epoch : {currtime}".format(currtime=str(current_time_epoch)))
        common_lib.logger("ERROR", "Recovery time in epoch : {recvtime}".format(recvtime=str(recovery_time_epoch)))
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type("Fatal")
        op_return_obj.set_status_msg("<MSCS-ERR-20803>: Cannot recover to a future time.")
        return op_return_obj

    # Check if the recovery time is within retention time
    if recovery_time_epoch < current_time_epoch - constants.CLOUD_RETENTION_DAYS * 86400:
        common_lib.logger("ERROR", "The recovery time is beyond the retention policy.")
        common_lib.logger("ERROR", "Current time in epoch : {currtime}".format(currtime=str(current_time_epoch)))
        common_lib.logger("ERROR", "Recovery time in epoch : {recvtime}".format(recvtime=str(recovery_time_epoch)))
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type("Fatal")
        op_return_obj.set_status_msg("<MSCS-ERR-20809>: The recovery time is beyond the retention policy.")
        return op_return_obj

    return op_return_obj


def recovery_pre_check(dictionary_data):
    """
      Performs recovery pre-check
      input:
            input JSON
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    result_obj = common_lib.OperationReturnObj()
    result_obj.set_bool_status(True)

    backupDestination = dictionary_data["SM_SERVICE_INFO"]["attributes"]["BACKUP_DESTINATION"]
    localBackupVolume = dictionary_data["SM_SERVICE_INFO"]["attributes"]["LOCAL_BACKUP_VOLUME_MOUNT"] if backupDestination != 'OSS' else os.path.dirname(constants.DATA_DIR)
    backupDir = os.path.join(localBackupVolume, "extractTemp")
    binLogDir = os.path.join(backupDir, "datadir")

    restoreId = dictionary_data["SM_OPERATION_INFO"]["requestAttributes"]["restoreId"]

    # First validate recovery time
    result_obj = validateRecoveryTime(restoreId)
    if not result_obj.get_bool_status():
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type(result_obj.get_error_type())
        op_return_obj.set_status_msg(result_obj.get_status_msg())
        return op_return_obj

    # Next check whether all needed backups are present
    PITRTimeInEpoch  = common_lib.getEpoch(restoreId, '%m/%d/%Y %H:%M:%S')
    fullBackupMetaData, incrBackupMetaData, binLogBackupMetaData, result_obj = \
        getBackupsForRecovery(PITRTimeInEpoch, dictionary_data, binLogDir)

    if not result_obj.get_bool_status():
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type(result_obj.get_error_type())
        op_return_obj.set_status_msg(result_obj.get_status_msg())
        return op_return_obj

    if incrBackupMetaData:
        common_lib.logger("INFO","Use incremental backup: {image}.".format(image=incrBackupMetaData.getBackupImage()))

    common_lib.logger("INFO","Use full backup: {image}.".format(image=fullBackupMetaData.getBackupImage()))
    if not skip_extract:
       common_lib.logger("INFO","Use binlog from backup: {image}.".format(image=binLogBackupMetaData.getBackupImage()))
    return op_return_obj


