#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'daniel, pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

REMOTE_CMD_TIMEOUT = 1200

SSH_CONNECTION_TIMEOUT = 600

SSH_OPTIONS = "-T -o UserKnownHostsFile=/dev/null " \
              "-o StrictHostKeyChecking=no " \
              "-o LogLevel=error " \
              "-o BatchMode=yes " \
              "-o ConnectTimeout=%s" % SSH_CONNECTION_TIMEOUT

SCP_OPTIONS = "-o UserKnownHostsFile=/dev/null " \
              "-o StrictHostKeyChecking=no " \
              "-o LogLevel=error " \
              "-o BatchMode=yes " \
              "-o ConnectTimeout=%s -p" % SSH_CONNECTION_TIMEOUT

COMPONENT_NAME = "ES"

# This section is the definition of keys in json bag
backupId = "backupId"
localBackupLocation = "localBackupLocation"
components = "components"
backupEnabled = "backupEnabled"
vms = "vms"

INCREMENTAL_BACKUP_DIR = "scheduledIncremental"
FULL_BACKUP_DIR = "scheduledFull"
ON_DEMAND_BACKUP_DIR = "onDemandFull"
INCREMENTAL_BACKUP_NAME = "backup_incremental.mbi"
FULL_BACKUP_NAME = "backup_full.mbi"
LOCAL_RETENTION_DAYS = 7
CLOUD_RETENTION_DAYS = 30

STATUS_LOG_JSON_KEY = "statusLog"
BACKUP_ARCHIVE_JSON_KEY = "archiveFileName"
CHECKSUM_JSON_KEY = "checksum"
SIZE_JSON_KEY = "size"
BACKED_UP_HOSTS_LIST_JSON_KEY = "backedUpHosts"
RESTORED_HOSTS_LIST_JSON_KEY = "restoredHosts"
NOT_RESTORED_HOSTS_LIST_JSON_KEY = "notRestoredHosts"
DB_TAG_JSON_KEY = "dbTag"
COMPLETE_CONFIG_JSON_KEY = "completeConfig"
HTTP_CODE_JSON_KEY = "httpCode"
SERVICE_INFO = "SM_SERVICE_INFO"
BACKUP_TAG_JSON_KEY = "tag"

# Exclusion list for datadir cleanup
#File exclusion list
FILE_EXCLUSION_LIST = [".pem",".pid",".index"]
#Directory exclusion list
DIR_EXCLUSION_LIST = []
#mysqlbackup binary location
MEB_LOC="/u01/bin/meb/bin/mysqlbackup"
#MySQL data directory
DATA_DIR="/u01/data/mysql"
#MySQL user
MYSQL_USER="oracle"
#Cloud key for Backups
CLOUD_KEY="MySQL/backup"
#https connection timeout
TIMEOUT=1200
#chunk size for chunked upload
CHUNKSIZE=4096 * 1024 * 1024
BACKUP_CONTENT_XML = "meta/backup_content.xml"
#CA cert info
CA_CERT_INFO = "/etc/ssl/certs/ca-bundle.crt"
#post restore backup JSON keys
POSTRESTORE_BACKUP_STATUS_JSON_KEY = "status"
POSTRESTORE_BACKUP_STATUS_MESSAGE_JSON_KEY = "statusMessage"
POSTRESTORE_BACKUP_START_DATE_JSON_KEY = "backupStartDate"
POSTRESTORE_BACKUP_IS_LOCAL_JSON_KEY = "isLocal"
POSTRESTORE_BACKUP_END_DATE_JSON_KEY = "backupCompleteDate"
POSTRESTORE_BACKUP_CHECKSUM_JSON_KEY = "checksum"
POSTRESTORE_BACKUP_BACKED_UP_HOST_JSON_KEY = "backedUpHosts"
POSTRESTORE_BACKUP_HAS_LOCAL_COPY_JSON_KEY = "hasLocalCopy"
POSTRESTORE_BACKUP_TAG_JSON_KEY = "tag"
POSTRESTORE_BACKUP_ARCHIVE_FILE_NAME_JSON_KEY = "archiveFileName"
POSTRESTORE_BACKUP_IS_FULL_JSON_KEY = "isFull"
POSTRESTORE_BACKUP_BACKUP_ID_JSON_KEY = "backupId"
POSTRESTORE_BACKUP_INITIATED_BY_JSON_KEY = "initiatedBy"
POSTRESTORE_BACKUP_FILE_SIZE_JSON_KEY = "size"
MBLPATH="/u01/bin/mysql/bin"
MSQLPATH="/u01/bin/mysql/bin"
MYDOTCNF="/u01/bin/mysql/my.cnf"
MYSQLDUMP_TEMP_LOCATION_BACKUP="/u01/backup/tempCreateInstance"
MYSQLDUMP_TEMP_LOCATION_DATA="/u01/data/tempCreateInstance"
MYCNF_CHANGE_PROPERTIES=["innodb_undo_tablespaces","innodb_page_size","innodb_checksum_algorithm","character_set_server","collation_server","default_time_zone"]
