#
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#

import json
import os
import sys
import time
import socket
import subprocess


def logger(level, message):
    """
    logger prints the level and message to standard out
    """ 
    if level == 'PLAIN':
        print message
    else:
        print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()),
                              level, message)

# blocking call
def call(command, args=None):
    if args:
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(command)
    else:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = process.communicate()

    if not stdout:
        stdout = stderr
    return  process.returncode, stdout

#call the command and record result
def run(command, host='localhost', remoteSSHRetries=5, sleepBetweenRemoteSSHRetries=1):
    startps = time.time();
    hostname=socket.gethostname()
    if host.lower() == hostname.lower() or host.lower() == 'localhost':
        # the command needs to be run locally
        status, stdout = call(command)
    else:
        # the command needs to be run on remote VM.
        import shlex
        remote_command = "ssh -T -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
        args = shlex.split(remote_command)
        args.append(host)

        for iteration in range(remoteSSHRetries):
            # run the command on remote VM and watch out for network related mishaps
            status, stdout = call(command, args=args)
            if "ssh: Could not resolve hostname" in stdout:
                time.sleep(sleepBetweenRemoteSSHRetries)
            else:
                break
        command = "{0} \"{1}\"".format(remote_command, command)
    return status, stdout

#to print the dictionary as a json
def print_dict_as_json(dictionary):
    try:
        print json.dumps(dictionary, indent=4)
    except Exception as e:
        print str(e)

#called by SM
def execute(data):
    logger("INFO","Script invoked for stopping the service")
    #logger("INFO","The subscription type for this service is : " +data['SM_SERVICE_INFO']['subscription'])
    logger("INFO","The formatted input json is as ")
    print_dict_as_json(data)
    tools_path=os.path.realpath(__file__)
    mysql_install_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"
    command = "source {mysql_install_script} && shutdownMysql oracle".format(mysql_install_script=mysql_install_script)
    logger("INFO","Command for stopping MySQL server : " +command)
    status,stdout = run(command)
    logger("INFO", "Status for the command run is : " +str(status) + ". The stdout says : " +str(stdout))
    result = {}
    if status == 0:
        logger("INFO","Successfully stopped the MySQL server!")
        result["status"] = "Success"
        result["statusMessage"] = "Successfully stopped the MySQL server!"
    else:
        logger("ERROR","Couldn't stop the MySQL server!")
        result["status"] = "Failed"
        result["statusMessage"] = "Couldn't stop the MySQL server!"

    logger("INFO","Exiting from the script")
    print "<JsonResult>"+json.dumps(result)+"</JsonResult>"
