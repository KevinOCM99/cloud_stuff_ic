#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import abc
import os
import constants
import shutil
import urlparse
import msaas_common_lib as common_lib


#
##
###
def clock(func):
    """
    Decorator function for decorating functions that need timing information
    """
    from datetime import  datetime

    def clocked(*args):
        name = func.__name__
        common_lib.logger("INFO","Entering {name}.".format(name=name))
        startTime = datetime.now()
        result = func(*args)
        duration = datetime.now() - startTime
        duration = duration.seconds * 1000 + duration.microseconds / 1000.0
        common_lib.logger("INFO","Leaving {name}.".format(name=name))
        common_lib.logger("INFO","Total time spent on {name} in milliseconds {duration}".format(name=name, duration=duration))
        return result
    return clocked


class RestoreFactory():
    """
    Restore factory class
    """

    def __init__(self, dictionaryData):
        self.dictionaryData = dictionaryData

    def get_restoreObject(self):
        """
        Returns restore object based on the backup destination and type of the backup, full or incremental.
        If the backup(cloud) image is avialable on the disk also then a disk restore object is returned.
        The cloud restore object is returned only if the disk backup image is not avialable.
        """
        try:
           backupDestination = self.dictionaryData['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
           isFull = self.dictionaryData['SM_OPERATION_INFO']['backup']['isFull']
           archiveFileName = self.dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName']
           isBMC = True if self.dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI'].startswith("https://swiftobjectstorage") else False 
           if (backupDestination == "BOTH" or backupDestination == "OSS") and not isFull :
              parentBackupArchiveFileName = self.dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
        except KeyError as e:
           common_lib.logger("ERROR","Expected keys missing in the input JSON.")
           raise KeyError

        if backupDestination == "DISK" and isFull :
           return FullDiskRestore(self.dictionaryData)
        elif backupDestination == "DISK" and not isFull :
           return IncrementalDiskRestore(self.dictionaryData)
        elif backupDestination == "BOTH" and isFull :
           localBackUpRoot = self.dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
           #make it work for cases where full disk archive name was sent.
           self.dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName'] = archiveFileName.replace(localBackUpRoot + '/' if not localBackUpRoot.endswith('/') else localBackUpRoot, '', 1)
           archiveFileNameOnDisk = os.path.join(localBackUpRoot, archiveFileName) if not archiveFileName.startswith(localBackUpRoot) else archiveFileName
           if os.path.isfile(archiveFileNameOnDisk):
               common_lib.logger("INFO","Backup archive {archive} available on disk, so continuing with restore from disk".format(archive=archiveFileNameOnDisk))
               return FullDiskRestore(self.dictionaryData)
           return FullCloudRestoreBMC(self.dictionaryData) if isBMC else FullCloudRestore(self.dictionaryData)
        elif backupDestination == "BOTH" and not isFull :
           localBackUpRoot = self.dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
           self.dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName'] = archiveFileName.replace(localBackUpRoot + '/' if not localBackUpRoot.endswith('/') else localBackUpRoot, '', 1)
           archiveFileNameOnDisk = os.path.join(localBackUpRoot, archiveFileName) if not archiveFileName.startswith(localBackUpRoot) else archiveFileName
           self.dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName'] = parentBackupArchiveFileName.replace(localBackUpRoot + '/' if not localBackUpRoot.endswith('/') else localBackUpRoot, '', 1)
           parentBackupArchiveFileNameOnDisk =  os.path.join(localBackUpRoot, parentBackupArchiveFileName) if not parentBackupArchiveFileName.startswith(localBackUpRoot) else parentBackupArchiveFileName
           if  os.path.isfile(archiveFileNameOnDisk) and os.path.isfile(parentBackupArchiveFileNameOnDisk) :
               common_lib.logger("INFO","Backup archives available on disk, so continuing with restore from disk")
               return IncrementalDiskRestore(self.dictionaryData)
           return IncrementalCloudRestoreBMC(self.dictionaryData) if isBMC else IncrementalCloudRestore(self.dictionaryData)
        elif backupDestination == "OSS" and isFull :
           cloudStorageURI = self.dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI']
           self.dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName'] = archiveFileName.replace(cloudStorageURI + '/' if not cloudStorageURI.endswith('/') else cloudStorageURI, '', 1)
           return FullCloudOnlyRestoreBMC(self.dictionaryData) if isBMC else FullCloudOnlyRestore(self.dictionaryData)
        elif backupDestination == "OSS" and not isFull :
           cloudStorageURI = self.dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI']
           self.dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName'] = archiveFileName.replace(cloudStorageURI + '/' if not cloudStorageURI.endswith('/') else cloudStorageURI, '', 1)
           self.dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName'] = parentBackupArchiveFileName.replace(cloudStorageURI + '/' if not cloudStorageURI.endswith('/') else cloudStorageURI, '', 1)
           return IncrementalCloudOnlyRestoreBMC(self.dictionaryData) if isBMC else IncrementalCloudOnlyRestore(self.dictionaryData)
        else:
           return None


class Restore:
    """
    An abstact restore class
    """

    __metaclass__  = abc.ABCMeta

    def __init__(self, dictionaryData):
        try:
           self.dictionaryData = dictionaryData
           self.backupId = dictionaryData['SM_OPERATION_INFO']['backupId']
           self.isFull = dictionaryData['SM_OPERATION_INFO']['backup']['isFull']
           self.initiatedBy = dictionaryData['SM_OPERATION_INFO']['backup']['initiatedBy']
           self.hostList = map(lambda x: x.lower(), dictionaryData['SM_SERVICE_INFO']['components']['mysql']['vmInstances'])
           self.archiveFileName = dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName']
           self.backupImageFullName = None
           self.backupDirectory = None
           self.restoreDirectory = constants.DATA_DIR
           self.restoredDirectory = self.restoreDirectory + '-' + str(os.getpid())
           self.restoreLogdir = common_lib.get_logDir()
           if not self.restoreLogdir:
              self.restoreLogdir = self.restoreDirectory
           self.restoredLogdir = self.restoreLogdir + '-' + str(os.getpid())
           self.fileExclusionList = constants.FILE_EXCLUSION_LIST
           self.dirExclusionList = constants.DIR_EXCLUSION_LIST
           self.serviceType = dictionaryData["SM_SERVICE_INFO"]["serviceType"]
           self.serviceName = dictionaryData["SM_SERVICE_INFO"]["serviceName"]
           self.dataDirFlipped = False
           self.MySQLUser = constants.MYSQL_USER
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing in the input JSON.")
           raise KeyError


    @classmethod
    @abc.abstractmethod
    def get_restoreCommand(self):
        return  constants.MEB_LOC + " --user=" + constants.MYSQL_USER

    @abc.abstractmethod
    def doRestore(self):
        return None

    @abc.abstractmethod
    def doPreCheck(self):
        return None

    def get_pathToMySQLInstallScript(self):
        """
        Gets mysqlInstallScript(provisioning) path
        """
        #get the script directory
        tools_path=os.path.realpath(__file__)
        #build path to the mysql-instalation-utils.sh
        mysql_install_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"
        return mysql_install_script


    @clock
    def stopMySQL(self):
        """
        Runs shutdownMysql function with in the mysql-installation-utils.sh
        """
        common_lib.logger("INFO","Executing stopMySQL(), shuting down mysql server.")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()

        cmd = "source {mysql_install_script} && shutdownMysql {mysqluser}".format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser())
        common_lib.logger("INFO","Running command " + cmd)
        cmd_result = executor.execute_cmd(cmd)
        if cmd_result.get_return_code() == 0:
           common_lib.logger("INFO","MySQL server is shutdown.")
           op_return_obj.set_bool_status(True)
           op_return_obj.set_status_msg("MySQL server is shutdown.")
        else:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20903>: MySQL server has failed to shutdown.")

        return op_return_obj

    @clock
    def startMySQL(self, argument=""):
        """
        Runs startMysql function with in the mysql-installation-utils.sh
        """
        common_lib.logger("INFO","Executing startMySQL(), starting mysql server.")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()

        cmd = "source {mysql_install_script} && startMysql {mysqluser} {args} "\
                        .format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser(), args=argument)
        common_lib.logger("INFO","Running command " + cmd)
        cmd_result = executor.execute_cmd(cmd)
        if cmd_result.get_return_code() == 0:
           common_lib.logger("INFO","MySQL server started.")
           op_return_obj.set_bool_status(True)
           op_return_obj.set_status_msg("MySQL server started.")
        else:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20904>: MySQL server has failed to start.")

        return op_return_obj


    @clock
    def checkMySQLStatus(self):
        """
        Confirms if the MySQL is up and accepting connections.
        Invokes getMysqlStatus function in mysql-installation-utils.sh
        Returns execution result an instance of CMDExecutionResultClass() in common lib.
        """
        common_lib.logger("INFO","Verifying connection to MySQL")
        executor = common_lib.Executor()
        op_return_obj = common_lib.OperationReturnObj()

        cmd = "source {mysql_install_script} && getMysqlStatus {mysqluser}"\
                         .format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser())
        common_lib.logger("INFO","Running command " + cmd)
        result = executor.execute_cmd(cmd)
        return  result


    def get_host(self):
        """
        Gets the hostname of the VM
        """
        import socket
        return socket.gethostname()

    @clock
    def doPreRestoreCleanUp(self):
        """
        This function cleansup the datadirectory of MySQL before retoring to the datadirectory
        If any files are directories need to be excluded ftom the cleanup the same should be
        specified in constants.py as below
        # Exclusion list for datadir cleanup
	#File exclusion list
	FILE_EXCLUSION_LIST = [".pem",".pid",".index"]
	#Directory exclusion list
	DIR_EXCLUSION_LIST = ["donotDeleteDir"]
        """
        import shutil
        import re

        host=self.get_host()

        common_lib.logger("INFO","Executing doPreRestoreCleaup(), will cleanup {target} with the exception of files with extension {extension}."\
                                .format(target=self.get_restoreDirectory(), extension=self.get_fileExclusionList()))
        #list of files to be deleted
        files_to_delete=filter(lambda name:not name.endswith(tuple(self.get_fileExclusionList())) and not name.startswith(host),
                                filter(lambda name: os.path.isfile(os.path.join(self.get_restoreDirectory(), name)),
                                       (os.listdir(self.get_restoreDirectory()))))
        #just to make sure binlogs are not deleted
        regex = re.compile(r'\.\d')
        files_to_delete =  [file for file in files_to_delete if not regex.search(file)]

        #list of directories to be deleted
        dirs_to_delete=filter(lambda name: not name.startswith(tuple(self.get_dirExclusionList())),
                              filter(lambda name: not os.path.isfile(os.path.join(self.get_restoreDirectory(), name)),
                                     (os.listdir(self.get_restoreDirectory()))))
        #Delete files
        for file in files_to_delete:
            common_lib.logger("INFO","Removing file " + os.path.join(self.get_restoreDirectory(), file))
            try:
               os.remove(os.path.join(self.get_restoreDirectory(), file))
            except OSError:
               pass

        #Delete directories
        for dir in dirs_to_delete:
            common_lib.logger("INFO","Removing directory " + os.path.join(self.get_restoreDirectory(), dir))
            shutil.rmtree(os.path.join(self.get_restoreDirectory(), dir), ignore_errors=True)
        common_lib.logger("INFO","Finished executing doPreRestoreCleaup().")

    @clock
    def doPreRestoreSetup(self):
        """
        Performs pre restore setup
           1. performs pre-check
           2. shutsdown MySQL database
           3. cleansup the datadir for restore
           4. create a logdir on latency drive.
        Return:
           rtype:
                OperationReturnObj
        """
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        executor = common_lib.Executor()
        #Perform precheck
        return_obj = self.doPreCheck()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(return_obj.get_bool_status())
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           return op_return_obj

        #stop MySQL server for restore
        return_obj = self.stopMySQL()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(return_obj.get_bool_status())
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           return op_return_obj

        #do pre restore cleanup not checking for failure
        #self.doPreRestoreCleanUp()
        #create restore directory
        exe_result = executor.execute_cmd("mkdir -p {restore_dir}".format(restore_dir=self.get_restoredDirectory()))
        if exe_result.get_return_code() != 0:
           common_lib.logger("ERROR","Unable to create restore directory {restoreDir}. Reason: {reason}"
                                          .format(reason=exe_result.get_detail(),restoreDir=self.get_restoredDirectory()))
           op_return_obj.set_bool_status(False)
           op_return_obj.append_status_msg("<MSCS-ERR-20505>: Unable to create restore directory.")
           #op_return_obj.append_status_msg("<MSCS-ERR-20505>: Unable to create restore directory."
           #                               .format(reason=exe_result.get_detail(),restoreDir=self.get_restoredDirectory()))
           return op_return_obj

        #create restore log directory
        if self.get_restoreLogdir() != self.get_restoreDirectory():
            exe_result = executor.execute_cmd("mkdir -p {restore_logdir}".format(restore_logdir=self.get_restoredLogdir()))
            if exe_result.get_return_code() != 0:
               common_lib.logger("ERROR","Unable to create log directory {restoreLogdir}. Reason: {reason}"
                                              .format(reason=exe_result.get_detail(),restoreLogdir=self.get_restoredLogdir()))
               op_return_obj.set_bool_status(False)
               op_return_obj.append_status_msg("<MSCS-ERR-20515>: Unable to create restore log directory.")
               #op_return_obj.append_status_msg("<MSCS-ERR-20515>: Unable to create restore directory {restoreLogdir}. Reason: {reason}"
               #                               .format(reason=exe_result.get_detail(),restoreLogdir=self.get_restoredLogdir()))
               return op_return_obj

        common_lib.logger("INFO","Pre-restore setup completed successfully.")
        op_return_obj.set_status_msg("Pre-restore setup completed successfully.")
        return op_return_obj

    @clock
    def doRestore(self):
        """
	        Gets the restore commands (multiple in case of restore from incremental backup)
        Executes restore commands and verifies the execution, incase of failure the appropriate status is returned
        Return:
            rtype : OperationReturnObj
        """

        #get operation object
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        #perform pre restore setup
        return_obj = self.doPreRestoreSetup()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           return op_return_obj


        #get restore command
        common_lib.logger("INFO","Getting restore command.")
        restoreCommands, restoreCommandsToPrint, backupImageNames = self.get_restoreCommand()

        # perform restore
        common_lib.logger("INFO","Starting restore from backup {backupImageFullName}."\
                                .format(backupImageFullName = self.get_backupImageFullName() ))
        #get an executor
        executor = common_lib.Executor()
        #execute restore command

        for backupType in sorted(restoreCommands.iterkeys()):
            common_lib.logger("INFO","Executing restore command: {restoreCommand}"\
                                        .format(restoreCommand=restoreCommandsToPrint[backupType]))
            exe_result = executor.execute_cmd(commandline=restoreCommands[backupType], command_for_print=restoreCommandsToPrint[backupType])
            common_lib.logger("INFO","===============Output from mysqlbackup (restore) ================")
            std_out = exe_result.get_std_out()
            std_err = exe_result.get_std_err()
            print exe_result.get_std_out()
            print exe_result.get_std_err()

            #check for 'mysqlbackup completed OK!' to conform the success
            if (std_out + std_err).find("mysqlbackup completed OK!") == -1 and exe_result.get_return_code() == 0:
               #cleanup the temp restored directory
               #Delete directories
               common_lib.logger("INFO","Removing temp restore directory " + self.get_restoredDirectory())
               shutil.rmtree(self.get_restoredDirectory(), ignore_errors=True)
               shutil.rmtree(self.get_restoredLogdir(), ignore_errors=True)
               common_lib.logger("INFO","Removed temp restore directory " + self.get_restoredDirectory())

               common_lib.logger("ERROR","Could not get 'mysqlbackup completed OK!' confirmation for restore from {backupImageFullName}."\
                                  .format(backupImageFullName = self.get_backupImageFullName() ))
               op_return_obj.set_bool_status(False)
               op_return_obj.set_status_msg("<MSCS-ERR-20501>: Restoring MySQL database failed.")
               return op_return_obj

            #if restore fails exit with error
            if exe_result.get_return_code() != 0:
               #cleanup the temp restored directory
               #Delete directories
               common_lib.logger("INFO","Removing temp restore directory " + self.get_restoredDirectory())
               shutil.rmtree(self.get_restoredDirectory(), ignore_errors=True)
               shutil.rmtree(self.get_restoredLogdir(), ignore_errors=True)
               common_lib.logger("INFO","Removed temp directory " + self.get_restoredDirectory())

               common_lib.logger("ERROR","Restoring from {backupType} backup {backupImageFullName} on {host} failed, exiting restore operation, return_code:{return_code}"\
                                .format(backupType=backupType, host=self.get_host(), backupImageFullName = backupImageNames[backupType], return_code=exe_result.get_return_code()))
               op_return_obj.set_bool_status(False)
               op_return_obj.set_status_msg("<MSCS-ERR-20501>: Restoring MySQL database failed.")
               return op_return_obj

            common_lib.logger("INFO","Restore from backup {backupImageFullName} on {host} succeeded."\
                                .format(backupImageFullName=backupImageNames[backupType] , host=self.get_host() ))


        #so far so good start post restore setup
        return_obj = self.doPostRestoreSetup()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           return op_return_obj

        common_lib.logger("INFO","PostRestoreSetup completed successfully.")

        common_lib.logger("INFO","Restore from backup {backupImageFullName} on {host} succeeded."\
                                .format(backupImageFullName = self.get_backupImageFullName(), host=self.get_host() ))
        op_return_obj.set_status_msg("<MSCS-INFO-20500>: Restore from backup succeeded. ")
        return op_return_obj

    @clock
    def doPostRestoreSetup(self):
        """
        Performs post restore operation
           1. Rename the restored directory to data dir
           2. Start MySQL
           3. Perform tests on MySQL
           4. Cleanup the old data dir
        Return:
           rtype: OperationReturnObj
        """
        import time

        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)

        #copy binary logs
        #if self.get_restoreLogdir() != self.get_restoreDirectory():
           #common_lib.copyBinLogToRestoredDir(self.get_restoreLogdir(),self.get_restoredLogdir())
        #else:
           #common_lib.copyBinLogToRestoredDir(self.get_restoreDirectory(),self.get_restoredDirectory())
        #delete binary logs from restored directory
        common_lib.delBinLogFromRestoredDir(self.get_restoredDirectory())

        #Rename restored directory to data directory
        common_lib.logger("INFO", "Renaming restore directory to data directory.")
        try:
           common_lib.logger("INFO","Renaming  {datadir} to {datadirnew} ".format(datadir = self.get_restoreDirectory(), datadirnew=self.get_restoredDirectory() + "-tmp"))
           shutil.move(self.get_restoreDirectory(),self.get_restoredDirectory() + "-tmp")
           common_lib.logger("INFO","Renaming  {datadir} to {datadirnew} ".format(datadir = self.get_restoredDirectory(), datadirnew=self.get_restoreDirectory()))
           shutil.move(self.get_restoredDirectory(),self.get_restoreDirectory())
        except OSError as e:
           common_lib.logger("ERROR","Unable to rename data directory.")
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20506>: Unable to rename the data directory.")
           return op_return_obj

        if self.get_restoreLogdir() != self.get_restoreDirectory():
           #Rename restored log directory to log directory
           common_lib.logger("INFO", "Renaming restored log directory to log directory.")
           try:
              common_lib.logger("INFO","Renaming  {logdir} to {logdirnew} ".format(logdir = self.get_restoreLogdir(), logdirnew=self.get_restoredLogdir() + "-tmp"))
              shutil.move(self.get_restoreLogdir(),self.get_restoredLogdir() + "-tmp")
              common_lib.logger("INFO","Renaming  {logdir} to {logdirnew} ".format(logdir = self.get_restoredLogdir(), logdirnew=self.get_restoreLogdir()))
              shutil.move(self.get_restoredLogdir(),self.get_restoreLogdir())
           except OSError as e:
              common_lib.logger("ERROR","Unable to rename log directory.")
              op_return_obj.set_bool_status(False)
              op_return_obj.set_status_msg("<MSCS-ERR-20516>: Unable to rename log directory.")
              return op_return_obj

        self.set_dataDirFlipped()
        #starting mysql
        common_lib.logger("INFO", "Trying to start MySQL.")
        return_obj = self.startMySQL("--skip-networking")
        if not return_obj.get_bool_status() :
	   op_return_obj.set_bool_status(return_obj.get_bool_status())
           op_return_obj.set_status_msg(return_obj.get_status_msg())
           #return op_return_obj
        else:
           common_lib.logger("INFO", "MySQL server started.")


        #performing MySQL test
        common_lib.logger("INFO", "Checking MySQL status.")
        check_result = self.checkMySQLStatus()
        for iter in range(1,6):
            if check_result.get_return_code() == 0:
               common_lib.logger("INFO","MySQL server accepting connection.")
               break
            common_lib.logger("INFO", "MySQL is not ready yet, will check again in %i seconds." % (iter * 10))
            time.sleep(iter * 10 )
            check_result = self.checkMySQLStatus()

        #No pulse from MySQL  so assuming problem
        #will try to put the currend data directory back and
        #start mysql

        if check_result.get_return_code() != 0:
           common_lib.logger("INFO", "MySQL status check is negative, problem with MySQL server. Reverting the restore.")
           #shutdown mysql
           common_lib.logger("INFO", "Stopping MySQL server for reverting the data directory.")
           return_obj = self.stopMySQL()
           if not return_obj.get_bool_status():
              common_lib.logger("ERROR", "Unable to stop MySQL server for reverting the data directory.")
              op_return_obj.set_bool_status(return_obj.get_bool_status())
              op_return_obj.set_status_msg(return_obj.get_status_msg())
              return op_return_obj

           #Flip the directories newly restored directory -> datadir-pid
           #                           current dire ctory to datadir
           #This steps will bring the current data (before restore) to data dir

           try:
               common_lib.logger("INFO", "Renaming {dir} to {dirnew} .".format(dir=self.get_restoreDirectory(), dirnew=self.get_restoredDirectory()))
               shutil.move(self.get_restoreDirectory(),self.get_restoredDirectory())
           except OSError as e:
               common_lib.logger("ERROR","Unable to rename the newly restored data directory. The current data (before restore is in {dir}".format(dir=self.get_restoredDirectory() + "-tmp"))
               op_return_obj.set_bool_status(False)
               op_return_obj.set_status_msg("<MSCS-ERR-20506>: Unable to rename the data directory.")
               return op_return_obj

           try:
               common_lib.logger("INFO", "Renaming {dir} to {dirnew} .".format(dir=self.get_restoredDirectory()  + "-tmp", dirnew=self.get_restoreDirectory()))
               shutil.move(self.get_restoredDirectory() + "-tmp", self.get_restoreDirectory())
           except OSError as e:
               common_lib.logger("ERROR","Unable to rename the temp directory to current data directory. The current data (before restore is in {dir}".format(dir=self.get_restoredDirectory() + "-tmp"))
               op_return_obj.set_bool_status(False)
               op_return_obj.set_status_msg("<MSCS-ERR-20506>: Unable to rename the data directory.")
               return op_return_obj

           #Flip the directories newly restored log directory -> log-pid
           #                           current directory to logdir
           #This steps will bring the current log directory (before restore) to log dir

           if self.get_restoreLogdir() != self.get_restoreDirectory():
              try:
                  common_lib.logger("INFO", "Renaming {dir} to {dirnew} .".format(dir=self.get_restoreLogdir(), dirnew=self.get_restoredLogdir()))
                  shutil.move(self.get_restoreLogdir(),self.get_restoredLogdir())
              except OSError as e:
                  common_lib.logger("ERROR","Unable to rename the newly restored log directory. The current log directory (before restore is in {dir}".format(dir=self.get_restoredLogdir() + "-tmp"))
                  op_return_obj.set_bool_status(False)
                  op_return_obj.set_status_msg("<MSCS-ERR-20516>: Unable to rename the log directory.")
                  return op_return_obj

              try:
                  common_lib.logger("INFO", "Renaming {dir} to {dirnew} .".format(dir=self.get_restoredLogdir()  + "-tmp", dirnew=self.get_restoreLogdir()))
                  shutil.move(self.get_restoredLogdir() + "-tmp", self.get_restoreLogdir())
              except OSError as e:
                  common_lib.logger("ERROR","Unable to rename the temp directory to current log directory. The current log (before restore is in {dir}".format(dir=self.get_restoredLogdir() + "-tmp"))
                  op_return_obj.set_bool_status(False)
                  op_return_obj.set_status_msg("<MSCS-ERR-20516>: Unable to rename log directory.")
                  return op_return_obj

           #try to start again
           #Suceeded in putting old directory back

           common_lib.logger("INFO", "Current data directory (data before restore operation) restored.")
           common_lib.logger("INFO", "Trying to start MySQL after restoring the current data directory.")
           return_obj = self.startMySQL()
           if not return_obj.get_bool_status() :
              common_lib.logger("ERROR", "Attempt to start MySQL after restoring the current data directory failed.")
              op_return_obj.set_bool_status(return_obj.get_bool_status())
              op_return_obj.set_status_msg(return_obj.get_status_msg())
              return op_return_obj

           # The current data directory is salvaged
           # Remoing the temp directories created
           common_lib.logger("INFO","Removing the temp restore directory " + self.get_restoredDirectory())
           shutil.rmtree(self.get_restoredDirectory(), ignore_errors=True)
           shutil.rmtree(self.get_restoredLogdir(), ignore_errors=True)
           common_lib.logger("INFO","Removed the temp restore directory " + self.get_restoredDirectory() )
           # put the current data backup but the restore operation has failed.
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg("<MSCS-ERR-20511>: Restoring MySQL from backup failed. The data directory is reverted to the state before restore.")
           return op_return_obj


        #Backup will intiated aftre this so the tmp directory needs to be preserved thill the backup succeeds
        #common_lib.logger("INFO","Removing the temp data directory " + self.get_restoredDirectory() + '-tmp')
        #shutil.rmtree(self.get_restoredDirectory() + '-tmp', ignore_errors=True)
        #common_lib.logger("INFO","Removed the temp data directory " + self.get_restoredDirectory() + '-tmp')
        common_lib.logger("INFO","Restore operation completed successfully.")
        return op_return_obj

    def checkRestoreDir(self):
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        executor = common_lib.Executor()

        if not os.path.isdir(self.get_restoreDirectory()):
           common_lib.logger("INFO","Data directory {datadir} does not exist, creating one.".format(datadir=self.get_restoreDirectory()))
           if not os.path.isfile(self.get_restoreDirectory()):
              exe_result = executor.execute_cmd("mkdir -p {dir}".format(dir=self.get_restoreDirectory()))
              if exe_result.get_return_code() != 0:
                 common_lib.logger("ERROR","Unable to create directory {dir}. Reason: {reason}"
                                          .format(reason=exe_result.get_detail(),dir=self.get_restoreDirectory()))
                 op_return_obj.set_bool_status(False)
                 op_return_obj.append_status_msg("<MSCS-ERR-20509>: Unable to create data directory.")
                 #op_return_obj.append_status_msg("<MSCS-ERR-20509>: Unable to create directory {dir}. Reason: {reason}"
                 #                         .format(reason=exe_result.get_detail(),dir=self.get_restoreDirectory()))
                 return op_return_obj
           else:
              common_lib.logger("ERROR","File with same name as data directory exists, cannot continue with the restore.")
              op_return_obj.set_bool_status(False)
              op_return_obj.set_status_msg("<MSCS-ERR-20508>: File with same name as data directory exists, cannot continue with the restore.")
              return op_return_obj

        return op_return_obj

    def set_dataDirFlipped(self, status=True):
        self.dataDirFlipped = status

    def isDataDirFlipped(self):
        return self.dataDirFlipped

    def get_dictionaryData(self):
        return self.dictionaryData

    def get_backupId(self):
        return self.backupId

    def get_localStorageRoot(self):
        return self.localStorageRoot

    def isFull(self):
        return self.isFull

    def get_initiatedBy(self):
        return self.initiatedBy

    def get_hostList(self):
        return self.hostList

    def get_archiveFileName(self):
        return self.archiveFileName

    def get_backupImageFullName(self):
        return self.backupImageFullName

    def get_backupDirectory(self):
        return self.backupDirectory

    def get_restoreDirectory(self):
        return self.restoreDirectory

    def get_restoredDirectory(self):
        return self.restoredDirectory

    def get_restoreLogdir(self):
        return self.restoreLogdir

    def get_restoredLogdir(self):
        return self.restoredLogdir

    def get_fileExclusionList(self):
        return self.fileExclusionList

    def get_dirExclusionList(self):
        return self.dirExclusionList

    def get_MySQLUser(self):
        return self.MySQLUser

    def get_serviceType(self):
        return self.serviceType

    def get_serviceName(self):
        return self.serviceName

    def set_restoredDirectory(self,restoredDir):
        self.restoredDirectory=restoredDir

    def set_restoredLogdir(self,restoredLogDir):
        self.restoredLogdir = restoredLogDir


class DiskRestore(Restore):
    """
    Abstract class implementing the Restore class
    """
    def __init__(self, dictionaryData):
        Restore.__init__(self, dictionaryData)
        self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
        self.backupImageFullName = os.path.join(self.localStorageRoot, self.get_archiveFileName())
        self.backupDirectory = os.path.dirname(self.backupImageFullName)

    @clock
    def doPreCheck(self):
        """
        Performs pre-check for restores from disk backup image
        """
        import socket
        common_lib.logger("INFO","Performing pre-check for restore, if archive name and restore directory specified.")
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        op_return_obj.set_status_msg("Restore pre-check successfull.")
        executor = common_lib.Executor()

        if not self.get_backupImageFullName() or not self.get_restoreDirectory():
          common_lib.logger("ERROR","Unable to perform restore, archive name or restore directory not specified.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type("Fatal")
          op_return_obj.set_status_msg("<MSCS-ERR-20503>: Unable to perform restore, archive name or restore directory not specified.")
          return op_return_obj

        common_lib.logger("INFO","Performing pre-check for restore, if data directory has enough space.")
        return_obj = self.checkRestoreDir()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20508>: File with same name as data directory exists, cannot continue with the restore.")
           return op_return_obj

        space_needed_for_data_on_backupvol = 0
        space_needed_for_log_on_backupvol = 0
        free_space = common_lib.getdiskFreeSpace(self.get_localStorageRoot())

        dataDirSize = common_lib.getDirSize(self.get_restoreDirectory(),operation="restore")
        freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreDirectory(),"data")
        if dataDirSize * 1.2 >= freeSpaceOnDataVol:
           common_lib.logger("WARN","Not enough space on data volume to create a new data dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=dataDirSize * 2.2))
           if dataDirSize * 1.2 <  free_space: #check if backup volume has enough space
              common_lib.logger("INFO","Using backup volume to create temp restore directory.")
              self.set_restoredDirectory(os.path.join (self.get_localStorageRoot(), "mysql" + '-' + str(os.getpid()) ))
              space_needed_for_data_on_backupvol = dataDirSize * 1.2
           else:
              common_lib.logger("ERROR","Not enough space on data volume or backup volume to create a temp data directory for restore.")
              op_return_obj.set_bool_status(False)
              op_return_obj.set_error_type("Fatal")
              op_return_obj.set_status_msg("<MSCS-ERR-20504>: Not enough space on data or backup volume to create a new data directory for restore.")
              return op_return_obj

        #perform logdir size check
        if self.get_restoreLogdir() != self.get_restoreDirectory():
           logDirSize = common_lib.get_logDirSize()
           freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreLogdir(),"log")
           if logDirSize * 1.2 >= freeSpaceOnDataVol:
              common_lib.logger("WARN","Not enough space on log volume to create a new log dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=logDirSize * 2.2))
              if logDirSize * 1.2 < free_space - space_needed_for_data_on_backupvol :
                 common_lib.logger("INFO","Using backup volume to create temp restore log directory.")
                 self.set_restoredLogdir(os.path.join (self.get_localStorageRoot(), "log"  + '-' + str(os.getpid()) ))
                 space_needed_for_log_on_backupvol = logDirSize * 1.2
              else:              
                 common_lib.logger("ERROR","Not enough space on log volume or backup volume to create a temp log directory for restore.")
                 op_return_obj.set_bool_status(False)
                 op_return_obj.set_error_type("Fatal")
                 op_return_obj.set_status_msg("<MSCS-ERR-20514>: Not enough space on log or backup volume to create a new log directory for restore.")
                 return op_return_obj

        #perform backup dir size check
        excludes = [ 'ib_logfile*', socket.gethostname() + '*', 'ibtmp*', 'undo*' ]
        data_dir_size = common_lib.getDirSize(constants.DATA_DIR, excludes)
        if not free_space - space_needed_for_data_on_backupvol - space_needed_for_log_on_backupvol >= data_dir_size * 0.6 :
           common_lib.logger("ERROR","Not enough space on backup volume to create post restore backup. Please increase the space on the backup volume and retry.")
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20518>: Not enough space on backup volume to create post restore backup. Please increase the space on the backup volume and retry.")
           return op_return_obj

        return op_return_obj


class FullDiskRestore(DiskRestore):
    """
    A concrete class of DiskRestore class, implements the get_restoreCommand method for full backup restore from disk image
    """
    def __init__(self, dictionaryData):
        DiskRestore.__init__(self, dictionaryData)

    def get_restoreCommand(self):
        restoreCommand = ( Restore.get_restoreCommand() + " "
                                " --backup-dir=" + self.get_backupDirectory() + " "
                                " --backup-image=" + self.get_backupImageFullName() + " "
                                " --datadir=" + self.get_restoredDirectory() + " "
                                " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                " --uncompress --force copy-back-and-apply-log " )

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommand
        restoreCommandsForPrint["full"] = restoreCommand
        backupImagesName["full"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName



class IncrementalDiskRestore(DiskRestore):
    """
    A concrete class of DiskRestore class, implements the get_restoreCommand method for incremental backup restore from disk image
    """

    def __init__(self, dictionaryData):
        DiskRestore.__init__(self, dictionaryData)
        self.parentArchiveFileName=dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
        self.parentBackupImageFullName= os.path.join(self.localStorageRoot, self.parentArchiveFileName)
        self.backupDirectory = os.path.dirname(self.backupImageFullName)

    def get_parentBackupImageFullName(self):
        return self.parentBackupImageFullName

    def get_restoreCommand(self):

        restoreCommandFull = ( Restore.get_restoreCommand() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --backup-image=" + self.get_parentBackupImageFullName() + " "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --uncompress --force copy-back-and-apply-log " )


        restoreCommandIncremental = ( Restore.get_restoreCommand() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --backup-image=" + self.get_backupImageFullName() + " "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --incremental copy-back-and-apply-log " )

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommandFull
        restoreCommandsForPrint["full"] = restoreCommandFull
        backupImagesName["full"] = self.get_parentBackupImageFullName()

        restoreCommands["incremental"] = restoreCommandIncremental
        restoreCommandsForPrint["incremental"] = restoreCommandIncremental
        backupImagesName["incremental"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName


class CloudRestore(Restore):
    """
     Abstact class implements Restore class
    """

    def __init__(self, dictionaryData):
        try:
           Restore.__init__(self, dictionaryData)
           self.cloudStorageURI = dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI']
           self.cloudStorageUser = dictionaryData['SM_OPERATION_INFO']['cloudStorageUser']
           self.cloudStoragePassword = dictionaryData['SM_OPERATION_INFO']['cloudStoragePassword']
           self.cloudObject = dictionaryData['SM_OPERATION_INFO']['backup']['archiveFileName']
           self.cloudObject = self.cloudObject[1:] if self.cloudObject.startswith('/') else self.cloudObject
           self.backupImageFullName = urlparse.urljoin(self.cloudStorageURI if self.cloudStorageURI.endswith('/') else self.cloudStorageURI + '/', self.cloudObject)
           self.cloudStorageServiceInstanceContainer = common_lib.get_Container_from_Storage_URL(self.cloudStorageURI)
           self.cloudStorageServiceInstance = self.cloudStorageServiceInstanceContainer.split('/')[0]
           self.cloudStorageContainer = self.cloudStorageServiceInstanceContainer.split('/')[1]
           self.uriTokens = urlparse.urlparse(self.cloudStorageURI)
           self.mebCloudStorageURI = self.uriTokens.scheme + "://" + self.uriTokens.netloc
           self.mebCloudStorageUser = self.cloudStorageServiceInstance + ":" + dictionaryData['SM_OPERATION_INFO']['cloudStorageUser']
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError


    @clock
    def doPreCheck(self):
        """
        Performs cloud restore specific prechecks
        1. Verifies the image in the cloud
        All other pre-checks for restore from cloud image should be part of this function
        Return:
          rtype : OperationReturnObj
        """
        import socket
        common_lib.logger("INFO","Performing pre-check for restore, if the cloud backup image  {image} is avialable in cloud storage.".format( image=self.get_cloudObjectURI() ))
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        op_return_obj.set_status_msg("Restore pre-check completed successfull.")

        credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()
        cloud_object_check_result = common_lib.verifyObjectOnCloud(self.get_cloudObjectURI(), credential)
        #cloud_object_check_result = common_lib.check_backup_in_cloud(self.get_cloudObjectURI(), self.get_cloudStorageUser(),
        #                                                             self.get_cloudStoragePassword())
        if not cloud_object_check_result.get_bool_status():
           common_lib.logger("ERROR","Backup image {URL} not found in cloud storage.".format(URL=self.get_cloudObjectURI() ))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(cloud_object_check_result.get_error_type())
           op_return_obj.append_status_msg(cloud_object_check_result.get_status_msg())
           return op_return_obj

        common_lib.logger("INFO","Performing pre-check for restore, if data directory has enough space.")
        return_obj = self.checkRestoreDir()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg("<MSCS-ERR-20508>: File with same name as data directory exists, cannot continue with the restore.")
           return op_return_obj

        space_needed_for_data_on_backupvol = 0
        space_needed_for_log_on_backupvol = 0
        free_space = common_lib.getdiskFreeSpace(self.get_localStorageRoot())

        dataDirSize = common_lib.getDirSize(self.get_restoreDirectory(),operation="restore")
        freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreDirectory(),"data")
        if dataDirSize * 1.2 >= freeSpaceOnDataVol:
           common_lib.logger("WARN","Not enough space on data volume to create a new data dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=dataDirSize * 2.2))
           if dataDirSize * 1.2 <  free_space: #check if backup volume has enough space
              common_lib.logger("INFO","Using backup volume to create temp restore directory.")
              self.set_restoredDirectory(os.path.join (self.get_localStorageRoot(), "mysql" + '-' + str(os.getpid()) ))
              space_needed_for_data_on_backupvol = dataDirSize * 1.2
           else:          
              common_lib.logger("ERROR","Not enough space on data volume or backup volume to create a temp data directory for restore.") 
              op_return_obj.set_bool_status(False)
              op_return_obj.set_error_type("Fatal")
              op_return_obj.set_status_msg("<MSCS-ERR-20504>: Not enough space on data or backup volume to create a new data directory for restore.")
              return op_return_obj

        #perform logdir size check
        if self.get_restoreLogdir() != self.get_restoreDirectory():
           logDirSize = common_lib.get_logDirSize()
           freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreLogdir(),"log")
           if logDirSize * 1.2 >= freeSpaceOnDataVol:
              common_lib.logger("WARN","Not enough space on log volume to create a new log dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=logDirSize * 2.2))
              if logDirSize * 1.2 < free_space - space_needed_for_data_on_backupvol :
                 common_lib.logger("INFO","Using backup volume to create temp restore log directory.")
                 self.set_restoredLogdir(os.path.join (self.get_localStorageRoot(), "log"  + '-' + str(os.getpid()) ))
                 space_needed_for_log_on_backupvol = logDirSize * 1.2
              else:              
                 common_lib.logger("ERROR","Not enough space on log volume or backup volume to create a temp log directory for restore.")
                 op_return_obj.set_bool_status(False)
                 op_return_obj.set_error_type("Fatal")
                 op_return_obj.set_status_msg("<MSCS-ERR-20514>: Not enough space on log or backup volume to create a new log directory for restore.")
                 return op_return_obj

        #perform backup dir size check
        excludes = [ 'ib_logfile*', socket.gethostname() + '*', 'ibtmp*', 'undo*' ]
        data_dir_size = common_lib.getDirSize(constants.DATA_DIR, excludes)
        if not free_space - space_needed_for_data_on_backupvol - space_needed_for_log_on_backupvol >= data_dir_size * 0.6 :
           common_lib.logger("ERROR","Not enough space on backup volume to create post restore backup. Please increase the space on the backup volume and retry.")
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20518>: Not enough space on backup volume to create post restore backup. Please increase the space on the backup volume and retry.")
           return op_return_obj
 
        common_lib.logger("INFO","Finished checking backup image {URL} in cloud storage.".format(URL=self.get_cloudObjectURI() ))

        return op_return_obj


    def get_cloudObjectURI(self):
        return urlparse.urljoin(self.get_cloudStorageURI(), self.get_cloudObject())

    def get_cloudObject(self):
        return self.cloudObject

    def get_cloudStorageURI(self):
        return self.cloudStorageURI + '/'

    def get_cloudStorageUser(self):
        return self.cloudStorageUser

    def get_cloudStoragePassword(self):
        return self.cloudStoragePassword

    def get_cloudStorageServiceInstanceContainer(self):
        return self.cloudStorageServiceInstanceContainer

    def get_cloudStorageServiceInstance(self):
        return self.cloudStorageServiceInstance

    def get_cloudStorageContainer(self):
        return self.cloudStorageContainer

    def get_uriTokens(self):
        return self.uriTokens

    def get_mebCloudStorageURI(self):
        return self.mebCloudStorageURI

    def get_mebCloudStorageUser(self):
        return self.mebCloudStorageUser


class FullCloudRestore(CloudRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from cloud backup
    """
    def __init__(self, dictionaryData):
        CloudRestore.__init__(self, dictionaryData)
        self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
        self.backupDirectory = os.path.dirname(os.path.join(self.localStorageRoot, self.cloudObject))

    def get_restoreCommand(self):
        restoreCommand = ( Restore.get_restoreCommand() + " "
                         " --cloud-service=openstack "
                         " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                         " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                         " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                         " --cloud-container=" + self.get_cloudStorageContainer() + " "
                         " --cloud-object=" + self.get_cloudObject() + " "
                         " --backup-dir=" + self.get_backupDirectory() + " "
			 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                         #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                         " --datadir=" + self.get_restoredDirectory() + " "
                         " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                         " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        backupImageName = self.get_backupImageFullName()

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommand
        restoreCommandsForPrint["full"] = restoreCommandForPrint
        backupImagesName["full"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName

class IncrementalCloudRestore(CloudRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from cloud backup
       ToDo: put the correct implementation for get_restoreCommand once finalized
    """

    def __init__(self, dictionaryData):
        try:
           CloudRestore.__init__(self, dictionaryData)
           self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
           self.backupDirectory = os.path.dirname(os.path.join(self.localStorageRoot, self.cloudObject))
           self.parentCloudObject = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
           self.parentBackupImageFullName = urlparse.urljoin(self.cloudStorageURI if self.cloudStorageURI.endswith('/') else self.cloudStorageURI + '/', self.parentCloudObject)
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError

    def get_parentBackupImageFullName(self):
        return self.parentBackupImageFullName

    def get_parentCloudObject(self):
        return self.parentCloudObject

    def get_restoreCommand(self):

        restoreCommandFull = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_parentCloudObject() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
			         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandFullForPrint = restoreCommandFull.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        restoreCommandIncremental = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudObject() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
			         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --incremental copy-back-and-apply-log " )

        restoreCommandIncrementalForPrint = restoreCommandIncremental.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommandFull
        restoreCommandsForPrint["full"] = restoreCommandFullForPrint
        backupImagesName["full"] = self.get_parentBackupImageFullName()

        restoreCommands["incremental"] = restoreCommandIncremental
        restoreCommandsForPrint["incremental"] = restoreCommandIncrementalForPrint
        backupImagesName["incremental"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName

class CloudOnlyRestore(CloudRestore):
    """
     Abstact class implements Restore class
    """

    def __init__(self, dictionaryData):
        try:
           CloudRestore.__init__(self, dictionaryData)
           self.localStorageRoot = os.path.join(os.path.dirname(constants.DATA_DIR), "backupmetadata")
           self.backupDirectory = os.path.dirname(os.path.join(self.localStorageRoot, self.cloudObject))
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError

    @clock
    def doPreCheck(self):
        """
        Performs cloud restore specific prechecks
        1. Verifies the image in the cloud
        All other pre-checks for restore from cloud image should be part of this function
        Return:
          rtype : OperationReturnObj
        """
        import socket
        common_lib.logger("INFO","Performing pre-check for restore, if the cloud backup image  {image} is avialable in cloud storage.".format( image=self.get_cloudObjectURI() ))
        op_return_obj = common_lib.OperationReturnObj()
        op_return_obj.set_bool_status(True)
        op_return_obj.set_status_msg("Restore pre-check completed successfull.")

        credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()
        cloud_object_check_result = common_lib.verifyObjectOnCloud(self.get_cloudObjectURI(), credential)
        #cloud_object_check_result = common_lib.check_backup_in_cloud(self.get_cloudObjectURI(), self.get_cloudStorageUser(),
        #                                                             self.get_cloudStoragePassword())
        if not cloud_object_check_result.get_bool_status():
           common_lib.logger("ERROR","Backup image {URL} not found in cloud storage.".format(URL=self.get_cloudObjectURI() ))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(cloud_object_check_result.get_error_type())
           op_return_obj.append_status_msg(cloud_object_check_result.get_status_msg())
           return op_return_obj

        common_lib.logger("INFO","Performing pre-check for restore, if data directory has enough space.")
        return_obj = self.checkRestoreDir()
        if not return_obj.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(return_obj.get_error_type())
           op_return_obj.set_status_msg("<MSCS-ERR-20508>: File with same name as data directory exists, cannot continue with the restore.")
           return op_return_obj

        space_needed_for_data_on_backupvol = 0
        space_needed_for_log_on_backupvol = 0


        dataDirSize = common_lib.getDirSize(self.get_restoreDirectory(),operation="restore")
        freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreDirectory(),"data")
        if dataDirSize * 1.2 >= freeSpaceOnDataVol:
           common_lib.logger("WARN","Not enough space on data volume to create a new data dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=dataDirSize * 2.2))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20504>: Not enough space on data volume to create a new data directory for restore.")
           return op_return_obj

        #perform logdir size check
        if self.get_restoreLogdir() != self.get_restoreDirectory():
           logDirSize = common_lib.get_logDirSize()
           freeSpaceOnDataVol = common_lib.getdiskFreeSpace(self.get_restoreLogdir(),"log")
           if logDirSize * 1.2 >= freeSpaceOnDataVol:
              common_lib.logger("WARN","Not enough space on log volume to create a new log dir for restore. Available free space is {freespace} required is {rspace}".format(freespace=freeSpaceOnDataVol,rspace=logDirSize * 2.2))
              op_return_obj.set_bool_status(False)
              op_return_obj.set_error_type("Fatal")
              op_return_obj.set_status_msg("<MSCS-ERR-20514>: Not enough space on log volume to create a new log directory for restore.")
              return op_return_obj

        common_lib.logger("INFO","Finished checking backup image {URL} in cloud storage.".format(URL=self.get_cloudObjectURI() ))

        return op_return_obj

class FullCloudOnlyRestore(CloudOnlyRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from cloud backup
    """
    def __init__(self, dictionaryData):
        CloudOnlyRestore.__init__(self, dictionaryData)

    def get_restoreCommand(self):
        restoreCommand = ( Restore.get_restoreCommand() + " "
                         " --cloud-service=openstack "
                         " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                         " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                         " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                         " --cloud-container=" + self.get_cloudStorageContainer() + " "
                         " --cloud-object=" + self.get_cloudObject() + " "
                         " --backup-dir=" + self.get_backupDirectory() + " "
                         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                         #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                         " --datadir=" + self.get_restoredDirectory() + " "
                         " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                         " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        backupImageName = self.get_backupImageFullName()

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommand
        restoreCommandsForPrint["full"] = restoreCommandForPrint
        backupImagesName["full"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName


class IncrementalCloudOnlyRestore(CloudOnlyRestore):
    """
       A concrete specialized class of CloudOnlyRestore class
       implements get_restoreCommand() method for full restore from cloud backup
       ToDo: put the correct implementation for get_restoreCommand once finalized
    """

    def __init__(self, dictionaryData):
        try:
           CloudOnlyRestore.__init__(self, dictionaryData)
           self.parentCloudObject = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
           self.parentCloudObject = self.parentCloudObject[1:] if self.parentCloudObject.startswith('/') else self.parentCloudObject
           self.parentBackupImageFullName = urlparse.urljoin(self.cloudStorageURI if self.cloudStorageURI.endswith('/') else self.cloudStorageURI + '/', self.parentCloudObject)
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError

    def get_parentBackupImageFullName(self):
        return self.parentBackupImageFullName

    def get_parentCloudObject(self):
        return self.parentCloudObject

    def get_restoreCommand(self):

        restoreCommandFull = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_parentCloudObject() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandFullForPrint = restoreCommandFull.replace(self.get_cloudStoragePassword(), "XXXXXXXX")


        restoreCommandIncremental = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudObject() + " "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --incremental copy-back-and-apply-log " )

        restoreCommandIncrementalForPrint = restoreCommandIncremental.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommandFull
        restoreCommandsForPrint["full"] = restoreCommandFullForPrint
        backupImagesName["full"] = self.get_parentBackupImageFullName()

        restoreCommands["incremental"] = restoreCommandIncremental
        restoreCommandsForPrint["incremental"] = restoreCommandIncrementalForPrint
        backupImagesName["incremental"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName

class FullCloudRestoreBMC(CloudRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from BMC cloud backup
    """
    def __init__(self, dictionaryData):
        CloudRestore.__init__(self, dictionaryData)
        self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
        self.backupDirectory = os.path.dirname(os.path.join(self.localStorageRoot, self.cloudObject))

    def get_restoreCommand(self):
        restoreCommand = ( Restore.get_restoreCommand() + " "
                         " --cloud-service=openstack "
                         " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                         " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                         " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                         " --cloud-container=" + self.get_cloudStorageContainer() + " "
                         " --cloud-object=" + self.get_cloudObject() + " "
                         " --cloud-chunked-transfer=false "
                         " --cloud-buffer-size=64 "
                         " --limit-memory=512 "
                         " --backup-dir=" + self.get_backupDirectory() + " "
			 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                         #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                         " --datadir=" + self.get_restoredDirectory() + " "
                         " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                         " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        backupImageName = self.get_backupImageFullName()

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommand
        restoreCommandsForPrint["full"] = restoreCommandForPrint
        backupImagesName["full"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName


class IncrementalCloudRestoreBMC(CloudRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from BMC cloud backup
       ToDo: put the correct implementation for get_restoreCommand once finalized
    """

    def __init__(self, dictionaryData):
        try:
           CloudRestore.__init__(self, dictionaryData)
           self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
           self.backupDirectory = os.path.dirname(os.path.join(self.localStorageRoot, self.cloudObject))
           self.parentCloudObject = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
           self.parentBackupImageFullName = urlparse.urljoin(self.cloudStorageURI if self.cloudStorageURI.endswith('/') else self.cloudStorageURI + '/', self.parentCloudObject)
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError

    def get_parentBackupImageFullName(self):
        return self.parentBackupImageFullName

    def get_parentCloudObject(self):
        return self.parentCloudObject

    def get_restoreCommand(self):

        restoreCommandFull = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_parentCloudObject() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
			         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandFullForPrint = restoreCommandFull.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        restoreCommandIncremental = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudObject() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
			         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --incremental copy-back-and-apply-log " )

        restoreCommandIncrementalForPrint = restoreCommandIncremental.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommandFull
        restoreCommandsForPrint["full"] = restoreCommandFullForPrint
        backupImagesName["full"] = self.get_parentBackupImageFullName()

        restoreCommands["incremental"] = restoreCommandIncremental
        restoreCommandsForPrint["incremental"] = restoreCommandIncrementalForPrint
        backupImagesName["incremental"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName


class FullCloudOnlyRestoreBMC(CloudOnlyRestore):
    """
       A concrete specialized class of CloudRestore class
       implements get_restoreCommand() method for full restore from BMC cloud backup
    """
    def __init__(self, dictionaryData):
        CloudOnlyRestore.__init__(self, dictionaryData)

    def get_restoreCommand(self):
        restoreCommand = ( Restore.get_restoreCommand() + " "
                         " --cloud-service=openstack "
                         " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                         " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                         " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                         " --cloud-container=" + self.get_cloudStorageContainer() + " "
                         " --cloud-object=" + self.get_cloudObject() + " "
                         " --cloud-chunked-transfer=false "
                         " --cloud-buffer-size=64 "
                         " --limit-memory=512 "
                         " --backup-dir=" + self.get_backupDirectory() + " "
                         " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                         #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                         " --datadir=" + self.get_restoredDirectory() + " "
                         " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                         " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandForPrint = restoreCommand.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        backupImageName = self.get_backupImageFullName()

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommand
        restoreCommandsForPrint["full"] = restoreCommandForPrint
        backupImagesName["full"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName


class IncrementalCloudOnlyRestoreBMC(CloudOnlyRestore):
    """
       A concrete specialized class of CloudOnlyRestore class
       implements get_restoreCommand() method for full restore from BMC cloud backup
       ToDo: put the correct implementation for get_restoreCommand once finalized
    """

    def __init__(self, dictionaryData):
        try:
           CloudOnlyRestore.__init__(self, dictionaryData)
           self.parentCloudObject = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
           self.parentCloudObject = self.parentCloudObject[1:] if self.parentCloudObject.startswith('/') else self.parentCloudObject
           self.parentBackupImageFullName = urlparse.urljoin(self.cloudStorageURI if self.cloudStorageURI.endswith('/') else self.cloudStorageURI + '/', self.parentCloudObject)
        except KeyError as e:
           common_lib.logger("ERROR","Some keys critical to restore operation are missing from the input JSON.")
           raise KeyError

    def get_parentBackupImageFullName(self):
        return self.parentBackupImageFullName

    def get_parentCloudObject(self):
        return self.parentCloudObject

    def get_restoreCommand(self):

        restoreCommandFull = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_parentCloudObject() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --uncompress --force copy-back-and-apply-log " )

        restoreCommandFullForPrint = restoreCommandFull.replace(self.get_cloudStoragePassword(), "XXXXXXXX")


        restoreCommandIncremental = ( Restore.get_restoreCommand() + " "
                                 " --cloud-service=openstack "
                                 " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
                                 " --cloud-password='" + self.get_cloudStoragePassword() + "'"
                                 " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
                                 " --cloud-container=" + self.get_cloudStorageContainer() + " "
                                 " --cloud-object=" + self.get_cloudObject() + " "
                                 " --cloud-chunked-transfer=false "
                                 " --cloud-buffer-size=64 "
                                 " --limit-memory=512 "
                                 " --backup-dir=" + self.get_backupDirectory() + " "
                                 " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
                                 #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
                                 " --datadir=" + self.get_restoredDirectory() + " "
                                 " --innodb_log_group_home_dir=" + self.get_restoredLogdir() + " "
                                 " --backup-image=- --incremental copy-back-and-apply-log " )

        restoreCommandIncrementalForPrint = restoreCommandIncremental.replace(self.get_cloudStoragePassword(), "XXXXXXXX")

        #create dictionaries to return commands, print commands, and backup image names
        restoreCommands = dict()
        restoreCommandsForPrint = dict()
        backupImagesName = dict()

        restoreCommands["full"] = restoreCommandFull
        restoreCommandsForPrint["full"] = restoreCommandFullForPrint
        backupImagesName["full"] = self.get_parentBackupImageFullName()

        restoreCommands["incremental"] = restoreCommandIncremental
        restoreCommandsForPrint["incremental"] = restoreCommandIncrementalForPrint
        backupImagesName["incremental"] = self.get_backupImageFullName()

        return restoreCommands, restoreCommandsForPrint, backupImagesName

