# Copyright (c) 2016, Oracle and/or its affiliates. All rights reserved.
__author__ = 'Masoud Kalali'
