#!/usr/bin/env python
#
# Copyright (c) 2017 Oracle and/or its affiliates. All rights reserved.
#
__author__= "Calvin Sun"
__copyright__ = "Copyright (c) 2017 Oracle and/or its affiliates. All rights reserved."

import sys
import os

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import constants
import json
from utils import *

def main():
    with open(sys.argv[1]) as data_file:
        input_dict_args = json.load(data_file)

    if input_dict_args:
        return execute(input_dict_args)


"""
entry function for snapshot rollback
"""
def execute(input_dict_args):
    logger("Script invoked for snapshot rollback operation")
    logger("The formatted input json is as ")
    print_dict_as_json(input_dict_args)

    output = {}

    mysql_status = check_process();
    # it is fine if mysqld is not running
    if mysql_status != 0:
        logger("MySQL is not running, but fine for snapshot ops.")
        output['status'] = "Success"
        output['statusMessage'] = "snapshot rollback succeeded."
    else:
        snapshot_sql = "/tmp/snapshot_ops.sql"
        with open(snapshot_sql, "w+") as snapshot_file:
            snapshot_file.write("SET GLOBAL read_only = OFF;")
            snapshot_file.write("UNLOCK TABLES;")
            snapshot_file.close()
            ret = execute_sql(snapshot_sql)

        if ret != 0:
            logger("MySQL UNLOCK TABLES failed")
            output['status'] = "Failure"
            output['statusMessage'] = "MySQL UNLOCK TABLES failed."
        else:
            logger("MySQL UNLOCK TABLES succeeded")
            output['status'] = "Success"
            output['statusMessage'] = "MySQL UNLOCK TABLES succeeded."

    print '<JsonResult>'
    print json.dumps(output, indent=4)
    print '</JsonResult>'
    return 0

if __name__ == "__main__":
    result = main()
    sys.exit(result)
