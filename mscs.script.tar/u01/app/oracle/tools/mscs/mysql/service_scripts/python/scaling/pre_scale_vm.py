__author__= "balagopalan thampi"
__copyright__ = "Copyright (c) 2016-2017 Oracle and/or its affiliates. All rights reserved."
__email__ = "balagopalan.thampi@oracle.com"


import time
import json
import os
import sys
import socket
import subprocess
tools_path=os.path.dirname(os.path.realpath(__file__))
sys.path.insert(1, tools_path)
import conf_parser


def logger(level, message):
    """
    logger prints the level and message to standard out
    """ 
    if level == 'PLAIN':
        print message
    else:
        print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()),
                              level, message)

#blocking call
def call(command, args=None):
    if args:
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(command)
    else:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = process.communicate()

    if not stdout:
        stdout = stderr
    return  process.returncode, stdout

#call the command and record result
def run(command, host='localhost', remoteSSHRetries=5, sleepBetweenRemoteSSHRetries=1):
    startps = time.time();
    hostname=socket.gethostname()
    if host.lower() == hostname.lower() or host.lower() == 'localhost':
        # the command needs to be run locally
        status, stdout = call(command)
    else:
        # the command needs to be run on remote VM.
        import shlex
        remote_command = "ssh -T -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
        args = shlex.split(remote_command)
        args.append(host)

        for iteration in range(remoteSSHRetries):
            # run the command on remote VM and watch out for network related mishaps
            status, stdout = call(command, args=args)
            if "ssh: Could not resolve hostname" in stdout:
                time.sleep(sleepBetweenRemoteSSHRetries)
            else:
                break
        command = "{0} \"{1}\"".format(remote_command, command)
    return status, stdout

#to print the dictionary as a json
def print_dict_as_json(dictionary):
    try:
        print json.dumps(dictionary, indent=4)
    except Exception as e:
        print str(e)

#called by SM
def execute(data):
    logger("INFO","Script invoked for pre Scale operations")
    #logger("INFO","The subscription type for this service is : " +data['SM_SERVICE_INFO']['subscription'])
    logger("INFO","The formatted input json is as ")
    print_dict_as_json(data)
    tools_path=os.path.realpath(__file__)

    #do operations here
    mscs_const=conf_parser.ConfParser(tools_path[:tools_path.index("service_scripts")] + "service_scripts/mscs.cnf")
    mycnf_file_path=mscs_const.getProperty('','mysql_conf_file')
    timeout=60
    sleep_time=10
    while timeout > sleep_time:
        try:
            mycnf=conf_parser.ConfParser(mycnf_file_path)
            break
        except IOError as err:
            d = {}
            for l in file('/proc/mounts'):
                if l[0] == '/':
                    l = l.split()
                    d[l[0]] = l[1]
            logger("INFO", "mounted volumes cat /proc/mounts : " + str(d))
            logger("Warning", "File " + mycnf_file_path + " not found: Error " + str(err))
            logger("INFO", "Waiting for my.cnf file for 10s")
            time.sleep(10)
            sleep_time = sleep_time + 10
    if timeout <= sleep_time:
        result = {}
        logger("ERROR","Could not do preScale operations")
        result["status"] = "Failed"
        result["statusMessage"] = "my.cnf file not found" 
        logger("INFO","Exiting from the script")
        print "<JsonResult>"+json.dumps(result)+"</JsonResult>"
        return 0
    buffer_pool_size_current = mycnf.getProperty('mysqld','innodb-buffer-pool-size')
    buffer_pool_instances_current=mycnf.getProperty('mysqld','innodb-buffer-pool-instances')

    mscs_utils_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/msaas-provisioning-utils.sh"
    mysql_utils_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"

    command = "source {mscs_utils_script}; getSystemRamInMB ".format(mscs_utils_script=mscs_utils_script)

    status,stdout = run(command)
    if status == 0:
    	ram_size=stdout.strip()
    else:
    	logger("Warning","Could not read ram size")

    command = "source {0}; calculateInnodbBuffPoolSize {1} ".format(mysql_utils_script,ram_size)
    status,stdout = run(command)
    if status == 0:
    	pool_size_calculated=stdout.strip()
    else:
    	logger("Warning","Could not calculate buffer pool size")

    command = "source {0}; calculateInnodbBuffPoolInstances {1} ".format(mysql_utils_script,pool_size_calculated)
    status,stdout = run(command)
    if status == 0:
    	pool_instances_calculated=stdout.strip()
    else:
    	logger("Warning","Could not calculate pool innodb-buffer-pool-instances")

    pool_size_calculated=str(int(pool_size_calculated)/1000)+'G'

    logger("INFO","current buffer pool size = {0}, calculated buffer pool size = {1}".format(buffer_pool_size_current,pool_size_calculated))
    logger("INFO"," current buffer pool instances = {0}, calculated buffer pool instances = {1}".format(buffer_pool_instances_current,pool_instances_calculated))

    if pool_size_calculated == buffer_pool_size_current:
        flag_file=tools_path[:tools_path.index("tools")]+ "tools/msaas/log/.buffer_pool_chage_file.flag"
        open(flag_file,'w')
        logger("INFO","created flagfile for post scale optimization")

    status = 0
    result = {}
    if status == 0:
        logger("INFO","Successfully executed PreScale scripts")
        result["status"] = "Success"
        result["statusMessage"] = "Successfully executed PreScale scripts"
    else:
        logger("ERROR","Could not do preScale operations")
        result["status"] = "Failed"
        result["statusMessage"] = "Could not do preScale operations"

    logger("INFO","Exiting from the script")
    print "<JsonResult>"+json.dumps(result)+"</JsonResult>"

