#!/usr/bin/env bash
volume=$1
device=$2

echo 'Extending '$volume
volumeGroup='vg_'$volume
if [ ${volumeGroup} = vg_MySQLlog ]; then
   volumeGroup=vg_log
   volume=log
fi
echo 'Volume Group '$volumeGroup

if vgdisplay | grep -q $volumeGroup; then
    pvcreate ${device}
    vgextend $volumeGroup ${device}
    lvextend /dev/$volumeGroup/lv_$volume -l+100%FREE
    resize2fs -f /dev/$volumeGroup/lv_$volume
else
    echo 'Cannot extend the volumes as they were not created using lvm'
    return 1
fi