#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
import time
import calendar
import xml.sax

__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'


#
##
###
def check_backup_in_cloud(URL, username, password):
   """
   Checks the backup image on cloud using pyCurl
   Checks for HTTP response code 200 for success
   """
   import pycurl
   op_return_obj = OperationReturnObj()
   crl = pycurl.Curl()
   crl.setopt(pycurl.URL, str(URL))
   crl.setopt(pycurl.VERBOSE, 1)
   crl.setopt(pycurl.USERPWD, '%s:%s' % (str(username), str(password)))
   crl.setopt(pycurl.NOBODY, 1)
   try:
       crl.perform()
       op_return_obj.set_bool_status(True)
       op_return_obj.set_status_msg("MySQL backup image {URL} avilable on cloud )".format(URL=URL))
       if crl.getinfo(pycurl.RESPONSE_CODE) != 200 :
          print "Failed while checking for backup image {URL} in cloud with response code : {respcode}".format(URL=URL, respcode=str(crl.getinfo(pycurl.RESPONSE_CODE)))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("Failed while checking for backup image {URL} in cloud with response code : {respcode}".format(URL=URL, respcode=str(crl.getinfo(pycurl.RESPONSE_CODE))))
   except pycurl.error, e:
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("Looking for MySQL backup image {URL} in cloud resulted in error {error}".format(error=e,URL=URL))
   crl.close()
   return op_return_obj

#
##
###
def delete_backup_from_cloud(URL, username, password):
   """
   Deletes the backup image from the cloud using pyCurl
   Checks for HTTP response code 204 for success
   """
   import pycurl
   op_return_obj = OperationReturnObj()
   crl = pycurl.Curl()
   crl.setopt(pycurl.URL, str(URL))
   crl.setopt(pycurl.VERBOSE, 1)
   crl.setopt(pycurl.USERPWD, '%s:%s' % (str(username), str(password)))
   crl.setopt(pycurl.CUSTOMREQUEST, "DELETE")
   try:
       crl.perform()
       op_return_obj.set_bool_status(True)
       op_return_obj.set_status_msg("MySQL backup image {URL} delete )".format(URL=URL))
       if crl.getinfo(pycurl.RESPONSE_CODE) != 204 :
          print "Failed with error code :" + str(crl.getinfo(pycurl.RESPONSE_CODE))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("MySQL backup image delete resulted in error {error}".format(error=str(crl.getinfo(pycurl.RESPONSE_CODE))))
   except pycurl.error, e:
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("MySQL backup image delete resulted in error {error}".format(error=e))
   crl.close()
   return op_return_obj

#
##
###
def delete_multipart_backup_from_cloud(URL, username, password):
   """
   Deletes the multipart backup image from the cloud using pyCurl
   Checks for HTTP response code 202 for success
   """
   import pycurl
   op_return_obj = OperationReturnObj()
   crl = pycurl.Curl()
   crl.setopt(pycurl.URL, str(URL) + "?multipart-manifest=delete" )
   crl.setopt(pycurl.VERBOSE, 1)
   crl.setopt(pycurl.USERPWD, '%s:%s' % (str(username), str(password)))
   crl.setopt(pycurl.CUSTOMREQUEST, "POST")
   try:
       crl.perform()
       op_return_obj.set_bool_status(True)
       op_return_obj.set_status_msg("MySQL backup image {URL} delete )".format(URL=URL))
       if crl.getinfo(pycurl.RESPONSE_CODE) != 202 :
          print "Failed with error code :" + str(crl.getinfo(pycurl.RESPONSE_CODE))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("MySQL backup image delete resulted in error {error}".format(error=str(crl.getinfo(pycurl.RESPONSE_CODE))))
   except pycurl.error, e:
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("MySQL backup image delete resulted in error {error}".format(error=e))
   crl.close()
   return op_return_obj

#
##
###
def download_backup_from_cloud(URL, filename, username, password):
   """
   Downloads the backup image from the cloud to the disk using pyCurl
   Checks for HTTP response code 200 for success
   """
   import pycurl

   op_return_obj = OperationReturnObj()
   disk_file=open(filename,"wb")
   crl = pycurl.Curl()
   crl.setopt(pycurl.URL, str(URL))
   crl.setopt(pycurl.WRITEDATA, disk_file)
   crl.setopt(pycurl.VERBOSE, 1)
   crl.setopt(pycurl.USERPWD, '%s:%s' % (str(username), str(password)))
   try:
       crl.perform()
       op_return_obj.set_bool_status(True)
       op_return_obj.set_status_msg("MySQL backup image downloaded to disk location {location}".format(location=filename))
       if crl.getinfo(pycurl.RESPONSE_CODE) != 200 :
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("MySQL backup image download resulted in error {error}".format(error=crl.getinfo(pycurl.RESPONSE_CODE)))
   except pycurl.error, e:
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("MySQL backup image download resulted in error {error}".format(error=e))
   crl.close()
   return op_return_obj



#
##
###
def backup(user, backup_image, backup_dir):
    """
    An adhoc backup function accepts following inputs:
    user : <dbuser for backup>
    backup_image : <backupImage>
    backup_directory : <backupDirectory>
    Generates the full backup command and executes the same by calling execude_cmd
    if successfull returns a "0" return code
    """
    import constants
    MEB=constants.MEB_LOC
    MEB_USER=user
    MEB_BACKUP_IMAGE=backup_image
    MEB_BACKUP_DIR=backup_dir
    executor = Executor()

    cmd="{MEB} --user={MEB_USER} --backup-dir={MEB_BACKUP_DIR} --backup-image={MEB_BACKUP_IMAGE} --compress backup-to-image".format(MEB=MEB,MEB_USER=MEB_USER,MEB_BACKUP_DIR=MEB_BACKUP_DIR,MEB_BACKUP_IMAGE=MEB_BACKUP_IMAGE)
    logger("INFO","running backup command {cmd}".format(cmd=cmd))
    exe_result = executor.execute_cmd(cmd)
    if exe_result.get_return_code() != 0:
        logger("ERROR","backup command {cmd} failed".format(cmd=cmd))
        return exe_result.get_return_code();

    cmd="{MEB} --backup-image={MEB_BACKUP_DIR}/{MEB_BACKUP_IMAGE} validate".format(MEB=MEB,MEB_BACKUP_DIR=MEB_BACKUP_DIR,MEB_BACKUP_IMAGE=MEB_BACKUP_IMAGE)
    logger("INFO","running validate command {cmd}".format(cmd=cmd))
    exe_result = executor.execute_cmd(cmd)
    return exe_result.get_return_code();

#
##
###
def restore(user, backup_image, backup_dir, data_dir):
    """
    An adhoc restore function accepts following inputs:
    user : <dbuser for backup>
    backup_image : <backupImage>
    backup_directory : <backupDirectory>
    data_dir :<mysql datadir >
    Generates the restore command and executes the same by calling execude_cmd
    if successfull returns a "0" return code
    """
    import constants
    MEB=constants.MEB_LOC
    MEB_USER=user
    MEB_BACKUP_IMAGE=backup_image
    MEB_BACKUP_DIR=backup_dir
    MEB_RESTORE_DIR=data_dir
    executor = Executor()

    cmd="{MEB} --user={MEB_USER} --backup-dir={MEB_BACKUP_DIR} --backup-image={MEB_BACKUP_IMAGE} --datadir={MEB_RESTORE_DIR} --uncompress --force copy-back-and-apply-log".format(MEB=MEB,MEB_USER=MEB_USER,MEB_BACKUP_DIR=MEB_BACKUP_DIR,MEB_BACKUP_IMAGE=MEB_BACKUP_IMAGE,MEB_RESTORE_DIR=MEB_RESTORE_DIR)
    logger("INFO","running restore command {cmd}".format(cmd=cmd))
    exe_result = executor.execute_cmd(cmd)
    if exe_result.get_return_code() != 0:
        logger("ERROR","backup command {cmd} failed".format(cmd=cmd))

    return exe_result.get_return_code();

#
##
###
def logger(level, message):
    """
    logger prints the level and message to standard out
    """ 
    if level == 'PLAIN':
        print message
    else:
        print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()),
                              level, message)


def remove_file(file_full_path):
    """
    utility function to remove file
    """
    import os
    try:
        os.remove(file_full_path)
    except OSError as e:
        logger("ERROR",str(e))

def analyzeHttpErrorResp(source, method, httpResposeObj):
    """
    Prints the appropriate error message to the stdout based on the HTTP code and operation.
    Returns operation object with error message encapsulated 
    """
    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(False)
    httpCode = httpResposeObj.get_http_code()
    statusMessage = ' '

    if httpCode == 404 and method == 'PUT':
        logMessage = statusMessage = "Unable to upload the file: " \
                          "the URL to Oracle Storage Cloud Service container is incorrect."
        errorCode = "<MSCS-ERR-20305>: "
    elif httpCode == 404 and method == 'DELETE':
        logMessage = "File %s does not exist in the " \
                              "Oracle Storage Cloud Service container. Nothing to delete." % source
        statusMessgae = "File does not exist in the " \
                              "Oracle Storage Cloud Service container. Nothing to delete."
        errorCode = "<MSCS-ERR-20306>: "
    elif httpCode == 404 and method == 'GET':
        logMessage = "Unable to veriry the file." \
                              "File %s does not exist in the Oracle Storage Cloud Service container." % source
        statusMessgae = "Unable to veriry the file." \
                              "File does not exist in the Oracle Storage Cloud Service container."
        errorCode = "<MSCS-ERR-20307>: "
    elif httpCode == 413 and method == 'PUT':
        logMessage = statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. Insufficient space for the file."
        errorCode = "<MSCS-ERR-20308>: "
    elif httpCode == 401 and method == 'PUT':
        logMessage = statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. User not authorized."
        errorCode = "<MSCS-ERR-20309>: "
    elif httpCode == 401 and method == 'DELETE':
        logMessage = statusMessage = "Unable to delete the file in the Oracle Storage Cloud Service container. " \
                         "User not authorized."
        errorCode = "<MSCS-ERR-20310>: "
    elif httpCode == 401 and method == 'GET':
        logMessage = statusMessage = "Unable to verify/download the file in the Oracle Storage Cloud Service container." \
                         "User not authorized."
        errorCode = "<MSCS-ERR-20311>: "
    elif httpCode == 504 and method == 'PUT':
        logMessage = statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. Gateway timeout."
        errorCode = "<MSCS-ERR-20312>: "
    elif httpCode == 408 and method == 'PUT':
        logMessage = statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. Connection timeout."
        errorCode = "<MSCS-ERR-20313>: "
    elif httpCode == 418 and method == 'PUT':  # customized http code for "could not resolve host error"
        logMessage = statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container: Could not resolve host. " \
                           "The given remote host was not resolved."
        errorCode = "<MSCS-ERR-20314>: "
    elif httpCode == 418 and method == 'DELETE':  # customized http code for "could not resolve host error"
        logMessage = statusMessage = "Unable to delete the file: Could not resolve host. " \
                         "The given remote host was not resolved."
        errorCode = "<MSCS-ERR-20315>: "
    elif httpCode == 418 and method == 'GET':  # customized http code for "could not resolve host error"
        logMessage = statusMessage = "Unable to verify/download the file in Oracle Storage Cloud Service container: " \
                         "Could not resolve the host. The given remote host was not resolved."
        errorCode = "<MSCS-ERR-20316>: "
    elif httpCode == 419 and method == 'PUT':  # customized http code for ssl error
        logMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. %s" % httpResposeObj.get_message()
        statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container."
        errorCode = "<MSCS-ERR-20317>: "
    elif httpCode == 419 and method == 'DELETE':  # customized http code for ssl error
        logMessage = "Unable to delete the file from the Oracle Storage Cloud Service container. " \
                             "%s..." % httpResposeObj.get_message()
        statusMessage = "Unable to delete the file from the Oracle Storage Cloud Service container." 
        errorCode = "<MSCS-ERR-20318>: "
    elif httpCode == 419 and method == 'GET':  # customized http code for ssl error
        logMessage = "Unable to verify/download the file in the Oracle Storage Cloud Service container. " \
                             "%s..." % httpResposeObj.get_message()
        statusMessage = "Unable to verify/download the file in the Oracle Storage Cloud Service container." 
        errorCode = "<MSCS-ERR-20319>: "
    elif httpCode == 999 and method == 'PUT':
        logMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container: %s. " % httpResposeObj.get_message()
        statusMessage = "Unable to upload the file to the " \
                          "Oracle Storage Cloud Service container. " \
                          "Please ensure that your account credentials are correct and has privileges to upload to the container." 
        errorCode = "<MSCS-ERR-20320>: "
    elif httpCode == 999 and method == 'DELETE':
        logMessage = "Unable to delete the file form the " \
                          "Oracle Storage Cloud Service container: %s. " % httpResposeObj.get_message()
        statusMessage = "Unable to delete the file form the " \
                          "Oracle Storage Cloud Service container. " \
                          "Please ensure that your account credentials are correct and has privileges to delete from the container." 
        errorCode = "<MSCS-ERR-20321>: "
    elif httpCode == 999 and method == 'GET':
        logMessage = "Unable to veriry the file in the " \
                          "Oracle Storage Cloud Service container: %s. " % httpResposeObj.get_message()
        statusMessage = "Unable to veriry the file in the " \
                          "Oracle Storage Cloud Service container. " \
                          "Please ensure that your account credentials are correct and has required privileges on the container."
        errorCode = "<MSCS-ERR-20322>: "
    else:
        logMessage = "Unable to %s the file in the " \
                          "Oracle Storage Cloud Service container. " \
                           "The HTTP Code: %s. The message: %s" % (method.lower(), httpCode, httpResposeObj.get_message())
        statusMessage = "Unable to perform operation on the file in the " \
                          "Oracle Storage Cloud Service container. " \
                          "Please ensure that your account credentials are correct and has required privileges on the container."
        errorCode = "<MSCS-ERR-20323>: "

    logger("ERROR", "HTTP response code :" + str(httpCode))
    logger("ERROR", logMessage)
    operation_obj.set_status_msg(errorCode + statusMessage)
    return operation_obj

def uploadManifestDLO(target, credential, chunksDetail, storageURIWithoutContainer):
    import constants

    timeout     = constants.TIMEOUT
    method      = 'PUT'
    headers     = dict()

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)

    cloudkeyWithContainer = target.replace(storageURIWithoutContainer, '', 1)
    headers['X-Object-Manifest'] = cloudkeyWithContainer
    headers['Content-Length'] = 0

    #perform upload
    response = do_request(target, credential, method, None, headers, timeout)

    http_response_code = response.get_http_code()
    print http_response_code

    if http_response_code == 201:
       logger("INFO","Created the manifest {manifest} to the Oracle Storage Cloud Service container.".format(manifest=target))
    else:
       return_obj = analyzeHttpErrorResp(target, method,response)
       operation_obj.set_bool_status(False)
       operation_obj.set_status_msg(return_obj.get_status_msg())

    return operation_obj

 
def uploadManifest(target, credential, chunksDetail, storageURIWithoutContainer):
    """
    Creates and uploads a manifest file for a chunked upload to cloud storage.
    Return:
      rtype: OperationReturnObj
    """

    import constants

    timeout     = constants.TIMEOUT
    method      = 'PUT'
    headers     = dict()

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)

    # create manifest
    putComma = False
    manifest = "[\n"

    for key in  sorted(chunksDetail):
       if putComma :
          manifest = manifest  + '\n,{'
       else:
          manifest = manifest  + '{'
       putComma = True
       manifest = manifest + '\n\t "path": "'
       manifest = manifest + chunksDetail[key]["target"].replace(storageURIWithoutContainer,'',1)
       manifest = manifest + '",\n\t "etag": "'
       manifest = manifest + chunksDetail[key]["chunkMD5"]
       manifest = manifest + '",\n\t "size_bytes": '
       manifest = manifest + str(chunksDetail[key]["filesize"])
       manifest = manifest  + '\n}'

    manifest = manifest  + '\n]'
    logger("INFO","Created manifest file.")
    logger("INFO",manifest)

    #set the header
    headers['Content-Length'] = len(manifest)
    #create the query string
    queryargs = '?multipart-manifest=put'
    #perform upload
    response = do_request(target + queryargs, credential, method, manifest, headers, timeout)

    http_response_code = response.get_http_code()
    if http_response_code == 201:
       logger("INFO","Uploaded the manifest {manifest} to the Oracle Storage Cloud Service container.".format(manifest=target + queryargs))
    else:
       return_obj = analyzeHttpErrorResp(target, method,response)
       operation_obj.set_bool_status(False)
       operation_obj.set_status_msg(return_obj.get_status_msg())

    return operation_obj

def chunkAndUpload(source,target,credential,storageURI,container):
    """
    Upload local file to cloud storage chunk by chunk.
    Chunk size has to follow some rules of mmap lib, it is set in cloud_storage_util. Default 4GB
        :param :
        * source: (str) the source where to upload from
        * target: (str) the target where to upload to
        * credential: (str) the credential for cloud storage access
        * storageURI: (str) cloud storage URI
        * container: (srt) cloud storage container name
        :return:
        :rtype:  OperationReturnObj
    """
    import constants
    import os
    import math
    import hashlib
    import mmap
    import copy
    import traceback

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    #initialize
    offset      = 0
    index       = 1
    method      = 'PUT'
    timeout     = constants.TIMEOUT

    chunkSize   = constants.CHUNKSIZE

    target_template =  "{target}_part_{index}"


    # keep track of uploaded chunks for creating manifest on successful upload or for cleanup on failure
    chunksDetail = dict()
    #check if source file exist before attempting upload
    if not os.path.isfile(source):
       logger("ERROR", "Unable to upload the file to the Oracle Storage Cloud Service container. The file %s does not exist." % source)
       statusMessage = "<MSCS-ERR-20301>: Unable to upload the file to the Oracle Storage Cloud Service container. " \
                         "The file to be uploaded does not exist."
       operation_obj.set_bool_status(False)
       operation_obj.set_status_msg(statusMessage)

       return operation_obj, chunksDetail

    # Calculate the number of chunks
    numOfChunks = int(
       math.ceil(os.path.getsize(source) / float(chunkSize))
    )

    logger("INFO","Started the chunked uploading to "
                    "the Oracle Storage Cloud Service container.")
    logger("INFO","The number of chunks to be uploaded is: {numberOfChunks}."
                    .format(numberOfChunks=numOfChunks))
    # iterate
    while numOfChunks:
        headers         = dict()
        chunkDetail     = dict()

        try:
            with open(source, 'rb') as infile:
               # chunksize should be smaller than filesize
               chunkSize = chunkSize if chunkSize < os.path.getsize(source) else os.path.getsize(source)
               # if the remaining file is less that the chubksize
               chunkSize =  os.path.getsize(source) - offset if os.path.getsize(source) - offset < chunkSize else chunkSize
               # offset should be with in the file
               # check if offset is set properly
               if  offset > os.path.getsize(source) - 1:
                   logger("ERROR","Unable to upload the chunk to the Oracle Storage Cloud Service container. The offset is out of boundary.")
                   operation_obj.set_bool_status(True)
                   operation_obj.set_status_msg("<MSCS-ERR-20302>: Unable to upload the chunk to the Oracle Storage Cloud Service container. "
                                              "The offset is out of boundary.")
                   return operation_obj
               #Memory map the source file
               m_mapped_data = mmap.mmap(infile.fileno(), chunkSize, access=mmap.ACCESS_READ, offset=offset)
               #set the target for upload of the chunk
               target_location = target_template.format(target=target,index='{0:05}'.format(index))
               #set the content size
               headers['Content-Length'] = chunkSize
               #perform the upload
               response = do_request(target_location, credential, method, m_mapped_data, headers, timeout)
               #obtain the response code
               http_response_code = response.get_http_code()

               if http_response_code == 201:
                  try:
                     chunkMD5 = hashlib.md5(m_mapped_data).hexdigest()
                  except Exception, e:
                     logger("ERROR","Unable to generate md5 hash for chunki.")
                     operation_obj.set_bool_status(return_obj.get_bool_status())
                     operation_obj.set_status_msg("<MSCS-ERR-20331>: Failed while genrating md5 hash.")
                     return operation_obj

                  chunkDetail["chunkMD5"] = chunkMD5
                  chunkDetail["filesize"] = chunkSize
                  chunkDetail["target"] = target_location
                  chunksDetail["part_" + str(index)] = copy.deepcopy(chunkDetail)
                  logger("INFO","Uploaded the file(chunk) {chunk} to the Oracle Storage Cloud Service container".format(chunk=target_location))
               else:
                  return_obj = analyzeHttpErrorResp(source, method, response)
                  operation_obj.set_bool_status(return_obj.get_bool_status())
                  operation_obj.set_status_msg(return_obj.get_status_msg())
                  return operation_obj,chunksDetail

               #close the memory map
               m_mapped_data.close()

        except (IOError, KeyError):
            statusMessage = "Unable to upload the file to the " \
                             "Oracle Storage Cloud Service container."
            logger("ERROR", statusMessage)
            logger("ERROR", traceback.format_exc())
            operation_obj.set_bool_status(False)
            operation_obj.set_status_msg("<MSCS-ERR-20399>: " + statusMessage)
            return operation_obj,chunksDetail

        numOfChunks     -= 1
        index           += 1
        offset          += chunkSize

    # upload the manifest
    if not storageURI.endswith('/'):
       storageURI = storageURI + '/'

    storageURIWithoutContainer = storageURI.replace(container + '/','',1)
    return_obj = uploadManifestDLO(target, credential, chunksDetail, storageURIWithoutContainer)
    if not return_obj.get_bool_status():
       operation_obj.set_bool_status(False)
       operation_obj.set_status_msg(return_obj.get_status_msg())

    return operation_obj,chunksDetail

def deleteObjectFromCloudDLO(source, credential):
    """
    Deletes DLO objects from the cloud storage
    param:
        source:<objectURL>
        cerdential:<credential> cloud storage credential in <user>:<password> format
    retun:
        rtype: OperationReturnObj
    """
    import json
    import urlparse

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    get_object_info_result, response = GetCloudObjectinfo(source, credential)
    method = 'DELETE'
    storageURIWithContainer = source.split('?')[0] + '/' 
    #objectPath = source.split('?')[1].replace('prefix=','',1).replace('&&format=json','',1)
    segments = json.loads(response.get_http_response().read()) 
    for segment in segments:
      objectPath = segment['name']
      logger("INFO", "Deleting the object {object} from the Oracle Storage Cloud Service container.".format(object=objectPath))
      # Do the delete request
      source = urlparse.urljoin(storageURIWithContainer,objectPath) 
      response = do_request(source, credential, method, "", {})

      http_response_code = response.get_http_code()
      if http_response_code == 204 or http_response_code == 200:
         statusMessage = "Deleted the object {object} form the " \
                                "Oracle Storage Cloud Service container".format(object=source)
         logger("INFO",statusMessage)
         operation_obj.set_status_msg(statusMessage)
      else:
         logger("ERROR","Failed to delete the object {object} form the " \
                                "Oracle Storage Cloud Service container".format(object=source))
         return_obj = analyzeHttpErrorResp(source, method, response)
         operation_obj.set_status_msg(return_obj.get_status_msg())
         operation_obj.set_bool_status(False)
    
    return operation_obj

def deleteObjectFromCloud(source, credential):
    """
    Deletes SLO objects from the cloud storage
    param:
        source:<objectURL>
        cerdential:<credential> cloud storage credential in <user>:<password> format
    retun:
        rtype: OperationReturnObj
    """

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    method = 'DELETE'
    logger("INFO", "Deleting the object {object} from the Oracle Storage Cloud Service container.".format(object=source))
    # Do the request
    response = do_request(source, credential, method, "", {})

    http_response_code = response.get_http_code()
    if http_response_code == 204 or http_response_code == 200:

       statusMessage = "Deleted the object {object} form the " \
                              "Oracle Storage Cloud Service container".format(object=source)
       logger("INFO",statusMessage)
       operation_obj.set_status_msg(statusMessage)
       return operation_obj
    else:
       logger("ERROR","Failed to delete the object {object} form the " \
                              "Oracle Storage Cloud Service container".format(object=source))
       return_obj = analyzeHttpErrorResp(source, method, response)
       operation_obj.set_status_msg(return_obj.get_status_msg())
       operation_obj.set_bool_status(False)

    return operation_obj

def verifyObjectOnCloud(source, credential):
    """
    Verifies objects on the cloud storage
    param:
        source:<objectURL>
        cerdential:<credential> cloud storage credential in <user>:<password> format
    retun:
        rtype: OperationReturnObj
    """
    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    method = 'GET'
    logger("INFO", "Verifying the object {object} on Oracle Storage Cloud Service container.".format(object=source))
    response = do_request(source, credential, method, "", {}) 

    http_response_code = response.get_http_code()
    if http_response_code == 200:

       statusMessage = "Verified the object {object} in the " \
                              "Oracle Storage Cloud Service container".format(object=source)
       logger("INFO",statusMessage)
       operation_obj.set_status_msg(statusMessage)
       return operation_obj
    else:
       return_obj = analyzeHttpErrorResp(source, method, response)
       operation_obj.set_status_msg(return_obj.get_status_msg())
       operation_obj.set_bool_status(False)

    return operation_obj

def GetCloudObjectinfo(source, credential):
    """
    Gets objects info on the cloud storage
    param:
        source:<objectURL>
        cerdential:<credential> cloud storage credential in <user>:<password> format
    retun:
        rtype: OperationReturnObj
    """
    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    method = 'GET'
    logger("INFO", "Getting the object {object} info from Oracle Storage Cloud Service container.".format(object=source))
    response = do_request(source, credential, method, "", {})

    http_response_code = response.get_http_code()
    if http_response_code == 200:

       statusMessage = "Got object {object} info from the " \
                              "Oracle Storage Cloud Service container".format(object=source)
       logger("INFO",statusMessage)
       operation_obj.set_status_msg(statusMessage)
    else:
       return_obj = analyzeHttpErrorResp(source, method, response)
       operation_obj.set_status_msg(return_obj.get_status_msg())
       operation_obj.set_bool_status(False)

    return operation_obj, response

def downloadObjectFromCloud(source, target, credential):
    """
    Downloads objects from the cloud storage
    param:
        source:<objectURL>
        cerdential:<credential> cloud storage credential in <user>:<password> format
        target:<disk file path>
    retun:
        rtype: OperationReturnObj
    """
    import traceback
    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    method = 'GET'
    logger("INFO", "Downloading the object {object} from Oracle Storage Cloud Service container.".format(object=source))
    try:
        response = do_request(source, credential, method, "", {}) 

        http_response_code = response.get_http_code()
        if http_response_code == 200:
           # Read data from the response and write to file
           with open(target, 'ab', 0) as writeFile:
                for file_segment in iter(lambda: response.get_http_response().read(1024 * 1024 * 1024), ''):
                    writeFile.write(file_segment)

           statusMessage = "Downloaded the object {object} from the " \
                                  "Oracle Storage Cloud Service container".format(object=source)
           logger("INFO",statusMessage)
           operation_obj.set_status_msg(statusMessage)
           return operation_obj
        else:
           return_obj = analyzeHttpErrorResp(source, method, response)
           operation_obj.set_status_msg(return_obj.get_status_msg())
           operation_obj.set_bool_status(False)

        return operation_obj
    except (IOError, Exception):
       status_message = "Unable to download the backup archive from the Oracle Storage Cloud Service container. " 
       logger("ERROR", status_message)
       traceback_msg = traceback.format_exc()
       logger("ERROR", traceback_msg)
       operation_obj.set_bool_status(False)
       operation_obj.set_status_msg("<MSCS-ERR-20398>: " + status_message)
       return operation_obj


def get_BMC_Storage_basicauth_URL(StorageURL):
    """
      Parses the storage URL for  <serviceInstanceName>-<identityDomainName>/<conatiner>
         input : Storage URL
         returns: <serviceInstanceName>-<identityDomainName>/<conatiner>
    """

    import urlparse
    uriTokens = urlparse.urlparse(StorageURL)
    path = uriTokens.path
    if path.endswith('/'):
       path  = path[:-1]

    path[:-len(path.split('/')[-1]) -1]
    return StorageURL[:-len(path.split('/')[-1]) -1]

def get_Container_from_Storage_URL(StorageURL):
    """ 
      Parses the storage URL for  <serviceInstanceName>-<identityDomainName>/<conatiner>
         input : Storage URL
         returns: <serviceInstanceName>-<identityDomainName>/<conatiner>
    """

    import urlparse
    uriTokens = urlparse.urlparse(StorageURL)
    path = uriTokens.path
    if path.endswith('/'):
       path  = path[:-1]

    container = path.split('/')[-1]
    serviceInstanceName_identityDomainName =  path.split('/')[-2]
    return serviceInstanceName_identityDomainName + "/" + container

def get_myDotCnf_properties():
    import constants
    op_return_obj = OperationReturnObj()
    op_return_obj.set_bool_status(True)
    myDotCNF = {}
    try:
        with open(constants.MYDOTCNF) as myCnffile:
           for line in myCnffile:
              if not line.strip().startswith("#") and line.strip().startswith("innodb-"):
                 property, value = line.partition("=")[::2]
                 myDotCNF[property.strip()] = value.strip()
    except IOError:
        op_return_obj.set_bool_status(False)

    return myDotCNF, op_return_obj

def get_logDirSize():
    import re
    logDirSize = 0
    myDotCNF, op_return_obj = get_myDotCnf_properties()
    if not op_return_obj.get_bool_status() :
       logger("INFO","Unable to determine innodb-log-file-size value")
       return logDirSize

    if "innodb-log-files-in-group" in myDotCNF  and "innodb-log-file-size" in myDotCNF :
       noOfFiles = [int(i) for i in re.findall(r'\d+',myDotCNF["innodb-log-files-in-group"])][0]
       sizeUnit = re.findall(r'(K|M|G)+',myDotCNF["innodb-log-file-size"])
       if not sizeUnit :
          sizeFactor = 1
       elif sizeUnit[0] == 'G' :
          sizeFactor = 1024 * 1024 * 1024
       elif sizeUnit[0] == 'M' :
          sizeFactor = 1024 * 1024
       else :
          sizeFactor = 1024

       logFileSize = [int(i) for i in re.findall(r'\d+',myDotCNF["innodb-log-file-size"])][0]

       logger("INFO","No of innodb log files {num}".format(num=noOfFiles))
       logger("INFO","Each innodb log file size {fsize} bytes".format(fsize=logFileSize * sizeFactor ))
       logDirSize = logFileSize * sizeFactor * noOfFiles

    return logDirSize
       

def get_logDir():
    myDotCNF, op_return_obj = get_myDotCnf_properties()

    if not op_return_obj.get_bool_status() :
       logger("Error","Unable to determine innodb-log-group-home-dir value")
       raise KeyError

    if "innodb-log-group-home-dir" in myDotCNF :
       return myDotCNF["innodb-log-group-home-dir"]
    else:
       return None


def remove_file_with_same_pattern(directory, pattern):
    """
    Removes file matching a pattern
       param:
         directory : (str) <directory path>
         pattern : (str) a valid regex 
       return:
         rtype: OperationReturnObj
    """
    import os
    import re
    op_return_obj = OperationReturnObj()
    try:
        for f in os.listdir(directory):
            if re.search(pattern, f):
                os.remove(os.path.join(directory, f))

        op_return_obj.set_bool_status(True)
        return op_return_obj
    except OSError as e:
        logger("ERROR",str(e))
        op_return_obj.set_bool_status(False)
        return op_return_obj

def get_file_md5_checksum(file_path, host=None, credential=None):
    """
    Gets md5sum for the input file
    """

    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)
    if  file_path.startswith('http') or file_path.startswith('https'):
        get_object_info_result, response = GetCloudObjectinfo(file_path, credential)
        http_header_info=dict(response.get_http_response().info())
        md5hash = http_header_info['etag']
    else:
       executor = Executor()
       command_line = "md5sum {file_path}".format(file_path=file_path)
       execution_result = executor.execute_cmd(command_line, host=host)

       if execution_result.get_return_code() != 0:
          logger("ERROR","unable to calculate checksum for file {file_path}".format(file_path=file_path))
          return None
       md5hash = execution_result.get_detail().split()[0]

    return md5hash

def get_file_size(file_path, host=None, credential=None):
    """
    Get bundle size on host
    :param file_path:
    :type file_path: str
    :param host:
    :type host: str
    :return:
    :rtype: int
    """

    import socket
    operation_obj = OperationReturnObj()
    operation_obj.set_bool_status(True)

    if not host:
        host = socket.gethostname()

    logger("INFO","Getting the size in bytes of the file {file_path} on the host {host}".format(file_path=file_path,host=host))
    if  file_path.startswith('http') or file_path.startswith('https'):
        get_object_info_result, response = GetCloudObjectinfo(file_path, credential)
        http_header_info=dict(response.get_http_response().info())
        size=http_header_info['content-length']
    else:
       executor = Executor()
       command_line = "ls -l %s | awk '{ print $5 }'" % file_path
       execution_result = executor.execute_cmd(command_line, host=host)

       if execution_result.get_return_code() == 0:
          size = int(execution_result.get_std_out())
       else:
          size = 0
          logger("ERROR","unable to get the size of the file {file_path} size on {host}.\nError: {detail}"\
            .format(file_path=file_path,
                    host=host,
                    detail=execution_result.get_detail()))
    return size

def add_file_to_zip_archive(source_file_path, zip_archive_path):
    """
    Add and update file in zip archive
    :param source_file_path:
    :param zip_archive_path:
    :return:
    """
    import os
    if not os.path.isfile(source_file_path):
        logger("ERROR","Unable to add file to {zip_archive_path}. File {source_file_path} does not exist".format(zip_archive_path=zip_archive_path, source_file_path=source_file_path))
        return False

    command_line = "zip -j -0u -g %s %s" % (zip_archive_path, source_file_path)
    executor = Executor()
    execution_result = executor.execute_cmd(command_line)

    if execution_result.get_return_code() != 0:
        logger("ERROR","Unable to add file to {zip_archive_path} \nError : {detail}".format(zip_archive_path=zip_archive_path, detail=execution_result.get_detail()))
        return False
    else:
        # Remove tar.gz.enc file once adding to zip is successful
        executor.execute_cmd("rm -rf {source_file_path}".format(source_file_path=source_file_path))
        return True


def get_date_from_backup_id(backup_id, output_format="%Y-%m-%d"):
    """
    Get the date from backupID
    :param backup_id: Backup ID
    :type backup_id: str
    :param output_format: The output format of date
    :type output_format: str
    :return: string representation of date
    :rtype: str
    """
    from datetime import datetime
    if not backup_id:
        date = datetime.utcnow().strftime(output_format)
    else:
        date = datetime.utcfromtimestamp(int(backup_id) / 1000.0).strftime(output_format)
    return str(date)

def getdiskFreeSpace(path, volume="backup"):
    """
    Gets free space on the disk
    """
    import os
    logger("INFO","Getting free disk space on {volume} volume.".format(volume=volume))
    st = os.statvfs(path)
    free = st.f_bavail * st.f_frsize
    return free

def getDirSize(folder,excludes=[],operation="backup"):
    """
    Gets the size of a specified directory
    """
    import re
    import fnmatch
    import os
    import socket

    logger("INFO","Getting data size for {operation}.".format(operation=operation))
    total_size = os.path.getsize(folder)
    excludes = r'|'.join([fnmatch.translate(x) for x in excludes]) or r'$.'
    names = [f for f in os.listdir(folder) if not re.match(excludes, f)]
    for item in names:
        itempath = os.path.join(folder, item)
        if os.path.isfile(itempath):
            total_size += os.path.getsize(itempath)
        elif os.path.isdir(itempath):
            total_size += getDirSize(itempath,operation=operation)
    return total_size



    #excludes = [ 'ib_logfile*', socket.gethostname() + '*', 'ibtmp*', 'undo*' ]
    #excludes = r'|'.join([fnmatch.translate(x) for x in excludes]) or r'$.'
    #total_size = 0
    #seen = {}
    #for dirpath, dirnames, filenames in os.walk(path):
    #   print dirpath
    #   print dirnames
    #   print 'I am outer'
    #   filenames = [f for f in filenames if not re.match(excludes, f)]
    #   for f in filenames:
    #       fp = os.path.join(dirpath, f)
    #       try:
    #           stat = os.stat(fp)
    #       except OSError:
    #           continue
    #
    #       try:
    #           seen[stat.st_ino]
    #       except KeyError:
    #           seen[stat.st_ino] = True
    #       else:
    #           continue
    #       total_size += stat.st_size
    #       print 'I am inner'
    #   return total_size

def delBinLogFromRestoredDir(src):
    """
    Deletes binary log files from restored log directory.
    All the files staring with hostname and with extension .[digit]* are considered binary log files.
    """

    import os
    import shutil
    import re
    import socket

    logger("INFO","Executing delBinLogFromRestoredDir(), will delete binary logs from restored directory.")
    #list of files to be copie
    host =  socket.gethostname()
    files_to_delete=filter(lambda name: name.startswith(host),
                         filter(lambda name: os.path.isfile(os.path.join(src, name)),
                               (os.listdir(src))))
    regex = re.compile(r'\.\d')
    files_to_delete =  [file for file in files_to_delete if regex.search(file) or file.endswith('.index')]
    #delete files
    for file in files_to_delete:
        file_full_path = os.path.join(src, file)
        logger("INFO","Removing file " + file_full_path)
        try:
           os.remove(file_full_path)
        except OSError as e:
           logger("INFO","Unable to remove binary log file {logfile}.".format(logfile=file_full_path))

    logger("INFO","Finished executing delBinLogFromRestoredDir().")


def copyBinLogToRestoredDir(src, dest): 
    """
    Copies binary log files from source to destination directory.
    All the files staring with hostname and with extension .[digit]* are considered binary log files. 
    """

    import os
    import shutil
    import re
    import socket

    logger("INFO","Executing copyBinLogToRestoredDir(), will copy binary logs from current data directory to restored directory {newdir}.".format(newdir=dest))
    #list of files to be copie
    host =  socket.gethostname()
    files_to_copy=filter(lambda name: name.startswith(host),
                         filter(lambda name: os.path.isfile(os.path.join(src, name)),
                               (os.listdir(src))))
    regex = re.compile(r'\.\d')
    files_to_copy =  [file for file in files_to_copy if regex.search(file) or file.endswith('.index')]
    #copy files
    for file in files_to_copy:
        logger("INFO","Copying file " + os.path.join(src, file))
	try:
	   shutil.copy(os.path.join(src, file), os.path.join(dest, file))
	except shutil.Error as e:
	   pass
  	except IOError as e:
           pass
    logger("INFO","Finished executing copyBinLogToRestoredDir().")

def getBackupMetaData(backupDir):
    """
    Function parses backup_content.xml and return a BackupMetadata bean.
    Return:
       rtype:BackupMetadata, OperationReturnObj
    """
    import os
    import constants
    import xml.sax

    op_return_obj = OperationReturnObj()
    op_return_obj.set_bool_status(True)

    #initialize
    backupMetaData = BackupMetaData()
    backupMetaFile = os.path.join(backupDir, constants.BACKUP_CONTENT_XML) #'meta/backup_content.xml'

    #make sure it is a valid backup directory
    if not os.path.isfile(backupMetaFile):
       logger("ERROR", " Metadata file {file} not found.".format(file=backupMetaFile))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20705>: Metadata file not found.")
       return None, op_return_obj

    try:
         # create an XMLReader
         parser = xml.sax.make_parser()
         # turn off namepsaces
         parser.setFeature(xml.sax.handler.feature_namespaces, 0)

         # override the default ContextHandler
         handler = BackupContentHandler()
         parser.setContentHandler( handler )

         #valid backup directory continue with xml parsing
         parser.parse(backupMetaFile)
    except xml.sax.SAXParseException, e:
         logger("ERROR", "Metadata XML {backupcontent} parsing error : {error}".format(backupcontent=backupMetaFile,error=e))
         op_return_obj.set_bool_status(False)
         op_return_obj.set_status_msg("<MSCS-ERR-20706>: Metadata XML parsing error.")
         return None, op_return_obj

    backupMetaData.setStartTime(getEpoch(handler.getStartTime(),"%Y-%m-%d %H:%M:%S",localTime=True))
    backupMetaData.setEndTime(getEpoch(handler.getEndTime(),"%Y-%m-%d %H:%M:%S",localTime=True))
    backupMetaData.setBinLogFile(handler.getBinLogFile())
    backupMetaData.setBinLogPos(handler.getBinLogPos())
    backupMetaData.setStartLSN(int(handler.getStartLSN()))
    backupMetaData.setEndLSN(int(handler.getEndLSN()))

    return backupMetaData, op_return_obj

def getEpoch(dateTime,dateTimeFormat,localTime=False):
    """
    Returns the epoch for the date passed in.
    If localTime is true the date passed will be considered localtime.
    if localTime is false (default) the time passed in is considered in GMT.
    """
    if localTime:
       epoch = int(time.mktime(time.strptime(dateTime,"{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat))))
    else:
       epoch = int(calendar.timegm(time.strptime(dateTime,"{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat))))

    return epoch

def getDateFromEpoch(epoch,dateTimeFormat,localTime=False):
    """
    Returns the date in the format passed for the epoch
    If localTime is true the time retured will be for local timezone
    if localTime is false the time retured will be for UTC
    """
    if localTime:
       dateTime=time.strftime("{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat), time.localtime(epoch))
    else:   
       dateTime=time.strftime("{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat), time.gmtime(epoch))
    return dateTime

class BackupMetaData:
    """
    Class encapsulates the backup metadata
    """
    def __init__(self, backup_type=None, backup_image=None, backup_start_epoch=None, backup_end_epoch=None, start_lsn=None, end_lsn=None,binlog_file=None, binlog_pos=None, backup_storage_uri=None):
        self.backup_type=backup_type
        self.backup_image=backup_image
        self.backup_storage_uri=backup_storage_uri
        self.backup_start_epoch=backup_start_epoch
        self.backup_end_epoch=backup_start_epoch
        self.start_lsn=start_lsn
        self.end_lsn=end_lsn
        self.binlog_file=binlog_file
        self.binlog_pos=binlog_pos

    def getBackupType(self):
        return self.backup_type

    def getBackupImage(self):
        return self.backup_image

    def getBackupStorageURI(self):
        return self.backup_storage_uri

    def getStartTime(self):
        return self.backup_start_epoch

    def getEndTime(self):
        return self.backup_end_epoch

    def getStartLSN(self):
        return self.start_lsn

    def getEndLSN(self):
        return self.end_lsn

    def getBinLogFile(self):
        return self.binlog_file

    def getBinLogPos(self):
        return self.binlog_pos

    def setBackupType(self, backup_type):
        self.backup_type=backup_type

    def setBackupImage(self, backup_image):
        self.backup_image=backup_image

    def setBackupStorageURI(self, backup_storage_uri):
        self.backup_storage_uri=backup_storage_uri

    def setStartTime(self,start_epoch):
        self.backup_start_epoch=start_epoch

    def setEndTime(self, end_epoch):
        self.backup_end_epoch=end_epoch

    def setStartLSN(self, start_lsn):
        self.start_lsn=start_lsn

    def setEndLSN(self, end_lsn):
        self.end_lsn=end_lsn

    def setBinLogFile(self, binlog_file):
        self.binlog_file=binlog_file

    def setBinLogPos(self, binlog_pos):
        self.binlog_pos=binlog_pos


class BackupContentHandler (xml.sax.ContentHandler):
    """
    A specialized class of xml.sax.ContentHandler for parsing backup_content.xml generated by MEB during backup.
    """
    def __init__(self):
        self.CurrentData = ""
        self.start_time = ""
        self.end_time = ""
        self.start_lsn = ""
        self.end_lsn = ""
        self.binlog_file = ""
        self.binlog_pos = ""

    # Call when an element starts
    def startElement(self, tag, attributes):
        self.CurrentData = tag

    # Call when an elements ends
    def endElement(self, tag):
        self.CurrentData = ""

    # Call when a character is read
    def characters(self, content):
        if self.CurrentData == "start_time":
           self.start_time = self.start_time + content
        elif self.CurrentData == "end_time":
           self.end_time = self.end_time + content
        elif self.CurrentData == "start_lsn":
           self.start_lsn = self.start_lsn + content
        elif self.CurrentData == "end_lsn":
           self.end_lsn = self.end_lsn + content
        elif self.CurrentData == "binlog_file":
           self.binlog_file = self.binlog_file + content
        elif self.CurrentData == "binlog_pos":
           self.binlog_pos = self.binlog_pos + content 

    def getStartTime(self):
        return self.start_time

    def getEndTime(self):
        return self.end_time

    def getStartLSN(self):
        return self.start_lsn

    def getEndLSN(self):
        return self.end_lsn

    def getBinLogFile(self):
        return self.binlog_file

    def getBinLogPos(self):
        return self.binlog_pos


class OperationReturnObj:
    def __init__(self):
        self.status = True
        self.status_message = ""
        self.error_type = ""
        pass

    def set_bool_status(self, status):
        self.status = status

    def get_bool_status(self):
        return self.status

    def set_status_msg(self, status_message):
        self.status_message = status_message

    def get_status_msg(self):
        return self.status_message

    def get_error_type(self):
        return self.error_type

    def set_error_type(self, error_type):
        self.error_type = error_type

    def append_status_msg(self, message):
        self.status_message = "{current_msg} {message}".format(current_msg=self.status_message, message=message)


class JSONUtil:
    import json

    def __init__(self):
        pass

    @staticmethod
    def decode_from_json_str(json_str):
        """
        Decode json string to Dict
        :param json_str:
        :return:
        :rtype: dict
        """
        try:
            decoder = JSONUtil.json.JSONDecoder()
            return decoder.decode(json_str)
        except Exception as e:
            logger("ERROR",str(e))
            return None

    @staticmethod
    def encode_to_json_str(dictionary):
        """
        Encode dictionary to json string
        :param dictionary:
        :return:
        :rtype: str
        """
        try:
            encoder = JSONUtil.json.JSONEncoder()
            return encoder.encode(dictionary)
        except Exception as e:
            logger("ERROR",str(e))
            return None

    @staticmethod
    def get_value_from_dict(dictionary, key):
        """
        Return the value of a specified key in json_args. Return empty str if key does not exist
        :param dictionary:
        :param key:
        :return:
        """
        try:
            return dictionary[key]
        except KeyError:
            return ""

    @staticmethod
    def print_dict_as_json(dictionary):
        try:
            print JSONUtil.json.dumps(dictionary, indent=4)
        except Exception as e:
            logger("ERROR",str(e))


class Executor:
    import subprocess
    import threading
    import socket

    def __init__(self):
        self.command = None
        self.std_in = None
        self.env = None
        self.process = None
        self.return_code = None
        self.std_out = None
        self.std_err = None

    def execute_scp(self, source, target, if_print=True, stdin=None, retry_count=0,
                    successful_return_code_list=None, env=None, cmd_timeout=None):
        import constants

        command_line = "scp {scp_options} {source} {target}".format(scp_options=constants.SCP_OPTIONS, source=source,
                                                                    target=target)
        return self.execute_cmd(command_line,
                                if_print=if_print,
                                stdin=stdin,
                                retry_count=retry_count,
                                successful_return_code_list=successful_return_code_list,
                                env=env,
                                cmd_timeout=cmd_timeout)

    def execute_cmd(self, commandline, command_for_print=None, host=None, if_print=True, stdin=None, retry_count=0,
                    successful_return_code_list=None, env=None, cmd_timeout=None):
        from datetime import datetime
        import time
        import socket
        import constants

        start = datetime.now()
        counter = 0
        cmd_execution_result = None

        if host and host != socket.gethostname():
            # On remote host
            commandline = "ssh {host} {ssh_option} '{command_line}'".format(host=host, ssh_option=constants.SSH_OPTIONS,
                                                                            command_line=commandline)

        successful_return_code_list = [0] if not successful_return_code_list else successful_return_code_list

        while counter <= int(retry_count):
            cmd_execution_result = self.__execute_impl__(commandline, stdin, env, cmd_timeout)
            return_code = cmd_execution_result.get_return_code()

            if return_code in successful_return_code_list:
                if return_code != 0:
                    logger("INFO","command returns status code: {return_code}".format(return_code=return_code))
                break
            if counter == int(retry_count):
                break
            logger("INFO","Retry in 10s..")
            time.sleep(10)  # Sleep 10 secs before retry

            counter += 1

        end = datetime.now()
        duration = end - start
        duration = duration.seconds * 1000 + duration.microseconds / 1000.0

        # After execution, replace user credential for output printing
        if if_print:
            logger("INFO","Executed command with status {return_code} in {milliseconds} milliseconds [ {command_line} ] "\
                .format(
                    return_code=cmd_execution_result.get_return_code() if cmd_execution_result else "None",
                    milliseconds=str(duration),
                    command_line=commandline if not command_for_print else command_for_print
                ))

        # Close the pipe
        self.close()

        return cmd_execution_result

    def __execute_impl__(self, command_line, std_in, env, timeout):
        """
        Execute command in another thread and terminate on timeout
        :param timeout:
        :return:
        """
        # Set the stdout, stderr and return_code to None. This will allow retries to start over
        self.std_out = None
        self.std_err = None
        self.return_code = None

        # Inner function to be invoke by python threading
        def run_command():
            self.process = self.subprocess.Popen(command_line,
                                                 shell=True,
                                                 stdout=self.subprocess.PIPE,
                                                 stdin=self.subprocess.PIPE,
                                                 stderr=self.subprocess.PIPE,
                                                 env=env)
            (self.std_out, self.std_err) = self.process.communicate(std_in)
            self.return_code = self.process.returncode

        thread = self.threading.Thread(target=run_command)
        # set daemon to be true which tells thread that it is ok to be terminated if subprocess is terminated
        thread.daemon = True
        thread.start()

        # set the timeout
        thread.join(timeout)

        # if thread is still alive after timeout, then kill subprocess
        if thread.isAlive():
            self.process.terminate()

        # self.std_out, self.std_err and self.return_code could be None since we terminate process on timeout
        if self.std_out is None:
            self.std_out = ""
        if self.std_err is None:
            self.std_err = "Command timed out after %s seconds: %s" % (timeout, command_line)
        if self.return_code is None:
            # -15 is the terminate signal in subprocess
            self.return_code = "-15"

        cmd_execution_result = CMDExecutionResultClass()
        cmd_execution_result.set_return_code(self.return_code)
        cmd_execution_result.set_std_out(self.std_out)
        cmd_execution_result.set_std_err(self.std_err)

        return cmd_execution_result

    def close(self):
        """
        Close subprocess pipe after execution
        :return:
        """
        if self.process:
            self.process.stdout.close()
            self.process.stdin.close()


class CMDExecutionResultClass:
    def __init__(self):
        self.exit_code = 0
        self.std_out = None
        self.std_err = None

    def set_return_code(self, exit_code):
        self.exit_code = exit_code

    def get_return_code(self):
        return self.exit_code

    def set_std_out(self, std_out):
        self.std_out = std_out

    def get_std_out(self):
        return self.std_out

    def set_std_err(self, std_err):
        self.std_err = std_err

    def get_std_err(self):
        return self.std_err

    def get_detail(self):
        return (self.std_out + self.std_err).strip()

### borrowed from python script belonging to platform team
def do_request(url, credential, method, data, headers, timeout=600, request_headers_to_hide=None, response_headers_to_hide=None):
    """
    The urllib2 implementation to send the http/https request to server, and get response.
    :param url: the url where to send the request to
    :type url: str
    :param method: PUT, GET, DELETE
    :type method: str
    :param data: the data send to server
    :type data: str
    :param credential:
    :type credential: str
    :param headers: the headers added to the request
    :type headers: dict
    :param timeout: the timeout for the request
    :type timeout: int
    :param request_headers_to_hide: a list of sensitive request headers to hide from logging
    :type request_headers_to_hide: list
    :param response_headers_to_hide: a list of sensitive response headers to hide from logging
    :type response_headers_to_hide: list
    :return:
    :rtype: UrllibHttpResponseHandler
    """

    """
    IMPORTANT: The following status codes are customized, it is not in HTTP Status Code Definitions
    418: Host cannot be resolved
    999: Exception
    """
    import urllib2
    import json
    import traceback
    import socket

    # List is mutable data type, the following way is better than put list directly into default arg value
    if not request_headers_to_hide:
        request_headers_to_hide = ["Authorization"]
    if not response_headers_to_hide:
        response_headers_to_hide = []

    response_wrapper_class = UrllibHttpResponseHandler()

    try:
        if data:
            request = urllib2.Request(url, data)
        else:
            request = urllib2.Request(url)

        request.get_method = lambda: method

        if credential:
            request.add_header("Authorization", "Basic " + credential.encode("base64").strip().replace("\n", ""))

        if headers:
            for header_key in headers.keys():
                request.add_header(header_key, headers[header_key])

        request_headers = dict(request.headers)
        for header in request_headers_to_hide:
            if header in request_headers:
                request_headers[header] = "******"

        logger("INFO","Request URL: %s" % str(request.get_full_url()))
        logger("INFO","Request Method: %s" % str(request.get_method()))
        logger("INFO","Request Headers: \n%s" % json.dumps(request_headers, indent=4))

        response = urllib2.urlopen(request, timeout=int(timeout))

        response_wrapper_class.set_http_code(response.getcode())
        response_wrapper_class.set_http_response(response)

        response_headers = dict(response.info())
        for header in response_headers_to_hide:
            if str(header).lower() in response_headers:
                response_headers[header] = "******"

        logger("INFO","Response URL: %s" % str(response.geturl()))
        logger("INFO","Response Headers:\n%s" % json.dumps(response_headers, indent=4))

    except urllib2.HTTPError as e:
        http_code = str(e.code)

        response_wrapper_class.set_http_code(http_code)
        response_wrapper_class.set_message(str(e))

        response_headers = dict(e.info())
        for header in response_headers_to_hide:
            if header in response_headers:
                response_headers[header] = "******"
        print "urllib2.HTTPError"
        logger("INFO",response_wrapper_class.get_message())
        logger("INFO","Response URL: %s" % e.geturl())
        logger("INFO","Response Headers:\n%s" % json.dumps(response_headers, indent=4))

    except urllib2.URLError as e:
        # For Python 2.6 to handle the timeout
        if isinstance(e.reason, socket.timeout):
            response_wrapper_class.set_http_code(408)
        else:
            response_wrapper_class.set_http_code(418)

        response_wrapper_class.set_message(str(e))
        print "urllib2.URLError"

    except ssl.SSLError as e:
        response_wrapper_class.set_http_code(419)
        response_wrapper_class.set_message(str(e))
        print "ssl.SSLError"
    except Exception as e:
        traceback_msg = traceback.format_exc()
        logger("ERROR",traceback_msg)
        response_wrapper_class.set_http_code(999)
        response_wrapper_class.set_message(str(e))
        print "Exception"
    finally:
        return response_wrapper_class


### borrowed from python script belonging to platform team
class UrllibHttpResponseHandler:
    """
    Class which handles the response from urllib2 request

    Members:
        http_code: the http code returned from server
        http_response: the response object returned from Urllib2 request
        message: the message to be returned to caller
    """

    def __init__(self, http_code=None, http_response=None, message=None):
        self.http_code = http_code
        self.http_response = http_response
        self.message = message

    def set_http_code(self, http_code):
        self.http_code = int(http_code)

    def get_http_code(self):
        return self.http_code

    def set_http_response(self, http_response):
        self.http_response = http_response

    def get_http_response(self):
        return self.http_response

    def set_message(self, message):
        self.message = message

    def get_message(self):
        return self.message


def decode_secure_params(input_dict_args):
    """
    Decode secureparameters passed.

    decode input secure parameters 
    and put parmeters in SM_OPERATIONINFO.
    """
    import base64
    import json
    if input_dict_args.has_key("SM_SENSITIVE_DATA"):
        try: 
            encoded_string = input_dict_args["SM_SENSITIVE_DATA"]['encodedString']
            cred_info = base64.b64decode(encoded_string)
            #print "cred _info " + cred_info
            cred_info_json = json.loads(cred_info)
            #print "cred _info _json" + cred_info_json
            password = cred_info_json['SCRIPT_SECURE_PARAMETERS'].get('cloudStoragePassword')
            user_name = cred_info_json['SCRIPT_SECURE_PARAMETERS'].get('cloudStorageUser')
            print user_name 
            input_dict_args['SM_OPERATION_INFO']['cloudStorageUser'] = user_name
            input_dict_args['SM_OPERATION_INFO']['cloudStoragePassword'] = password
            input_dict_args["SM_SENSITIVE_DATA"]['encodedString'] = 'XXXXXXXXX'
        except Exception, e:
            logger("ERROR", "error in decoding sensitive parameters")
            raise Exception("error in decoding sensitive parameters"+str(e))
    else:
        logger("Warninig", "SM_SENSITIVE_DATA not found")
    return input_dict_args




