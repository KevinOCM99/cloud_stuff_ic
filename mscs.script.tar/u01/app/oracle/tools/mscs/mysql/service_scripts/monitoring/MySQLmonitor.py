import random
import json
import sys
import datetime
import time
import socket
import subprocess
import os

#set path for the scripts
tools_path=os.path.realpath(__file__)
script_utils=tools_path[:tools_path.index("service_scripts")] + "service_scripts/monitoring/utils.sh"
mysql_install_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"

#command mapping
commandMap={
      "Machine_CPU_Utilization":{
                                  "command":"source {script_utils} && getCpuUtilization".format(script_utils=script_utils),
                                  "errorMessage":"Unable to get the CPU utilization"
                                },
      "Data_Volume_Utilization":{
                                  "command":"source {script_utils} && getDataVolumeFree".format(script_utils=script_utils),
                                  "errorMessage":"Unable to get the Data Volume utilization"
                                },
      "TRANSLOG_VOLUME_Utilization":{
                                  "command":"source {script_utils} && getTransLogVolumeUtilization".format(script_utils=script_utils),
                                  "errorMessage":"Unable to get the Translog volume utilization"
                                    },
      "Machine_Free_Memory":{
                                 "command":"source {script_utils} && getFreeMemory".format(script_utils=script_utils),
                                 "errorMessage":"Unable to get the free memory"
                            },
      "MySQL_Requests_Per_Sec":{
                                 "command":"source {script_utils} && getQueriesPerSecond".format(script_utils=script_utils),
                                 "errorMessage":"MySQL Server is down, unable to get the query per seconds stat"
                               },
      "MySQL_UpTime_Sec":{
                                 "command":"source {script_utils} && getMySQLUpTime".format(script_utils=script_utils),
                                 "errorMessage":"MySQL Server is down, unable to get the uptime"
                         },
      "MySQL_Open_Connections":{
                                 "command":"source {script_utils} && getOpenConnections".format(script_utils=script_utils),
                                 "errorMessage":"MySQL Server is down, unable to get the number of open connections"
                               },
      "SERVER:Status":{
                                 "command":"source {mysql_install_script} && getMysqlStatus oracle".format(mysql_install_script=mysql_install_script),
                                 "errorMessage":"MySQL Server is down"
                      },
      "SERVICE:Status":{
                                 "command":"source {script_utils} && getMySQLStatus oracle".format(script_utils=script_utils),
                                 "errorMessage":"MySQL Server is down"
                       }
}

#blocking call
def call(command, args=None):
    if args:
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(command)
    else:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = process.communicate()

    if not stdout:
        stdout = stderr
    return  process.returncode, stdout

#call the command and record result
def run(command, host='localhost', remoteSSHRetries=5, sleepBetweenRemoteSSHRetries=1):
    startps = time.time();
    hostname=socket.gethostname()
    if host.lower() == hostname.lower() or host.lower() == 'localhost':
        # the command needs to be run locally
        status, stdout = call(command)
    else:
        # the command needs to be run on remote VM.
        import shlex
        remote_command = "ssh -T -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
        args = shlex.split(remote_command)
        args.append(host)

        for iteration in range(remoteSSHRetries):
            # run the command on remote VM and watch out for network related mishaps
            status, stdout = call(command, args=args)
            if "ssh: Could not resolve hostname" in stdout:
                time.sleep(sleepBetweenRemoteSSHRetries)
            else:
                break
        command = "{0} \"{1}\"".format(remote_command, command)
    return status, stdout


def getVMmetric(vmName,vmIP,vmMetric):
    status,stdout = run(commandMap[vmMetric]['command'])
    if status == 0:
       return {"Status":"Success","time":getGMT(),"data":{"value":stdout}}

    return {"Status":"Failure","time":getGMT(),"failure":{"code":500,"message":commandMap[vmMetric]['errorMessage']}}

def getSERVERmetric(serverName,serverType,serverMetric):
    status,stdout = run(commandMap[serverMetric]['command'])
    if status == 0:
       if serverMetric == 'SERVER:Status':
          return {"Status":"Success","time":getGMT(),"data":{"value":"UP"}}
       return {"Status":"Success","time":getGMT(),"data":{"value":stdout}}

    return {"Status":"Failure","time":getGMT(),"failure":{"code":501,"message":commandMap[serverMetric]['errorMessage']}}

def getComputeServiceMetric(svcMetric):
    status,stdout = run(commandMap[svcMetric]['command'])
    if status == 0:
       return {"Status":"Success","time":getGMT(),"data":{"value":"UP"}}
    else:
       RETURN_JSON={"Status":"Success","time":getGMT(),"data":{"value":"DOWN"}} if "Check that mysqld is running" in stdout else {"Status":"Success","time":getGMT(),"data":{"value":"ERROR"}}
       return RETURN_JSON

def getGMT():
    utc= datetime.datetime.utcnow()
    return str(utc.date())+"T"+str(utc.time())[:-3]+"+00:00"

def execute(data):
    VMmetrics=["Machine_CPU_Utilization","Machine_Free_Memory","Data_Volume_Utilization","TRANSLOG_VOLUME_Utilization"]
    SERVERmetrics=["SERVER:Status","MySQL_Requests_Per_Sec","MySQL_UpTime_Sec","MySQL_Open_Connections"]
    ServiceMetrics=["SERVICE:Status"]

    sm_service_info = data['SM_SERVICE_INFO']
    sm_operation_info = data['SM_OPERATION_INFO']
    output={}
    sm_execution_result={}

    output['status']="Success"
    output['statusMessage']="Monitoring was successful"

    sm_execution_result['domainName'] = sm_service_info['domainName']
    sm_execution_result['serviceType'] = sm_service_info['serviceType']
    sm_execution_result['serviceName'] = sm_service_info['serviceName']

    sm_execution_result['components'] = {}

    sm_execution_result['components'][sm_operation_info['componentName']] = {}
    sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'] = {}

    for VM, vmValue in sm_service_info['components'][sm_operation_info['componentName']]['vmInstances'].iteritems():
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM] = {}
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['servers'] = {}
        for SERVER, serverValue in vmValue['servers'].iteritems():
            sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['servers'][SERVER] = {}

    for SIBCOMP, sibCompValue in sm_operation_info['siblingComponentsExecutionContext'].iteritems():
       sm_execution_result['components'][SIBCOMP] = {}
       sm_execution_result['components'][SIBCOMP]['vmInstances'] = {}
       for VM, vmValue in sm_service_info['components'][SIBCOMP]['vmInstances'].iteritems():
            sm_execution_result['components'][SIBCOMP]['vmInstances'][VM] = {}
            sm_execution_result['components'][SIBCOMP]['vmInstances'][VM]['servers'] = {}
            for SERVER, serverValue in vmValue['servers'].iteritems():
                sm_execution_result['components'][SIBCOMP]['vmInstances'][VM]['servers'][SERVER] = {}

    serverCount=0
    for VM, value in data['SM_SERVICE_INFO']['components'][sm_operation_info['componentName']]['vmInstances'].iteritems():
        serverCount+=len(value['servers'])

    for VM, vmValue in sm_service_info['components'][sm_operation_info['componentName']]['vmInstances'].iteritems():
        metrics=[]
        metric={}
        for VMmetric in VMmetrics:
            response=getVMmetric(VM,vmValue['ipAddress'],VMmetric)
            metric['healthCheckName']=VMmetric
            metric['Status']=response['Status']
            if metric['Status']=="Success":
                metric['data']=response['data']
                if "failure" in metric:
                    del metric['failure']
            else:
                metric['failure']=response['failure']
                if "data" in metric:
                    del metric['data']
            metric['time']=response['time']

            metrics.append(metric.copy())
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['healthData']={}
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['healthData']['healthValues']=metrics

        for SERVER, serverValue in vmValue['servers'].iteritems():
            metrics=[]
            metric={}
            for SERVERmetric in SERVERmetrics:
                response=getSERVERmetric(SERVER,serverValue['serverType'],SERVERmetric)
                metric['healthCheckName']=SERVERmetric
                metric['Status']=response['Status']
                if metric['Status']=="Success":
                    metric['data']=response['data']
                    if "failure" in metric:
                        del metric['failure']
                else:
                    metric['failure']=response['failure']
                    if "data" in metric:
                        del metric['data']
                metric['time']=response['time']
                metrics.append(metric.copy())
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['servers'][SERVER]['healthData']={}
        sm_execution_result['components'][sm_operation_info['componentName']]['vmInstances'][VM]['servers'][SERVER]['healthData']['healthValues']=metrics

    metrics=[]
    metric={}
    for SvcMetric in ServiceMetrics:
        response=getComputeServiceMetric(SvcMetric)
        metric['healthCheckName']=SvcMetric
        metric['Status']=response['Status']
        if metric['Status']=="Success":
            metric['data']=response['data']
            if "failure" in metric:
                del metric['failure']
        else:
            metric['failure']=response['failure']
            if "data" in metric:
                del metric['data']
        metric['time']=response['time']
        metrics.append(metric.copy())
    sm_execution_result['healthData']={}
    sm_execution_result['healthData']['healthValues']=metrics

    output['SM_EXECUTION_RESULT']=sm_execution_result
    sys.stdout.write(json.dumps(output))
