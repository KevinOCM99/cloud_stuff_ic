# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.

import os, sys, subprocess, time, socket
import json
import logging

##A simple wrapper for SM to VM scripts execution
class ExecutionContext:
    #initialize patching context with json string params
    def __init__(self, jsonArgs):
        self.args = jsonArgs
        #each message in format of {message, timestamp} or {id, args, timestamp}
        self.progress={"messages": [], "timestamp": int(time.time() * 1000)}
        #{"args": {}, "commands":[], "messages": [], "failures": []} only left over messages or failures matter
        self.result  ={}

        standardLogger = logging.getLogger()
        standardLogger.setLevel(logging.DEBUG)

        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        standardLogger.addHandler(ch)


    #format a message
    def __toMessage(self, message, timestamp = 0):
        if timestamp <= 0:
            timestamp = int(time.time() * 1000);
        if type(message) is str:
            return  {"message": message, "timestamp": timestamp}
        if message.get("timestamp") is None:
            message["timestamp"] = timestamp

        return message;

    #stdout messages
    def logger(self, level, message):
        """
        logger prints the level and message to standard out
        """ 
        if level == 'PLAIN':
            print message
        else:
            print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()),
                                  level, message)


    #add a progress message, periodically refresh the last write if buffered
    def addMessage(self, message, timestamp = 0, flush=False):
        messages = self.progress.get("messages")
        if messages is None:
            messages = [];
            self.progress["messages"] = messages

        #append the message to li
        messages.append(self.__toMessage(message, timestamp));
        #flush progress message if it's been awhile ~ since 20 seconds
        diff = int(time.time() * 1000) - self.progress["timestamp"]
        if flush or diff >= 20000 or len(messages) < 10:
            #progress file is the same as .log file with .prog extension
            pf = os.open(self.args["REX_PROGRESS_FILE_PATH"], os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
            os.write(pf, json.dumps(self.progress, indent=4, sort_keys=True))
            os.fsync(pf)
            os.close(pf)

            #to avoid message lost, not pickup by SM, reset only if longer than 1000 seconds
            if len(messages) > 10000 or diff >= 1000000:
                self.progress["messages"] = messages[500:]

            #update last time
            self.progress["timestamp"] = int(time.time() * 1000);

    #failure is not a progress, but rather than final result
    def addFailure(self, message, timestamp = 0):
        self.addMessage(message)
        failures = self.result.get("failures")
        if failures is None:
            failures = [];
            self.result["failures"] = failures

        #append the message
        failures.append(self.__toMessage(message, timestamp));

    # function returns failure message
    def getFailure(self):
        try:
            failures = self.result.get("failures")
            return failures[-1].get("message")
        except:
            return "see activity log for details."

    #add command output with total processing time and status
    def addCommand(self, command, output, totalTime, status = 0):
        commands = self.result.get("commands")
        if commands is None:
            commands = [];
            self.result["commands"] = commands
        #add command with details
        commands.append({"command": command, "output": output, "totalTime": totalTime, "status": status})

    #finish the execution write json to stdout...details status such as SUCCESS_WITH_WARNING or SUCCESS...
    def exit(self, code=0, print_on_stdOut=1, message=None, status=None):
        #insert optional execution message
        if message is not None:
            self.result["statusMessage"] = message;
        if status is not None:
            self.result["status"] = status;

        #If still have progress message left over => merge over to the result messages
        messages = self.progress.get("messages")
        if messages:
            self.result["messages"] = messages;

        #append json args
        self.result["args"] = self.args;

        #Flush everything to stdout
        if print_on_stdOut == 0:
            sys.stdout.write("<JsonResult>")
            JSONUtil.print_dict_as_json(self.result)
            sys.stdout.write("</JsonResult>")

        return 0

##Simple shell command wrapper to execute command and add to the system
class ShellCommand:
    def __init__(self, context):
        self.context = context

    #blocking call
    def call(self, command, args=None):

        if args:
            process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate(command)
        else:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            stdout, stderr = process.communicate()

        if not stdout:
            stdout = stderr
        return  process.returncode, stdout

    #call the command and record result
    def run(self, command, host='localhost', remoteSSHRetries=5, sleepBetweenRemoteSSHRetries=1):
        startps = time.time();
        hostname=socket.gethostname()
        if host.lower() == hostname.lower() or host.lower() == 'localhost':
            # the command needs to be run locally
            status, stdout = self.call(command)
        else:
            # the command needs to be run on remote VM.
            import shlex
            remote_command = "ssh -T -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
            args = shlex.split(remote_command)
            args.append(host)

            for iteration in range(remoteSSHRetries):
                # run the command on remote VM and watch out for network related mishaps
                status, stdout = self.call(command, args=args)
                if "ssh: Could not resolve hostname" in stdout:
                    time.sleep(sleepBetweenRemoteSSHRetries)
                else:
                    break
            command = "{0} \"{1}\"".format(remote_command, command)
        self.context.addCommand(command, stdout, int(time.time() - startps), status)
        return status, stdout

##Example of patching context extension
class PatchingContext(ExecutionContext):
    def __init__(self, jsonArgs):
        ExecutionContext.__init__(self, jsonArgs)

     #return patch Id
    def getPatchId(self):
        return self.args['SM_OPERATION_INFO']["patchId"];

    #return bin dir
    def getBinDir(self):
        return self.args["binDir"];

    #return data dir
    def getDataDir(self):
        return self.args["dataDir"];

    #return backup dir
    def getBackupDir(self):
        return self.args["backupDir"];

    #return component Name
    def getComponentName(self):
        return self.args["componentName"];

    #return the list of vm's
    def getHosts(self, service_key):
        hosts = map(lambda x: x.lower(), self.args['SM_SERVICE_INFO']['components'][service_key]['vmInstances'])
        return hosts

    def getStorageURL(self):
        return self.args['SM_OPERATION_INFO']["storageURL"]

    def getStorageKey(self, serviceKey, component):
        return self.args['SM_OPERATION_INFO']["zipBundles"][serviceKey][component]["storageKey"]

    def getMd5sum(self, serviceKey, component):
        return self.args['SM_OPERATION_INFO']["zipBundles"][serviceKey][component]["md5sum"]

    def hasMd5sum(self, serviceKey, component):
        key="md5sum"
        if key in self.args['SM_OPERATION_INFO']["zipBundles"][serviceKey][component]:
            return True
        else:
            return False

    def getZipVersion(self,component,zip_component):
        return self.args['SM_OPERATION_INFO']["zipBundles"][component][zip_component]["zipVersion"]

    def getToolsRoot(self):
        return self.args['SM_SERVICE_INFO']['attributes']["_tools_root_"]

    def getCurrentVersion(self):
        return self.args['SM_SERVICE_INFO']["releaseVersion"]

    def getReleaseVersion(self,serviceKey):
        return self.args['SM_OPERATION_INFO']["zipBundles"][serviceKey]["componentReleaseVersion"]

## JSON UTILITIES
class JSONUtil:
    import json

    def __init__(self):
        pass

    @staticmethod
    def decode_from_json_str(json_str):
        """
        Decode json string to Dict
        :param json_str:
        :return:
        :rtype: dict
        """
        try:
            decoder = JSONUtil.json.JSONDecoder()
            return decoder.decode(json_str)
        except Exception as e:
            print str(e)
            return None

    @staticmethod
    def encode_to_json_str(dictionary):
        """
        Encode dictionary to json string
        :param dictionary:
        :return:
        :rtype: str
        """
        try:
            encoder = JSONUtil.json.JSONEncoder()
            return encoder.encode(dictionary)
        except Exception as e:
            print str(e)
            return None

    @staticmethod
    def get_value_from_dict(dictionary, key):
        """
        Return the value of a specified key in json_args. Return empty str if key does not exist
        :param dictionary:
        :param key:
        :return:
        """
        try:
            return dictionary[key]
        except KeyError:
            return ""

    @staticmethod
    def print_dict_as_json(dictionary):
        try:
            print JSONUtil.json.dumps(dictionary, indent=4)
        except Exception as e:
            print str(e)
