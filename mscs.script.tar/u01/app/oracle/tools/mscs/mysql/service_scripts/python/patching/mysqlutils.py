# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.

import json
import utils
import socket,time,datetime
import sys
import os
import shutil
import logging
import tarfile
import constants

class MysqlUtils(utils.Utils):
    service_key = constants.serviceKey
    component = constants.component

    def __init__(self, pcontext, shellcommand):
        self.pcontext = pcontext
        self.shellcommand = shellcommand
        utils.Utils.__init__(self,pcontext,shellcommand)

    def check_process(self,host='localhost'):
        """ function to return mysql server status
        returns success if mysql server is up
        returns failure if msyql server is not up
        """
        tools_path=os.path.realpath(__file__)
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Shell script path used for MySQL running status is : "+mysql_install_script)
        command = "source {mysql_install_script} && getMysqlStatus {sys_user}".format(mysql_install_script=mysql_install_script,sys_user=sys_user)
        self.patchlog("Command for MySQL running status : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status for the command run is : " +str(status) + ". The stdout says : " +str(stdout))
        if status == 0:
            return constants.SUCCESS
        else:
            return constants.FAILURE

    def getSpaceNeededInKB(self,artifactSize):
        self.patchlog("Running the function getSpaceNeededInKB()")
        extraspaceNeeded=1073741824
        aproximate_extracted_size=3221225472	
        spaceNeeded=aproximate_extracted_size+extraspaceNeeded
        self.patchlog("Exiting from the function getSpaceNeededInKB()")
        return spaceNeeded/1024

    def getSpaceAvailableInKB(self,bin_vol):
        self.patchlog("Running the function getSpaceAvailableInKB()")
        command = constants.space_availability_command
        self.patchlog("Running the command : "+command)
        status,stdout = self.shellcommand.run(command)
        self.patchlog("Exiting from the function getSpaceAvailableInKB()")
        return stdout

    def check_for_available_space(self,storageURL,cloudKey,host='localhost'):
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_provision_script")
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        self.patchlog("Got the path for mysql_provision_script : " +mysql_provision_script)
        command = "source {mysql_provision_script} && getArtifactSize {storageURL} {cloudKey}".format(mysql_provision_script=mysql_provision_script, storageURL=storageURL, cloudKey=cloudKey)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            spaceNeeded=self.getSpaceNeededInKB(stdout)
            self.patchlog("Space needed for the patching operation would be approximately : " +str(spaceNeeded) + "KB")
            spaceAvailable=self.getSpaceAvailableInKB(constants.BIN_HOME)
            self.patchlog("Space available in KB is : " +spaceAvailable)
            if int(spaceAvailable) < int(spaceNeeded):
                self.pcontext.addFailure("Not enough space available on \"" + constants.BIN_HOME +"\" for patching operation")
                self.patchlog("Not enough space available in \""+constants.BIN_HOME+"\" for patching operation,","ERROR")
                return constants.FAILURE
            else:
                self.patchlog("Enough space available on VM for patching")
                return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't get the size of MySQL artifact in cloud.")
            self.patchlog("Couldn't get the artifact size","ERROR")
            return constants.FAILURE

    def check_for_zipbundles_on_cloudstorage(self, mysqlStorageURL):
        self.patchlog("Running the function check_for_zipbundles_on_cloudstorage()")
        self.patchlog("Storage url chekcingfor is : " +mysqlStorageURL)
        status,binary_size = self.check_for_file_on_cloudstorage(mysqlStorageURL)
        self.patchlog("Status for the check for file on cloud storage is : " +str(status) + ". And the toral size on cloud is : "+str(binary_size))
        return status

    def startMySQL(self,host='localhost',mysql_arguments='',sleep_time=3,retry_count=20):
        self.pcontext.addMessage("Starting the MySQL server")
        self.patchlog("Starting the MySQL server")
        tools_path=os.path.realpath(__file__)
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Shell script path used for starting MySQL server is : "+mysql_install_script)
        command = "source {mysql_install_script} && startMysql {sys_user} {mysql_arguments}".format(mysql_install_script=mysql_install_script,sys_user=sys_user,mysql_arguments=mysql_arguments)
        self.patchlog("Command for starting MySQL server : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status for the command run is : " +str(status) + ". The stdout says : " +str(stdout))
        if status == 0:
            self.patchlog("Waiting for MySQL server to start in " +str(sleep_time*retry_count) +" seconds")
            command = "source {mysql_install_script} && waitForMysqlToStart {sleep_time} {retry_count} {sys_user}".format(mysql_install_script=mysql_install_script,sleep_time=sleep_time,retry_count=retry_count,sys_user=sys_user)
            self.patchlog("Waiting for MySQL server to start with the command : "+command)
            waitStatus,waitStdout = self.shellcommand.run(command,host)
            self.patchlog("Status for the command run is : " +str(waitStatus) + ". The stdout says : " +str(waitStdout))
            if waitStatus == 0:
                self.patchlog("MySQL server is running after bouncing: Verified")
                return constants.SUCCESS
            else:
                self.pcontext.addFailure("Failed to bringup Mysql. Waited for " +str(sleep_time*retry_count) +" seconds")
                self.patchlog("Failed to bringup Mysql. Waited for " +str(sleep_time*retry_count) +" seconds","ERROR")
                return constants.FAILURE
        else:
            self.pcontext.addFailure("Failed to restart MySQL")
            self.patchlog("Failed to restart MySQL", "ERROR")
            return constants.FAILURE


    def bounceMySQL(self,host='localhost', sleep_time=3,retry_count=4,pcontext=None ):
        """function bounces the mysql server and waits for server to come up
        returns 2 if mysql server is not up
        returns Failure if unable to bounce
        """
      
        # enable patch related log if patch context object is not none
        if pcontext != None:
            enable_patch_log=1
        else:
            enable_patch_log=0

        self.patchlog("Restarting the MySQL server")
        tools_path=os.path.realpath(__file__)
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Shell script path used for restarting MySQL server is : "+mysql_install_script)
        command = "source {mysql_install_script} && bounceMysql {sys_user}".format(mysql_install_script=mysql_install_script,sys_user=sys_user)
        self.patchlog("Command for bouncing MySQL server : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status for the command run is : " +str(status) + ". The stdout says : " +str(stdout))
        if status == 0:
            sleep_time=3
            retry_count=4
            if enable_patch_log == 1:
                self.patchlog("Waiting for MySQL server to start in " +str(sleep_time*retry_count) +" seconds")
            command = "source {mysql_install_script} && waitForMysqlToStart {sleep_time} {retry_count} {sys_user}".format(mysql_install_script=mysql_install_script,sleep_time=sleep_time,retry_count=retry_count,sys_user=sys_user)
            if enable_patch_log == 1:
                self.patchlog("Waiting for MySQL server to start with the command : "+command)
            waitStatus,waitStdout = self.shellcommand.run(command,host)
            if enable_patch_log == 1:
                self.patchlog("Status for the command run is : " +str(waitStatus) + ". The stdout says : " +str(waitStdout))
            if waitStatus == 0:
                if enable_patch_log == 1:
                    self.patchlog("MySQL server is running after bouncing: Verified")
                return constants.SUCCESS
            else:
                if enable_patch_log == 1:
                    pcontext.addFailure("Failed to bringup Mysql after restart. Waited for " +str(sleep_time*retry_count) +" seconds")
                    self.patchlog("Failed to bringup Mysql after restart. Waited for " +str(sleep_time*retry_count) +" seconds", "ERROR")
                return 2
        else:
            if enable_patch_log == 1:
                pcontext.addFailure("Failed to restart MySQL")
                self.patchlog("Failed to restart MySQL", "ERROR")
            return constants.FAILURE

    def extractZipArtifact(self,installer,extractLocation,host='localhost'):
        self.patchlog("Extracting the artifact : " +installer + " into " +extractLocation)
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_provision_script")
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Got the path for mysql_provision_script : " +mysql_provision_script)
        command = "source {mysql_provision_script} && extractZipArtifact {installer} {extractLocation} {sys_user}".format(mysql_provision_script=mysql_provision_script,installer=installer,extractLocation=extractLocation, sys_user=sys_user)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            self.patchlog("Successfully extracted the artifact : " +installer + " into " +extractLocation)
            return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't extract the artifacts")
            self.patchlog("Couldn't extract the artifacts", "ERROR")
            return constants.FAILURE

    def fetchArtifact(self,msaasInstaller,storageURL,cloudKey,md5sum='None',host='localhost'):
        self.patchlog("Fetching the artifacts from cloud")
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_provision_script")
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        self.patchlog("Got the path for mysql_provision_script : " +mysql_provision_script)
        command = "source {mysql_provision_script} && fetchArtifact {msaasInstaller}  {storageURL} {cloudKey}".format(mysql_provision_script=mysql_provision_script,msaasInstaller=msaasInstaller,storageURL=storageURL, cloudKey=cloudKey)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            command = "md5sum {msaasInstaller} | cut -d ' ' -f 1".format(msaasInstaller=msaasInstaller)
            self.patchlog("Running the command : " +command)
            status,stdout = self.shellcommand.run(command,host)
            self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
            md5sum_calculated=stdout.strip()
            self.patchlog("Md5sum calculated for downloaded artifact: "+md5sum_calculated)
            if md5sum != 'None':
                if md5sum_calculated == md5sum:
                    self.patchlog("Md5 sum of downloaded artifact: "+md5sum_calculated +" matches with original md5sum: "+md5sum, "INFO")
                else:
                    self.pcontext.addFailure("Md5sums didnt match")
                    self.patchlog("Md5 sum of downloaded artifact: "+md5sum_calculated +" doesnt match with original md5sum: "+md5sum, "ERROR")
                    return constants.FAILURE
            else:
                self.patchlog("No md5sum field with artifact, skipping md5sum check for downloaded artifact.")
            self.patchlog("Fetched the artifacts successfully from the cloud")
            return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't fetch the artifacts")
            self.patchlog("Couldn't fetch the artifacts", "ERROR")
            return constants.FAILURE

    def extractMysql(self,mysqlInstaller,releaseVersion,extractLocation,host='localhost'):
        self.pcontext.addMessage("Extracting MySQL new version")
        self.patchlog("Extracting MySQL new version")
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_install_script")
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Got the path for mysql_install_script : " +mysql_install_script)
        command = "source {mysql_provision_script} && source {mysql_install_script} && extractMysql {mysqlInstaller} {releaseVersion} {extractLocation} {sys_user}".format(mysql_provision_script=mysql_provision_script,mysql_install_script=mysql_install_script,mysqlInstaller=mysqlInstaller,releaseVersion=releaseVersion,extractLocation=extractLocation,sys_user=sys_user)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            self.patchlog("Successfully extracted MySQL binaries in bin_home")
            return stdout
        else:
            self.pcontext.addFailure("Couldn't extract the artifacts")
            self.patchlog("Couldn't extract the artifacts", "ERROR")
            return constants.FAILURE

    def shutdownMysql(self,host='localhost',clean_shutdown = 0):
        self.pcontext.addMessage("Shutting down MySQL")
        self.patchlog("Shutting down MySQL")
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_install_script")
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Got the path for mysql_install_script : " +mysql_install_script)
        command = "source {mysql_install_script} && shutdownMysql {sys_user} {clean_shutdown}".format(mysql_install_script=mysql_install_script,sys_user=sys_user, clean_shutdown=clean_shutdown)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            self.pcontext.addMessage("Successfully shutdown MySQL")
            self.patchlog("Successfully shut down MySQL")
            return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't extract the artifacts")
            self.patchlog("Couldn't extract the artifacts", "ERROR")
            return constants.FAILURE

    def removeDirectories(self,cleanup_objects=[],host='localhost'):
        for dir in cleanup_objects:
            try:
                self.patchlog( "Removing the directory "+dir)
                shutil.rmtree(dir)
                os.remove(dir)
            except Exception as ex:
                self.patchlog("WARNING", str(ex))

    def runMysqlUpgrade(self,base_dir,host='localhost',options=''):
        self.pcontext.addMessage("Running MySQL upgrade")
        self.patchlog("Running MySQL upgrade")
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_install_script")
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Got the path for mysql_install_script : " +mysql_install_script)
        command = "source {mysql_install_script} && runMysqlUpgrade {base_dir} {sys_user} {options}".format(mysql_install_script=mysql_install_script,base_dir=base_dir,sys_user=sys_user,options=options)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        if status == 0:
            self.pcontext.addMessage("Successfully upgraded MySQL")
            self.patchlog("Successfully upgraded MySQL")
            return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't upgrade MySQL")
            self.patchlog("Couldn't upgrade MySQL", "ERROR")
            return constants.FAILURE

    def changeSoftLink(self,link_name,old_loc,new_loc,host='localhost'):
        self.patchlog("Changing soft link from old MySQL dir to new MySQL dir")
        try:
            if os.path.islink(link_name):
                self.patchlog("Found link " + link_name)
                os.remove(link_name)
                self.patchlog("Deleted the link: "+link_name)
        except:
            self.patchlog("Failed to delete the link "+link_name)
            return constants.FAILURE
        try:
            os.symlink(new_loc, link_name)
        except Exception as ex:
            self.pcontext.addFailure("Couldn't change the soft link from " +old_loc +" to " +new_loc)
            self.patchlog("Couldn't change the soft link: "+link_name+" from " +old_loc +" to " +new_loc, "ERROR")
            return constants.FAILURE
        self.patchlog("Successfully changed the soft link "+link_name+" from " +old_loc +" to " +new_loc)
        return constants.SUCCESS

    def copyMysqlServerFile(self,base_dir,data_dir,host='localhost'):
        self.patchlog("Copying mysql.server in MySQL bin")
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_install_script")
        mysql_install_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_install_script_relative_path
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        self.patchlog("Got the path for mysql_install_script : " +mysql_install_script)
        command = "source {mysql_provision_script} && source {mysql_install_script} && copyMysqlServerFile {base_dir} {data_dir}".format(mysql_provision_script=mysql_provision_script,mysql_install_script=mysql_install_script,base_dir=base_dir,data_dir=data_dir)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            return constants.SUCCESS
        else:
            return constants.FAILURE

    def extractTarGzArtifact(self,mebInstaller,extractLocation,host='localhost'):
        self.patchlog("Extracting the "+mebInstaller +" in the location "+extractLocation)
        #cwd = os.getcwd()
        #try:
        #    tar = tarfile.open(mebInstaller)
        #    os.chdir(extractLocation)
        #    tar.extractall()
        #    tar.close()
        #except Exception as ex:
        #    self.pcontext.addFailure("Couldn't extract the MEB installer")
        #    self.patchlog("ERROR","Couldn't extract the MEB installer")
        #    return constants.FAILURE
        #finally:
        #    os.chdir(cwd)
        tools_path=os.path.realpath(__file__)
        self.patchlog("Getting the path of mysql_provision_script")
        mysql_provision_script=tools_path[:tools_path.index(constants.service_scripts_var)] + constants.mysql_provisioning_script_relative_path
        sys_user=constants.sys_user
        self.patchlog("Got the path for mysql_provision_script : " +mysql_provision_script)
        command = "source {mysql_provision_script} && extractTarGzArtifact {mebInstaller}  {extractLocation} {sys_user}".format(mysql_provision_script=mysql_provision_script,mebInstaller=mebInstaller,extractLocation=extractLocation, sys_user=sys_user)
        self.patchlog("Running the command : " +command)
        status,stdout = self.shellcommand.run(command,host)
        self.patchlog("Status code of the command run is : "+str(status) +".  And the stdout says : " +stdout)
        if status == 0:
            self.pcontext.addMessage("Successfully extracted the MEB installer")
            self.patchlog("Successfully extracted the MEB installer")
            return constants.SUCCESS
        else:
            self.pcontext.addFailure("Couldn't extract the MEB installer")
            self.patchlog("Couldn't extract the MEB installer", "ERROR")
            return constants.FAILURE

    def getMySQLHost(self):
        ret=self.getOrchestrationData('http://192.0.0.192/latest/attributes/serviceVM')
        mysql_host=''
        for i in ret:
            hostname=self.getOrchestrationData('http://192.0.0.192/latest/attributes/serviceVM/'+i+'/hostname')
            vmtype=self.getOrchestrationData('http://192.0.0.192/latest/attributes/serviceVM/'+i+'/type')
            if 'MYSQL_SERVER' in vmtype:
                mysql_host=hostname

        return mysql_host

    def getMySQLPort(self):
        return self.getOrchestrationData('http://192.0.0.192/latest/attributes/userdata/msaas_admin_port')

