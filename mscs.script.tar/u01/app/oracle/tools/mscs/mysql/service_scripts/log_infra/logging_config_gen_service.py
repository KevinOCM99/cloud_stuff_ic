#
# Confidential and Proprietary for Oracle Corporation
#
# This computer program contains valuable, confidential, and
# proprietary information.  Disclosure, use, or reproduction
# without the written authorization of Oracle is prohibited.
# This unpublished work by Oracle is protected by the laws
# of the United States and other countries.  If publication
# of this computer program should occur, the following notice
# shall apply:
#
# Copyright (c) 2016 Oracle Corp.
# All rights reserved.
#
# =========================================================================
# MySQL service log json generator script
# =========================================================================

import json
import sys
import urllib2
import socket

# json dictionary that contains data to have in json for each component type
_mysql_type = {
    "blueprintName": "MySQLCS",
    "logTypes": [
        {
            "pluginType": "file",
            "logType": "mysql_log",
            "paths": ["/u01/data/mysql/*.err"]
        }
    ]
}


def main():
    """Main funcion."""
    _service_json_location = None
    key = "artifacts/SERVICE_TOOLS"
    _service_component = fetch_attributes(key)
    # _service_component = None
    if len(sys.argv) > 1:
        _service_json_location = sys.argv[1]
    if len(sys.argv) > 2:
        _service_component = sys.argv[2]
    _service_json_content = gen_platform_json(_service_component.lower().strip())

    if _service_json_location is None:
        print 'Bad json location. Exiting!'
        return
    if _service_json_content is None:
        print 'Unkown type. Exiting!'
        return

    with open(_service_json_location, 'w') as outfile:
        json.dump(_service_json_content, outfile, indent=4, sort_keys=True, separators=(',', ':'))


def gen_platform_json(component):
    """
    Return the service JSON for the VM.
    Typically will figure out the service instance type for PSM VMs based on so
    me environment value.
    :return: the service json
    """
    if component == "mysql":
        return _mysql_type
    return None


def fetch_attributes(key):
    """Fetch system attributes."""
    attributes_url = "http://192.0.0.192/latest/attributes"
    url = attributes_url + "/" + key
    try:
        result = urllib2.urlopen(url, timeout=10).read()
    except urllib2.HTTPError as e:
        # traceback.print_exc()
        print('HTTPError occured while getting attribute: %s, error= %s' % (key, e))
        print url + " [LEAF]"
        return ""
    except urllib2.URLError as ue:
        # traceback.print_exc()
        print('UrlError occured while getting attribute: %s, error= %s' % (key, ue))
        return ""
    except socket.timeout, se:
        # For Python 2.7
        print('socket.timeout occured while getting attribute: %s, error= %s' % (key, se))
        return ""
    if len(result) == 0:
        print url + " [NO VALUE]"
        return ""

    print("attribute '" + key + "'=" + result)
    return result.strip()

if __name__ == "__main__":
    main()
