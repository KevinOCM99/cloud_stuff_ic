#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import time
import sys
import atexit
import os

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import restore
import msaas_common_lib as common_lib
import msaas_restore_precheck
import constants

from module_exe_util import ModuleExecutionReturnClass


module_exe_result = ModuleExecutionReturnClass()
module_exe_result.set_operation_type("restore")
restoreObj = None
backupObj = None


def main():
    """
    Validates the input JSON, if validation succeeds return do_restore function
    if validation fails return the OperationReturnObj
    Return:
     rtype : function do_restore
    """
    #parsing input JSON into a python dictionary
    op_return_obj = common_lib.OperationReturnObj()
    input_dict_args = common_lib.JSONUtil.decode_from_json_str(sys.argv[1])

    if not input_dict_args:
        common_lib.logger("ERROR","Invalid json argumentr, exiting restore operation")
        op_return_obj.set_bool_status(False)
        op_return_obj.append_status_msg("Exiting restore operation. Invalid JSON arguments...")
        return op_return_obj

    return do_restore(input_dict_args)


def execute(input_dict_args):
    """
    Generates a formated JSON dump to stdout anc calls do_restore. If do_restore succeeds this function returns "0", if not "1"
    The function also flushes the operation detail JSON to stdout to be consumed by the platform
    operation details are as follows:
    <JsonResult>{
    "status": "Success", 
    "SM_EXECUTION_RESULT": {
        "serviceType": <serviceType>, 
        "serviceName": <serviceName>, 
        "restoreDetails": {
            "restoredBackupImage": <image used for restore>, 
            "restoredHosts": [<hostname>...], 
            "notRestoredHosts": ""
        }
    }, 
    "statusMessage": " Restore health check passed... Restored hosts <hostname> ..."
    }
    </JsonResult>
    """
    import copy
    import shutil
    import time

    global module_exe_result
    #create a return object
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    
    common_lib.logger("INFO","Formated input JSON dump.")
    input_dict_args = common_lib.decode_secure_params(input_dict_args)
    #obfuscate password before dumping
    input_dict_args_for_print = copy.deepcopy(input_dict_args)
    #if input_dict_args_for_print.has_key('cloudStoragePassword'): 
    if input_dict_args_for_print.has_key('SM_OPERATION_INFO') and input_dict_args_for_print['SM_OPERATION_INFO'].has_key('cloudStoragePassword'):
       input_dict_args_for_print['SM_OPERATION_INFO']['cloudStoragePassword'] = 'XXXXXXXX'
    common_lib.JSONUtil.print_dict_as_json(input_dict_args_for_print)

    #set up service info
    service_info = input_dict_args.get(constants.SERVICE_INFO)
    if service_info:
       module_exe_result.set_service(service_info)

    restore_result = do_restore(input_dict_args)

    #intialize the backup sucess status
    backup_successful = False

    if restore_result.get_bool_status():
       common_lib.logger("INFO","")
       common_lib.logger("INFO","=================================================================")
       common_lib.logger("INFO","Starting Post Restore Backup")
       common_lib.logger("INFO","=================================================================")

       backup_result = do_backup(input_dict_args)
       if not backup_result.get_bool_status() and ( backupObj and backupObj.isCleanupRequired() ):
          backupObj.doCleanUp()

       #shutdown mysql
       common_lib.logger("INFO","Stopping MySQL.")
       stop_return_obj = restoreObj.stopMySQL()
       #if not return_obj.get_bool_status():
       #   op_return_obj.set_bool_status(return_obj.get_bool_status())
       #   op_return_obj.set_status_msg(return_obj.get_status_msg())

       if not backup_result.get_bool_status():
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg(backup_result.get_status_msg())
          op_return_obj.set_error_type(backup_result.get_error_type())
          common_lib.logger("ERROR","The backup initiated by the restore operation failed. Trying to switch to the old data directory.")
          switch_result = switch_directory(restoreObj.get_restoredDirectory() + '-tmp', restoreObj.get_restoreDirectory()) 
          if not switch_result.get_bool_status():
             op_return_obj.append_status_msg(switch_result.get_status_msg())             
          else:
              if restoreObj.get_restoreLogdir() != restoreObj.get_restoreDirectory():
                 switch_result = switch_directory(restoreObj.get_restoredLogdir() + '-tmp', restoreObj.get_restoreLogdir(),startMySQL=True)
                 if not switch_result.get_bool_status():
                    op_return_obj.append_status_msg(switch_result.get_status_msg())

       if backup_result.get_bool_status():
          op_return_obj.set_status_msg("<MSCS-INFO-20100>: Backup and backup image validation completed successfully.")

          common_lib.logger("INFO","The backup initiated by the restore operation succeeded.")

          #start mysql
          #wait for 10 seconds before attempting start
          time.sleep(10 )
          common_lib.logger("INFO", "Trying to start MySQL.")
          start_return_obj = restoreObj.startMySQL()
          for iter in range(1,6):
              if start_return_obj.get_bool_status():
                 common_lib.logger("INFO", "Started MySQL server.")
                 break
              common_lib.logger("INFO", "MySQL could not be started, will try again in %i seconds." % (iter * 10))
              time.sleep(iter * 10 )
              start_return_obj = restoreObj.startMySQL()

          #set backup as successful
          backup_successful = True

          common_lib.logger("INFO","Removing the temp data and log directory " + restoreObj.get_restoredDirectory() + '-tmp')
          shutil.rmtree(restoreObj.get_restoredDirectory() + '-tmp', ignore_errors=True)
          shutil.rmtree(restoreObj.get_restoredLogdir() + '-tmp', ignore_errors=True)
          common_lib.logger("INFO","Removed the temp data and logdirectory " + restoreObj.get_restoredDirectory() + '-tmp')
          module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_STATUS_JSON_KEY, "Completed") 
          module_exe_result.set_bool_status(backup_result.get_bool_status())
          
          
    if module_exe_result:
        if backupObj :
           module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_BACKUP_ID_JSON_KEY, backupObj.get_backupId())
        status_message = op_return_obj.get_status_msg()
        status_message = (status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
        module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_STATUS_MESSAGE_JSON_KEY, status_message)
        #check if the error is Fatal.
        if op_return_obj.get_error_type() == "Fatal" or restore_result.get_error_type() == "Fatal":
           module_exe_result.set_errorType("Fatal")
        status_message=restore_result.get_status_msg()
        status_message=(status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
        module_exe_result.set_status_log(status_message)
        module_exe_result.flush()

    module_exe_result = None

    return 0 if restore_result.get_bool_status() and backup_successful else 1


#performs restore operation
def do_restore(dictionary_data):
    """
    Obtains restore object from RestoreFactorya
    Calls msaas_restore_precheck.restore_pre_check() if fails return OperationReturnObj
    Calls doRestore method on restore object
    Return:
      rtype:OperationReturnObj
    """
    import constants
    import urlparse
    import shutil
    import recovery


    #create a return object
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    #perform precheck
    common_lib.logger("INFO","Executing msaas_restore_precheck.restore_pre_check(), checking the backup archive for any alteration.")
    restore_pre_check_result = msaas_restore_precheck.restore_pre_check(dictionary_data)
    if not restore_pre_check_result.get_bool_status():
        common_lib.logger("ERROR","Precheck msaas_restore_precheck.restore_pre_check() failed. exiting restore operation.")
        op_return_obj.set_bool_status(False)
        op_return_obj.set_status_msg(restore_pre_check_result.get_status_msg())
        return op_return_obj
    common_lib.logger("INFO","Finished executing msaas_restore_precheck.restore_pre_check() successfully.")


    #
    #PITR changes
    #create resttore object
    global restoreObj
    if "backup" in dictionary_data['SM_OPERATION_INFO']: 
        try:
           restoreObj = restore.RestoreFactory(dictionary_data).get_restoreObject()
        except KeyError as e:
           common_lib.logger("ERROR","Some keys missing in the Input JSON, failing with key error while parsing error: {err}".format(err=e))
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20902>: Unable to obtain the restore object.")
           return op_return_obj

        if not restoreObj:
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type("Fatal")
           op_return_obj.set_status_msg("<MSCS-ERR-20902>: Unable to obtain the restore object.")
        #perform restore operation
        restore_return_obj = restoreObj.doRestore()
        if not restore_return_obj.get_bool_status() :
           if not restoreObj.isDataDirFlipped() and os.listdir(restoreObj.get_restoreDirectory()):
              common_lib.logger("ERROR","Retore operation failed, but trying to start mysql on the current data directory (data before retore operation).")
              # do it only when the server is down
              checkResult=restoreObj.checkMySQLStatus()
              if checkResult.get_return_code() != 0:
                 #start the server
                 restoreObj.startMySQL()
              #cleanup 
              if os.path.exists(restoreObj.get_restoredLogdir()) or os.path.exists(restoreObj.get_restoredDirectory()) :
                 common_lib.logger("INFO","Removing temp restore directory")
                 shutil.rmtree(restoreObj.get_restoredLogdir(), ignore_errors=True)
                 shutil.rmtree(restoreObj.get_restoredDirectory(), ignore_errors=True)
 
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(restore_return_obj.get_error_type())
           op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
           return op_return_obj
        op_return_obj.set_status_msg(restore_return_obj.get_status_msg())
    else:
        restoreObj, recovery_return_obj = recovery.do_recovery(dictionary_data)
        if not recovery_return_obj.get_bool_status() :
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(recovery_return_obj.get_error_type())
           op_return_obj.set_status_msg(recovery_return_obj.get_status_msg())
           return op_return_obj
        op_return_obj.set_status_msg(recovery_return_obj.get_status_msg())

    # Loop on hosts_list
    restored_hosts=""
    not_restored_hosts = ""

    for host in restoreObj.get_hostList():
        restored_hosts += "{host} ".format(host=host)

    #stop restore and start succeeded, setup the success message
    #op_return_obj.append_status_msg("Restored hosts {host_list}...".format(host_list=restored_hosts))

    module_exe_result.set_operation_detail(constants.RESTORED_HOSTS_LIST_JSON_KEY, restored_hosts.strip())
    module_exe_result.set_operation_detail(constants.NOT_RESTORED_HOSTS_LIST_JSON_KEY, not_restored_hosts.strip())
    module_exe_result.set_operation_detail("restoredBackupImage", restoreObj.get_backupImageFullName())

    op_return_obj.set_bool_status(True)
    return op_return_obj

def get_DictForScheduledFullBackup(dictionaryData):
    """
    Build and return a dictionary object for scheduled full backup.
    """
    try: 
        #tag= common_lib.JSONUtil.decode_from_json_str(dictionaryData['SM_OPERATION_INFO']['backup']['tag'])

        #initialize the dictionary
        dictionaryDataForSchdFullBackup=dict()
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']=dict()
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['backup']=dict()
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']=dict()
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['attributes']=dict()
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['components']=dict()
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['components']['mysql']=dict()
        
        #setup the dictionary for scheduled full backup
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['backupId'] = dictionaryData['SM_OPERATION_INFO']['nextBackupId']
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['backup']['initiatedBy']= 'scheduled'
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['backup']['isFull']= True
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['backup']['backupStorageURI']= dictionaryData['SM_OPERATION_INFO']['storageURI']
        #setup cloud attributes
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['cloudStoragePassword'] = dictionaryData['SM_OPERATION_INFO']['cloudStoragePassword']
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['cloudStorageUser'] =  dictionaryData['SM_OPERATION_INFO']['cloudStorageUser']
        dictionaryDataForSchdFullBackup['SM_OPERATION_INFO']['storageURI'] = dictionaryData['SM_OPERATION_INFO']['storageURI']
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['attributes']['CLOUD_STORAGE_CONTAINER']=  dictionaryData['SM_SERVICE_INFO']['attributes']['CLOUD_STORAGE_CONTAINER']
        #setup service type and service name
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['serviceName']= dictionaryData['SM_SERVICE_INFO']['serviceName']
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['serviceType']= dictionaryData['SM_SERVICE_INFO']['serviceType']
        #setup backup destination and backup volume
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION'] = dictionaryData['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
        if dictionaryData['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION'] == 'BOTH':
           dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']= dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
        #setup instance detail
        dictionaryDataForSchdFullBackup['SM_SERVICE_INFO']['components']['mysql']['vmInstances'] =  dictionaryData['SM_SERVICE_INFO']['components']['mysql']['vmInstances']
    except KeyError as e:
        common_lib.logger("ERROR","Some keys specific to backup scheduled full backup operation are missing.")
        raise KeyError

    return dictionaryDataForSchdFullBackup

    
def do_backup(dictionaryData):
    """
    Performs a scheduled full backup 
    Return:
      Operation object
    """

    import socket
    import backup

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    

    #get backup object
    global backupObj
    try:
       backupObj = backup.BackupFactory(get_DictForScheduledFullBackup(dictionaryData)).get_backupObject()
    except KeyError as e:
       common_lib.logger("ERROR","Some keys missing in the Input JSON, failing with key error while parsing error: {err}".format(err=e))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20901>: Unable to obtain the backup object.")
       return op_return_obj

    if not backupObj:
       common_lib.logger("ERROR","Unable to obtain a backup object from the factory, JSON input BACKUP_DESTINATION and/or isFull does not have correct values")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20901>: Unable to obtain the backup object.")
       return op_return_obj

    #perform precheck
    preCheckResults = backupObj.doPreCheck()
    #check if all precheck passed
    for preCheck in preCheckResults.iterkeys():
        if not preCheckResults[preCheck]["status"] :
           common_lib.logger("ERROR","Following pre-check(s) failed, exiting backup operation. ")
           break

    #print the precheck details.
    for preCheck in preCheckResults.iterkeys():
        if not preCheckResults[preCheck]["status"] :
           common_lib.logger("ERROR",preCheckResults[preCheck]["message"])
           op_return_obj.set_bool_status(False)
           op_return_obj.append_status_msg(preCheckResults[preCheck]["message"] + " ")
    if not op_return_obj.get_bool_status():
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20201>: Pre-check(s) failed. " + op_return_obj.get_status_msg())
       return op_return_obj

    common_lib.logger("INFO","All pre-checks passed, continuing with backup operation. ")

    #perform backup and backup validation
    backup_return_obj = backupObj.doBackupAndValidate()
    if not backup_return_obj.get_bool_status() :
       op_return_obj.set_bool_status(backup_return_obj.get_bool_status())
       op_return_obj.set_error_type(backup_return_obj.get_error_type())
       op_return_obj.set_status_msg(backup_return_obj.get_status_msg())
       return op_return_obj

    # Loop on hosts_list
    backed_up_hosts=""
    for host in backupObj.get_hostList():
        backed_up_hosts += "{host} ".format(host=host)

    backupMetaData=common_lib.BackupMetaData()
    backupMetaData, backup_return_obj = backupObj.get_backupMetaData()
    if not backup_return_obj.get_bool_status() :
       op_return_obj.set_bool_status(backup_return_obj.get_bool_status())
       op_return_obj.set_error_type(backup_return_obj.get_error_type())
       op_return_obj.set_status_msg(backup_return_obj.get_status_msg())
       return op_return_obj

    backed_up_hosts=""
    for host in backupObj.get_hostList():
        backed_up_hosts += "{host} ".format(host=host)

    common_lib.logger("INFO","Printing backup metadata")
    common_lib.logger("INFO","Backup Start time : {starttime}".format(starttime=backupMetaData.getStartTime()))
    common_lib.logger("INFO","Backup End time : {endtime}".format(endtime=backupMetaData.getEndTime()))
    common_lib.logger("INFO","Backup Start LSN : {startlsn}".format(startlsn=backupMetaData.getStartLSN()))
    common_lib.logger("INFO","Backup End LSN : {endlsn}".format(endlsn=backupMetaData.getEndLSN()))
    common_lib.logger("INFO","Latest Binary Log parsed for the backup : {binlog}".format(binlog=backupMetaData.getBinLogFile()))
    common_lib.logger("INFO","Latest Binary Log parsed till offset : {pos}".format(pos=backupMetaData.getBinLogPos()))

    #backupAttributes = ( "{'startTime'" + ":" + "{startTime}".format(startTime=backupMetaData.getStartTime()) + "," 
    #		       "'endTime'" + ":" + "{endTime}".format(endTime=backupMetaData.getEndTime()) + "," 
    #		       "'startLSN'" + ":" + "{startLSN}".format(startLSN=backupMetaData.getStartLSN()) + "," 
    #		       "'endLSN'" + ":" + "{endLSN}".format(endLSN=backupMetaData.getEndLSN()) + "," 
    #		       "'lastBinLog'" + ":" + "'{lastBinLog}'".format(lastBinLog=backupMetaData.getBinLogFile()) + "," 
    #		       "'lastBinLogPos'" + ":" + "{lastBinLogPos}".format(lastBinLogPos=backupMetaData.getBinLogPos()) + "," 
    #		       "'triggeredBy'" + ":" + "'restore'}" )

    backupAttributes = ( '{"startTime"' + ':' + '{startTime}'.format(startTime=backupMetaData.getStartTime()) + ',' 
    		       '"endTime"' + ':' + '{endTime}'.format(endTime=backupMetaData.getEndTime()) + ',' 
    		       '"startLSN"' + ':' + '{startLSN}'.format(startLSN=backupMetaData.getStartLSN()) + ',' 
    		       '"endLSN"' + ':' + '{endLSN}'.format(endLSN=backupMetaData.getEndLSN()) + ',' 
    		       '"lastBinLog"' + ':' + '"{lastBinLog}"'.format(lastBinLog=backupMetaData.getBinLogFile()) + ',' 
    		       '"lastBinLogPos"' + ':' + '{lastBinLogPos}'.format(lastBinLogPos=backupMetaData.getBinLogPos()) + ',' 
    		       '"triggeredBy"' + ':' + '"restore"}' )
    #cleanup the backup directory and cloud backup objects
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_START_DATE_JSON_KEY, common_lib.getDateFromEpoch(backupMetaData.getStartTime(),'%Y-%m-%dT%H:%M:%S'))
    #backupStartDate =  common_lib.getDateFromEpoch(backupMetaData.getStartTime()'%Y-%m-%dT%H:%M:%S')
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_IS_LOCAL_JSON_KEY,False)
    #backupisLocal = false
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_END_DATE_JSON_KEY, common_lib.getDateFromEpoch(backupMetaData.getEndTime(),'%Y-%m-%dT%H:%M:%S'))
    #credential
    credential = backupObj.get_cloudStorageUser() + ":" + backupObj.get_cloudStoragePassword()
    #backupEndDate =  common_lib.getDateFromEpoch(backupMetaData.getEndTime()'%Y-%m-%dT%H:%M:%S')
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_CHECKSUM_JSON_KEY, common_lib.get_file_md5_checksum(backupObj.get_backUpImageFullName(), credential=credential))
    #backupCheckSum = common_lib.get_file_md5_checksum(backupObj.get_backUpImageFullName())
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_BACKED_UP_HOST_JSON_KEY, str(backed_up_hosts.strip()))
    #backupBackedUpHosts = backed_up_hosts.strip()
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_HAS_LOCAL_COPY_JSON_KEY, True)
    #backupHasLocalCopy = true
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_TAG_JSON_KEY, backupAttributes)
    #backupTag = 1461637041.35
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_ARCHIVE_FILE_NAME_JSON_KEY, backupObj.get_backupCloudObject())
    #backupArchiveFileName = backupObj.get_backUpImageFullName()
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_IS_FULL_JSON_KEY, True)
    #backupIsFull = true
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_BACKUP_ID_JSON_KEY, backupObj.get_backupId())
    #backupBackupID = backupObj.get_backupId() 
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_INITIATED_BY_JSON_KEY, "restore")
    #backupInitiatedBy = "restore"
    module_exe_result.set_postRestoreBackup_operation_detail(constants.POSTRESTORE_BACKUP_FILE_SIZE_JSON_KEY, common_lib.get_file_size(backupObj.get_backUpImageFullName(),credential=credential))
    #backupFileSize = common_lib.get_file_size(backupObj.get_backUpImageFullName())

    return op_return_obj


def switch_directory(fromDirectory, toDirectory, startMySQL=False):
    import shutil
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    #shutdown mysql
    #return_obj = restoreObj.stopMySQL()
    #if not return_obj.get_bool_status():
    #   op_return_obj.set_bool_status(return_obj.get_bool_status())
    #   op_return_obj.set_status_msg(return_obj.get_status_msg())
    #return op_return_obj

    #perform the swap
    #remove the current datadir
    try:
       shutil.rmtree(toDirectory, ignore_errors=True)
       common_lib.logger("INFO","Renaming  {datadir} to {datadirnew} ".format(datadir = fromDirectory, datadirnew=toDirectory))
       shutil.move(fromDirectory, toDirectory)
    except OSError as e:
       common_lib.logger("ERROR","Unable to rename data directory OS.OSError.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("Unable to rename data directory OSError.")
       return op_return_obj

    #start mysql
    if startMySQL:
       common_lib.logger("INFO", "Trying to start MySQL.")
       return_obj = restoreObj.startMySQL()
       if not return_obj.get_bool_status() :
          common_lib.logger("ERROR","Unable to start MySQL.")
          op_return_obj.set_bool_status(return_obj.get_bool_status())
          op_return_obj.set_status_msg(return_obj.get_status_msg())
          return op_return_obj

       common_lib.logger("INFO", "Started MySQL after switching to old data directory.") 
    return op_return_obj

@atexit.register
def at_exit():
    """
    This function will get invoked when script exits
    :return:
    """
    if module_exe_result:
        module_exe_result.flush()

if __name__ == "__main__":
    result = main()
    module_exe_result.set_status_log(result.get_status_msg())

    sys.exit(0 if result.get_bool_status() else 1)


