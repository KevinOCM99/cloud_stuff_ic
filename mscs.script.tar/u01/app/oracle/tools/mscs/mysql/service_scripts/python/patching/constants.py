#constant file used in patchin framework

#Status codes
SUCCESS = 0
FAILURE = 10

#Binary Home
BIN_HOME = "/u01/bin"
data_dir = "/u01/data/mysql"
#Sys user
sys_user = "oracle"

#Serive key and component names used to extract info from the input json for storageKey , zipBundles and checkSum
serviceKey = "mysql"
component = "MSAAS"

#patching and Rollback shell scripts
patch_shell_script = "/mysqlPatch.sh"
rollback_shell_script = "/mysqlRollback.sh"
mscs_log_file="log"
patch_log_file="/patch.log"
patch_folder = '/tmp/patch'

#Variable is used to print the final json result only once on the stdout
print_on_stdOut = 0

#
service_scripts_var = "service_scripts"

#Relative paths of the shell scripts used for checking available space and MySQL status on VM
mysql_install_script_relative_path = "vm-scripts/mysql-installation-utils.sh"
mysql_provisioning_script_relative_path = "vm-scripts/msaas-provisioning-utils.sh"

#Command to check the space available for Binary Volume
space_availability_command = "df /u01/bin | grep /u01/b | awk '{print $3}'"

#NUMA library
LIBNUMA = "numactl-devel"
