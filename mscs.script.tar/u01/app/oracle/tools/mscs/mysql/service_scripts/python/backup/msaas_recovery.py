#!/usr/bin/env python
import sys
import re
import time
import os
import xml.sax
import constants
import msaas_common_lib as common_lib


def getBackupMetaData(backupDir):
   """
    Function parses backup_content.xml and return a BackupMetadata bean.
    Return:
       rtype:BackupMetadata, OperationReturnObj
   """
  
   op_return_obj = common_lib.OperationReturnObj()
   op_return_obj.set_bool_status(True)

   #initialize
   backupMetaData=common_lib.BackupMetaData()
   backupMetaFile=os.path.join(backupDir, constants.BACKUP_CONTENT_XML) #'meta/backup_content.xml'

   #make sure it is a valid backup directory
   if not os.path.isfile(backupMetaFile):
      common_lib.logger("ERROR", " Metadata file {file} not found.".format(file=backupMetaFile))
      op_return_obj.set_bool_status(False)
      op_return_obj.set_status_msg("<MSCS-ERR-20705>: Metadata file {file} not found.".format(file=backupMetaFile))
      return None, op_return_obj

   try:
        # create an XMLReader
        parser = xml.sax.make_parser()
        # turn off namepsaces
        parser.setFeature(xml.sax.handler.feature_namespaces, 0)

        # override the default ContextHandler
        handler = common_lib.BackupContentHandler()
        parser.setContentHandler( handler )

        #valid backup directory continue with xml parsing
        parser.parse(backupMetaFile)
   except xml.sax.SAXParseException, e:
        commom_lib.logger("ERROR", "Metadata XML {backupcontent} parsing error : {error}".format(backupcontent=backupMetaFile,error=e))
        op_return_obj.set_bool_status(False)
        op_return_obj.set_status_msg("<MSCS-ERR-20706>: Metadata XML paring error")
        return None, op_return_obj 

   backupMetaData.setStartTime(getEpoch(handler.getStartTime(),"%Y-%m-%d %H:%M:%S"))
   backupMetaData.setEndTime(getEpoch(handler.getEndTime(),"%Y-%m-%d %H:%M:%S"))
   backupMetaData.setBinLogFile(handler.getBinLogFile())
   backupMetaData.setBinLogPos(handler.getBinLogPos())
   backupMetaData.setStartLSN(int(handler.getStartLSN()))
   backupMetaData.setEndLSN(int(handler.getEndLSN()))

   return backupMetaData, op_return_obj


def getBackupDirectories(backupDir):
    try:
       backupDirs=filter(lambda name: not os.path.isfile(os.path.join(backupDir, name)), (os.listdir(backupDir)))
    except:
       backupDirs=[]
              
    return backupDirs

def getBackupsForPITR(backupDir, backupType, recovery_time_epoch,fullbkup_end_lsn=None,fullbkup_end_time=None):
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    #get the directroies to work with
    backups=getBackupDirectories(backupDir)
    if not backups:
       return None, op_return_obj
       
    #initialize the metadata
    new_backup_image=None
    new_backup_type=None
    new_backup_start_epoch=0
    new_backup_end_epoch=0
    new_binlog_file=None
    new_binlog_pos=None
    new_end_lsn=None
    new_start_lsn=None
    # check for incremnatl backup search parent backup details or passed, if not exit out with error
    if backupType == 'incr' and not (fullbkup_end_lsn and fullbkup_end_time) :
       common_lib.logger("ERROR","Incremental backup must pass parent backup details.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20707>: Incremental backup parent backup detail missing")
       return None, op_return_obj

    #get metadata bean object
    backupMetaData=common_lib.BackupMetaData()
    #check each of the backups and pick last one  which is done before the recovery time
    for dir in backups:
        backupMetaData, result_obj = getBackupMetaData(os.path.join(backupDir, dir))
        print os.path.join(backupDir, dir)
        if not result_obj.get_bool_status(): 
           op_return_obj.set_bool_status(False)
           op_return_obj.set_status_msg(result_obj.get_status_msg())
           return None, op_return_obj

        #check if required for the recovery
        print backupMetaData.getEndTime()
        print recovery_time_epoch
        print new_backup_end_epoch

        if backupType == 'full' and  backupMetaData.getEndTime() < recovery_time_epoch and backupMetaData.getEndTime() > new_backup_end_epoch:
           new_backup_image=os.path.join(os.path.join(backupDir, dir), constants.FULL_BACKUP_IMAGE) #'/backup_full.mbi'
           new_backup_type="full"
           
        elif backupType == 'incr' and (    backupMetaData.getEndTime() < recovery_time_epoch
				       and backupMetaData.getEndTime() > new_backup_end_epoch
                                       and fullbkup_end_lsn+1 == backupMetaData.getStartLSN()
                                       and backupMetaData.getEndTime() >= fullbkup_end_time ):
          new_backup_image=os.path.join(os.path.join(incrBackupDir, dir), constants.INCR_BACKUP_IMAGE) #'/backup_incremental.mbi'
          new_backup_type="incr"
        else:
          continue

        new_backup_start_epoch=backupMetaData.getStartTime()
        new_backup_end_epoch=backupMetaData.getEndTime()
        new_binlog_file=backupMetaData.getBinLogFile()
        new_binlog_pos=backupMetaData.getBinLogPos()
        new_start_lsn=backupMetaData.getStartLSN()
        new_end_lsn=backupMetaData.getEndLSN()
    #generate a metadata bean 
    backupMetaData = common_lib.BackupMetaData(new_backup_type,new_backup_image,new_backup_start_epoch,new_backup_end_epoch,new_start_lsn,new_end_lsn,new_binlog_file,new_binlog_pos)       
    return backupMetaData, op_return_obj

def getBinaryLogsStarttime(binLogFile):
   """
   """
   from datetime import datetime
   op_return_obj = common_lib.OperationReturnObj()
   op_return_obj.set_bool_status(True)


   executor = common_lib.Executor()
   cmd ="{mblpath}/mysqlbinlog  --start-position=4 --stop-position=12 {binLogFile}|grep 'log created'".format(mblpath=constants.MBLPATH, binLogFile=binLogFile)
   exec_result=executor.execute_cmd(cmd)
   if exec_result.get_return_code() != 0:
      common_lib.logger("Error","Unable to get start start time and server id from binary log {binlog}".format(binlog=binLogFile))
      op_return_obj.set_bool_status(False)
      op_return_obj.set_status_msg("<MSCS-ERR-20108>: Unable to get start start time and server id from the binary log.")
      return None,None,op_return_obj

   #get standard out
   stdOut = exec_result.get_std_out()
   #normalize the blank space
   stdOut = " ".join(stdOut.split())
   words=stdOut.split()
   #Format the time and get the epoch
   wdatetime="20" + words[0].strip("#") + " " + words[1]
   #sepoch = int(time.mktime(time.strptime(wdatetime,"%Y%m%d %H:%M:%S")))
   try:
      datetime.strptime(wdatetime, '%Y%m%d %H:%M:%S')
   except ValueError:
      common_lib.logger("ERROR", "Invalid date format, format should be in '%Y%m%d %H:%M:%S'")
      op_return_obj.set_bool_status(False)
      op_return_obj.set_status_msg("<MSCS-ERR-20108>: Unable to get start start time and server id from the binary log.")
      return None,None,op_return_obj
   
   sepoch = getEpoch(wdatetime,"%Y%m%d %H:%M:%S")
   wserverid= words[4]
   return sepoch, wserverid,op_return_obj

def getBinaryLogsForPITR(binLogs, lepoch, repoch, serverid):
    rbinlogs={}
    for binlog in binLogs:
        wepoch, wserverid, result_obj = getBinaryLogsStarttime(binlog)
        if wepoch >= lepoch and wepoch <= repoch and wserverid==serverid :
           rbinlogs.update({wepoch : binlog})
    return rbinlogs


def getEpoch(dateTime,dateTimeFormat):
   epoch = int(time.mktime(time.strptime(dateTime,"{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat))))
   return epoch

def getDateFromEpoch(epoch,dateTimeFormat):
   dateTime=time.strftime("{dateTimeFormat}".format(dateTimeFormat=dateTimeFormat), time.localtime(epoch))
   return dateTime

def applyBinaryLogs(recoveryBinaryLog,user,binLogPos,recoveryTimeEpoch):
   recoveryTime=getDateFromEpoch(recoveryTimeEpoch, "%Y-%m-%d %H:%M:%S")
   cmd='{mblpath}/mysqlbinlog --skip-gtids --start-position={start_position} --stop-datetime="{stop_datetime}" {recovery_bin_log}|{MSQLPATH}/mysql -u{USER} '.format(MSQLPATH=MSQLPATH, mblpath=MBLPATH,start_position=binLogPos,stop_datetime=recoveryTime,recovery_bin_log=recoveryBinaryLog, USER=USER)
   #create executer
   executor = common_lib.Executor()
   common_lib.logger("INFO", "Applying binary log {cmd}".format(cmd=cmd))
   cmd_execution_result = executor.execute_cmd(cmd)
   return cmd_execution_result

def getBackupsForRecovery(recovery_time_epoch):
    """
    Function identifies full backup, differential backup required for recovery
    Return:
      rtype: BackupMetaData, BackupMetaData, OperationReturnObj
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    
    #get metadata for full and incremental backups needed for recovery
    #
    fullBackupMetaData,result_obj = getBackupsForPITR(FULLBACKUPDIR,'full',recovery_time_epoch)
    if not result_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return None, None, op_return_obj

    incrBackupMetaData,result_obj = getBackupsForPITR(INCRBACKUPDIR,'incr',recovery_time_epoch,fullBackupMetaData.getEndLSN(),fullBackupMetaData.getEndTime())
    if not result_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return None, None, op_return_obj

    return fullBackupMetaData, incrBackupMetaData, op_return_obj

 
def getBackupsAndBinlogsForRecovery(recovery_time_epoch):
    """
    This function identifies full backup, differential backup and binlogs required for recovery
    Return:
       rtype:retrunData, OperationReturnObj
       retrunData = {fullbackmetadata:BackupMetaData, incrbackupmetadata:BackupMetaData,recoverybinlogs:recovery_binary_log }
    """
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    returnData = dict()

    #get metadata for full and incremental backups needed for recovery
    #There will always be one full backup required for recovery
    #differential  backup may or may not be needed for recovery. If needed there could be only one incremental backup
    #
    fullBackupMetaData, incrBackupMetaData , result_obj = getBackupsForRecovery(recovery_time_epoch)
    if not result_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return None, op_return_obj
 
    #exit if no full backup available for restore
    if not fullBackupMetaData or not fullBackupMetaData.getBackupImage():
       common_lib.logger("ERROR","No full backup available for recovery time {recvtime}".format(recvtime=str(recovery_time_epoch)))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20704>: No full backup available for recovery time {recvtime}.".format(recvtime=str(recovery_time_epoch)))
       return None, op_return_obj

 
    #find the first binary log required for recovery after restoring from full backup and applying differential backup.
    #find the last binary log file upto whihc the full backup has data
    binary_log_file=fullBackupMetaData.getBinLogFile()
    #if there is an incremental also needed for recovery start with last binlog file of the incremental
    if incrBackupMetaData:
       binary_log_file=incrBackupMetaData.getBinLogFile()
 
    #construct the absolute path to the binary log
    absolute_binlog_file=os.path.join(BINLOGDIR, binary_log_file)
 
    #construct a list of all binlog files from binlog directory
    binlogList=[os.path.join(BINLOGDIR, bfile) for bfile in os.listdir(BINLOGDIR) if re.match(r'.*\.[0-9]+$', bfile)]
 
    # verify the binary log file and get the list of the binary log files required for this recovery
    # based on the binlog header information
    # if no binary logs are available exit with error.
    if os.path.isfile(absolute_binlog_file):
       sepoch, serverid, result_obj = getBinaryLogsStarttime(absolute_binlog_file)
       if not result_obj.get_bool_status():
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg(result_obj.get_status_msg())
          return None, op_return_obj

       binary_logfiles=getBinaryLogsForPITR(binlogList, sepoch,recovery_time_epoch,serverid )
    else:
       common_lib.logger("ERROR","No Binary logs avialable for recovery")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return None, op_return_obj
 
    returnData['fullbackmetadata'] = fullBackupMetaData
    returnData['incrbackupmetadata'] = incrBackupMetaData
    returnData['binlogs'] = binary_logfiles

    return returnData, op_return_obj


def validateRecoveryTime(rtime):
    """
    This function validates the recovery time for format
    and also for it the recovery time is in future.
    Returns:
       rtype:OperationReturnObj
    """
    from datetime import datetime
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    recovery_time_epoch = None   

    #chec the date format
    try:
        datetime.strptime(rtime, '%Y-%m-%d %H:%M:%S')
    except ValueError:
        common_lib.logger("ERROR", "Invalid date format, format shoud be in '%Y-%m-%d %H:%M:%S'")
        op_return_obj.set_bool_status(False)
        op_return_obj.set_status_msg("<MSCS-ERR-20702>: Invalid date format, format shoud be in '%Y-%m-%d %H:%M:%S'")
        return None, op_return_obj

    #check if the recovery time is in futire
    recovery_time_epoch=getEpoch(rtime,"%Y-%m-%d %H:%M:%S")
    current_time_epoch=getEpoch(time.strftime("%Y-%m-%d %H:%M:%S"),"%Y-%m-%d %H:%M:%S")
    if recovery_time_epoch > current_time_epoch :
       common_lib.logger("ERROR", "Cannot recover to a future time.")
       common_lib.logger("ERROR", "Current time in epoch : {currtime}".format(currtime=str(current_time_epoch)))
       common_lib.logger("ERROR", "Recovery time in epoch : {recvtime}".format(recvtime=str(recovery_time_epoch)))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20703>: Cannot recover to a future time, recovery time specified is in future.")
       return None, op_return_obj

    return recovery_time_epoch, op_return_obj

def main():
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    if len(sys.argv) == 1:
       common_lib.logger("ERROR", "Please provide the time to recover in %Y-%m-%d %H:%M:%S format")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20701>: Cannot recover to a future time, recovery time specified is in future.")
       return op_return_obj

    #Validate recovery time
    
    recovery_time_epoch, result_obj = validateRecoveryTime(sys.argv[1])
    if not result_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return op_return_obj

    retrunData, result_obj = getBackupsAndBinlogsForRecovery(recovery_time_epoch)
    if not result_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(result_obj.get_status_msg())
       return op_return_obj

    #log all the information collected for recovery, full backup image, incremental backup image and binary logs
    fullBackupMetaData = retrunData.get('fullbackmetadata', None)
    incrBackupMetaData = retrunData.get('incrbackupmetadata', None)
    binary_logfiles = retrunData.get('binlogs', None)

    common_lib.logger("INFO","For Recovery apply the following in order :")
    common_lib.logger("INFO","=====Full backup: {fullbackup}".format(fullbackup=fullBackupMetaData.getBackupImage()))
    if incrBackupMetaData:
       common_lib.logger("INFO","========Incremental backup: {incrbackup}".format(incrbackup=incrBackupMetaData.getBackupImage()))
 
    recovery_binary_log=""
    for key in sorted(binary_logfiles):
       recovery_binary_log= recovery_binary_log + " " + binary_logfiles.get(key)
       common_lib.logger("INFO", "==========Binary logs:" + binary_logfiles.get(key))

    op_return_obj.set_status_msg("<MSCS-INFO-20700>: Databases is successfully recoeverd to {rtime}".format(rtime = sys.argv[1]))
    return op_return_obj

if ( __name__ == "__main__"):

   ########FULLBACKUPDIR="/u01/backup/mscs/testsrv/scheduledFull"
   FULLBACKUPDIR="/u01/backup/MSCS/prad-BR/onDemandFull"
   INCRBACKUPDIR="/u01/backup/MSCS/test-diskBR/onDemandIncermental"
   BINLOGDIR=constants.DATA_DIR
   MYCNFPATH="/u01/bin/mysql"
   MSQLPATH="/u01/bin/mysql/bin"
   DATADIR=constants.DATA_DIR
   USER=constants.MYSQL_USER

   op_return_obj = common_lib.OperationReturnObj()
   op_return_obj.set_bool_status(True)
   op_return_obj = main()
   print (op_return_obj.get_status_msg())
   sys.exit(0)

   #start recovery
   #stop mysql
   return_obj = stopMySQL()
   if not return_obj.get_bool_status():
      sys.exit(1)


   #fullback restore
   binlog_pos=fullBackupMetaData.getBinLogPos()
   exe_result = restoreBackup(fullBackupMetaData, USER, DATADIR)
   return_code = exe_result.get_return_code()
   if return_code != 0:
      common_lib.logger("ERROR", "Failed to restore from full backup {backup_image}".format(backup_image=fullBackupMetaData.getBackupImage()))
      sys.exit(1)

   #retore from incremental backup if required
   if not incrBackupMetaData.getBackupImage() == None:
      binlog_pos=incrBackupMetaData.getBinLogPos()
      exe_result = restoreBackup(incrBackupMetaData, USER, DATADIR)
      return_code = exe_result.get_return_code()
      if return_code != 0:
         common_lib.logger("ERROR", "Failed to restore from incremental backup {backup_image}".format(backup_image=incrBackupMetaData.getBackupImage()))
         sys.exit(1)

   #start mysqld
   return_obj = startMySQL()
   if not return_obj.get_bool_status():
      sys.exit(1)


   time.sleep(50)

   #now apply binlogs
   exe_result = applyBinaryLogs(recovery_binary_log,USER,binlog_pos,recovery_time_epoch)
   return_code = exe_result.get_return_code()

   if return_code != 0:
      common_lib.logger("ERROR","Failed to apply the binary log {recoveryBinaryLog}".format(recoveryBinaryLog=recovery_binary_log))
      sys.exit(1)

   common_lib.logger("INFO","Recovery completed successfully.")
   sys.exit(0)

