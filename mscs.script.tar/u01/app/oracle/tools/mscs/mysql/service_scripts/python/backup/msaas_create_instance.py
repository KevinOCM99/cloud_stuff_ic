#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import sys
import os
import atexit

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import createInstance
import constants
import msaas_common_lib as common_lib

createInstanceObj=None


#
##
###main
def main():
    """
    Returns a function execute_backup if the input JSON validates with out error.
    """
    return_obj = common_lib.OperationReturnObj()
    return_obj.set_bool_status(True)

    #parsing input JSON into a python dictionary
    try:
       with open(sys.argv[1]) as inputJSONFile:
            json_str = inputJSONFile.read()
            input_dict_args = common_lib.JSONUtil.decode_from_json_str(json_str)
    except EnvironmentError as e:
       common_lib.logger("ERROR","Error in reading the create instance JSON file")

    if not input_dict_args:
        common_lib.logger("ERROR","Invalid json argument, exiting backup operation")
        return_obj.set_bool_status(False)
        return_obj.append_status_msg("Exiting backup operation. Invalid JSON arguments...")
        return return_obj


    result = execute_createInstance(input_dict_args)
    return result

def execute_createInstance(input_dict_args):
    import copy

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    global module_exe_result
    common_lib.logger("INFO","Formated input JSON dump.")

    #obfuscate password before dumping
    input_dict_args_for_print = copy.deepcopy(input_dict_args)
    if input_dict_args_for_print.has_key('dumpCloudUserPassword'):
       input_dict_args_for_print['dumpCloudUserPassword'] = 'XXXXXXXX'

    common_lib.JSONUtil.print_dict_as_json(input_dict_args_for_print)
    
    #get backup object
    global createInstanceObj
    try:
       createInstanceObj = createInstance.CreateInstanceFactory(input_dict_args).get_CreateInstanceObject()
    except KeyError as e:
       common_lib.logger("ERROR","Error while intializing data from backup.")
       common_lib.logger("ERROR","Some keys missing in the Input JSON, failing with key error while parsing error: {err}".format(err=e))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20911>: Error while intializing data from backup.")
       return op_return_obj
    except ValueError as e:
       common_lib.logger("ERROR","Error while intializing data from backup.")
       common_lib.logger("ERROR",e.args)
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20911>: Error while intializing data from backup.")
       return op_return_obj

    if not createInstanceObj:
       common_lib.logger("ERROR","Unable to obtain a createInstance object from the factory, JSON input does not have correct value for the backup file name.")
       common_lib.logger("ERROR","Only file extentions .zip (for SQL dump) and .mbi (for meb backup) are allowed.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg("<MSCS-ERR-20911>: Unable to process the backup file. Only file extentions .zip (for SQL dump) and .mbi (for meb backup) are allowed.")
       return op_return_obj

    return_obj = createInstanceObj.createInstance()
    if not return_obj.get_bool_status():
       op_return_obj.set_bool_status(False)
       op_return_obj.set_status_msg(return_obj.get_status_msg())
       return op_return_obj
    common_lib.logger("INFO","MySQL database instance created.")
    #perform cleanup
    createInstanceObj.cleanUp()
    common_lib.logger("INFO","Finished cleaning temporary files.")
    return op_return_obj

@atexit.register
def at_exit():
    """
    This function will get invoked when script exits
    :return:
    """
    global createInstanceObj
    if createInstanceObj:
       createInstanceObj.cleanUp()

if __name__ == "__main__" :
   result = main()
   # for error, create a error file to be propagated to the event log
   if not result.get_bool_status():
      errorFile = '/tmp/create_instance_from_backup.err'
      status_message = result.get_status_msg()
      status_message = (status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
      with open(errorFile, 'w' ) as efile:
         efile.write(status_message)

   sys.exit(0 if result.get_bool_status() else 1)
