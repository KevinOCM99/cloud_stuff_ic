#
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#

__author__ = 'jnag'

import json

def simplify_payload(data):
    print "JSON payload received: "
    print json.dumps(data)
    sm_service_info = data['SM_SERVICE_INFO']
    componentName = data["SM_OPERATION_INFO"]["COMPONENT_TYPE"]
    operationHosts = data["SM_OPERATION_INFO"]["PAAS_OPERATION_VMS"]
    hosts=[]
    component = sm_service_info["components"][componentName]
    for vmName, vmValue in component["vmInstances"].iteritems():
        if vmName in operationHosts:
            host={}
            host["hostName"] = vmName
            ###
            host["publicIpAddress"] = vmValue["publicIpAddress"]
            ###
            servers=[]
            host["servers"] = servers
            
            hosts.append(host)

            for serverName, serverValue in vmValue["servers"].iteritems():
                server={}
                server["serverName"] = serverValue["serverName"]
                server["usageType"] = serverValue["serverType"]
                server["serverAttributes"] = serverValue.get("attributes", {})
                servers.append(server)


    simplifiedPayload = {}
    simplifiedPayload["hosts"] = hosts
    simplifiedPayload["componentAttributes"] = component["attributes"]
    simplifiedPayload["mysql_port"] = sm_service_info["attributes"]["MYSQL_PORT"]
    return simplifiedPayload


def get_component_name(data):
    componentName = data["SM_OPERATION_INFO"]["COMPONENT_TYPE"]
    return componentName

def get_mysql_port(data):
    port = data["SM_SERVICE_INFO"]["attributes"]["MYSQL_PORT"]
    return port

