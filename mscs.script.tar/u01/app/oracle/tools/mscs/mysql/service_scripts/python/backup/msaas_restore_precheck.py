#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import sys
import os
import urlparse

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import constants
import msaas_common_lib as common_lib
from module_exe_util import ModuleExecutionReturnClass

module_exe_result = ModuleExecutionReturnClass()
module_exe_result.set_operation_type("restore_precheck")

def execute(dictionary_data):
    """
    Produces a formated input JSON dump
    and calls restore_pre_check function
    If restore_pre_check succeeds will return "0", if not "1"
    """
    import copy
    #obfuscate password before dumping
    common_lib.logger("INFO","Formated input JSON dump.")
    dictionary_data = common_lib.decode_secure_params(dictionary_data)
    input_dict_args_for_print = copy.deepcopy(dictionary_data)
    if input_dict_args_for_print.has_key('SM_OPERATION_INFO') and input_dict_args_for_print['SM_OPERATION_INFO'].has_key('cloudStoragePassword'):
       input_dict_args_for_print['SM_OPERATION_INFO']['cloudStoragePassword'] = 'XXXXXXXX'
    #if input_dict_args_for_print.has_key('cloudStoragePassword'):
    #   input_dict_args_for_print['cloudStoragePassword'] = 'XXXXXXXX'
    common_lib.JSONUtil.print_dict_as_json(input_dict_args_for_print)

    result = restore_pre_check(dictionary_data)

    service_info = dictionary_data.get(constants.SERVICE_INFO)

    if service_info:
       module_exe_result.set_service(service_info)

    if module_exe_result:
       module_exe_result.set_bool_status(result.get_bool_status())
       module_exe_result.set_errorType(result.get_error_type())
       status_message=result.get_status_msg()
       status_message=(status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
       module_exe_result.set_status_log(status_message)
       module_exe_result.flush()
    return 0 if result.get_bool_status() else 1

#
##
###checks the backup archive file for existance and size
def restore_pre_check(dictionary_data):
    """
    Performs pre checks for restore
    1. run meb validate command on the cloud backup image
    2. for disk based image checks the existance and size
    Return:
           rtype: OperationReturnObj
    """
    import datetime
    import recovery

    #common_lib.JSONUtil.print_dict_as_json(dictionary_data)
    startTime = datetime.datetime.now()

    common_lib.logger("INFO","Begin restore health check")
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    op_return_obj.set_status_msg("<MSCS-INFO-20600>: Restore health check passed.")

    if not "backup" in dictionary_data['SM_OPERATION_INFO']:
        # new format, could be PIT
        if "restoreType" in dictionary_data["SM_OPERATION_INFO"]["requestAttributes"] \
                and dictionary_data["SM_OPERATION_INFO"]["requestAttributes"]["restoreType"] == "pit":
            result_obj = recovery.recovery_pre_check(dictionary_data)
            if not result_obj.get_bool_status():
                op_return_obj.set_bool_status(False)
                op_return_obj.set_error_type(result_obj.get_error_type())
                op_return_obj.set_status_msg(result_obj.get_status_msg())
                return op_return_obj

        op_return_obj.set_bool_status(True)
        op_return_obj.set_status_msg("<MSCS-INFO-20600>: Restore health check passed.")
        return op_return_obj

    try:
       archiveFileName = dictionary_data['SM_OPERATION_INFO']['backup']['archiveFileName']
       backup_destination = dictionary_data['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
       isFull = dictionary_data['SM_OPERATION_INFO']['backup']['isFull']
       archive_size = dictionary_data['SM_OPERATION_INFO']['backup']['size']
       archive_checksum = dictionary_data['SM_OPERATION_INFO']['backup']['checksum']
       if not isFull :
          parent_archiveFileName = dictionary_data['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
          parent_archive_size = dictionary_data['SM_OPERATION_INFO']['backup']['fullBackup']['size']
          parent_archive_checksum = dictionary_data['SM_OPERATION_INFO']['backup']['fullBackup']['checksum']

       if backup_destination=='BOTH' or backup_destination=='OSS':
          storage_uri = dictionary_data['SM_OPERATION_INFO']['backup']['backupStorageURI']
          cloud_storage_container = common_lib.get_Container_from_Storage_URL(storage_uri)
          cloud_storage_user_password = dictionary_data['SM_OPERATION_INFO']['cloudStoragePassword']
          cloud_storage_user = dictionary_data['SM_OPERATION_INFO']['cloudStorageUser']

       if backup_destination=='OSS':
          local_backup_volume_mount = storage_uri
          archive = urlparse.urljoin(storage_uri if storage_uri.endswith('/') else storage_uri + '/', archiveFileName)
          if not isFull :
             parent_archive = urlparse.urljoin(storage_uri if storage_uri.endswith('/') else storage_uri + '/', parent_archiveFileName)
       else:
          local_backup_volume_mount = dictionary_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
          archive = os.path.join(local_backup_volume_mount, archiveFileName)
          if not isFull :
             parent_archive = os.path.join(local_backup_volume_mount, parent_archiveFileName)

    except KeyError as e:
       common_lib.logger("ERROR","Some keys specific to restore are missing in the input JSON payload.")
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("<MSCS-ERR-20609>: Unable to validate the backup because input JSON key(s) missing.")
       return op_return_obj

    #check if the back is on cloud storage and not present on the local  disk
    if ( backup_destination=='BOTH' or backup_destination=='OSS' ) and not os.path.isfile(archive):
       #validate the backup on cloud
        validation_result = validate_cloudBackup(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password)
        if not validation_result.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(validation_result.get_error_type())
           common_lib.logger("ERROR","Validation of backup image {image} failed.".format(image=archive))
           op_return_obj.set_status_msg("<MSCS-ERR-20601>: Validation of backup image failed.")
           return op_return_obj
        if not isFull :
           validation_result = validate_cloudBackup(storage_uri, local_backup_volume_mount, cloud_storage_container, parent_archive, cloud_storage_user, cloud_storage_user_password)
           if not validation_result.get_bool_status():
              op_return_obj.set_bool_status(False)
              op_return_obj.set_error_type(validation_result.get_error_type())
              common_lib.logger("ERROR","Validation of backup image {image} failed.".format(image=parent_archive))
              op_return_obj.set_status_msg("<MSCS-ERR-20601>: Validation of backup image failed.")
              return op_return_obj
    else:
        #the image is on disk
        validation_result = validate_diskBackup(archive, archive_size, archive_checksum)
        if not validation_result.get_bool_status():
           op_return_obj.set_bool_status(False)
           op_return_obj.set_error_type(validation_result.get_error_type())
           common_lib.logger("ERROR","Validation of backup image {image} failed.".format(image=archive) + validation_result.get_status_msg())
           op_return_obj.set_status_msg("<MSCS-ERR-20601>: Validation of backup image failed.")
           return op_return_obj
        if not isFull :
           if os.path.isfile(parent_archive) :
              validation_result = validate_diskBackup(parent_archive, parent_archive_size, parent_archive_checksum)
           else:
              validation_result = validate_cloudBackup(storage_uri, local_backup_volume_mount, cloud_storage_container, parent_archive, cloud_storage_user, cloud_storage_user_password)
           if not validation_result.get_bool_status():
              op_return_obj.set_bool_status(False)
              op_return_obj.set_error_type(validation_result.get_error_type())
              common_lib.logger("ERROR","Validation of backup image {image} failed.".format(image=parent_archive) + validation_result.get_status_msg())
              op_return_obj.set_status_msg("<MSCS-ERR-20601>: Validation of backup image failed.")
              return op_return_obj

    common_lib.logger("INFO","Restore health check passed.")
    endTime = datetime.datetime.now()
    duration = endTime - startTime
    duration = duration.seconds * 1000 + duration.microseconds / 1000.0
    common_lib.logger("INFO","Total time spent on restore pre-check in milliseconds {duration}".format(duration=duration))

    module_exe_result.set_operation_detail("checkedBackupImage", dictionary_data['SM_OPERATION_INFO']['backup']['archiveFileName'])
    return op_return_obj

def validate_diskBackup(archive, archive_size, archive_checksum):
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    op_return_obj.set_status_msg("Validation of image {image} passed.".format(image=archive))

    if not archive:
       common_lib.logger("ERROR","Cannot validate archive {source}. Archive name not passed in the input JSON.".format(source=archive))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("Validation of archive failed, archive not specified.")
       return op_return_obj
    if not os.path.isfile(archive):
       common_lib.logger("ERROR","Archive {source} does not exist.".format(source=archive))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("Validation of archive failed, archive specified does not exit.")
       return op_return_obj
    common_lib.logger("INFO","Backup archive exists.")

    #Verify the backup archive size
    if archive_size:
       common_lib.logger("INFO","Validating archive size.")
       archive_size_calc = os.path.getsize(archive)
       if archive_size_calc != archive_size:
          common_lib.logger("ERROR","Validation of archive {archive} failed, archive size mismatch.".format(archive=archive))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type("Fatal")
          op_return_obj.set_status_msg("Validation of archive {archive} failed, archive size mismatch.".format(archive=archive))
          return op_return_obj

    #Verify the backup archive checksum
    if archive_checksum :
       common_lib.logger("INFO","Validating backup archive checksum.")
       archive_checksum_calc = common_lib.get_file_md5_checksum(archive)
       if archive_checksum_calc != archive_checksum:
          common_lib.logger("ERROR","Validation of archive {archive} failed, archive checksum mismatch.".format(archive=archive))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_error_type("Fatal")
          op_return_obj.set_status_msg("Validation of archive {archive} failed, archive checksum mismatch.".format(archive=archive))
          return op_return_obj

    return op_return_obj

def validate_cloudBackup(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password):

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    op_return_obj.set_status_msg("Validation of image {image} passed.".format(image=archive))

    executor = common_lib.Executor()
    common_lib.logger("INFO","Validating the backup image {image}.".format(image=archive))
    isBMC = True if storage_uri.startswith("https://swiftobjectstorage") else False 
    validate_cmd=get_BMC_validate_cmd(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password) if isBMC else get_validate_cmd(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password)
    validate_cmd_print=validate_cmd.replace(cloud_storage_user_password,'XXXXXXXX')
    common_lib.logger("INFO","Executing command {validate_cmd}".format(validate_cmd=validate_cmd_print))
    exe_result = executor.execute_cmd(commandline=validate_cmd,command_for_print=validate_cmd_print)
    common_lib.logger("INFO","===============output from mysqlbackup (validate) ================")
    print exe_result.get_std_out()
    print exe_result.get_std_err()
    if exe_result.get_return_code() != 0:
       common_lib.logger("ERROR","Validation of backup image {image} failed, exiting restore precheck. Please check mysqlbackup log.".format(image=archive))
       op_return_obj.set_bool_status(False)
       op_return_obj.set_error_type("Fatal")
       op_return_obj.set_status_msg("Validation of backup image failed.")
       return op_return_obj

    common_lib.logger("INFO","Validated backup image {image} successfully.".format(image=archive))
    return op_return_obj


#
##
###generates validate command
def get_validate_cmd(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password):
    """
    Gets mysqlback validate command for cloud backup image
    """
    import constants
    import urlparse

    uri_tokens = urlparse.urlparse(storage_uri)
    MEB = constants.MEB_LOC
    MEB_BACKUP_CONTAINER = cloud_storage_container.split('/')[1]
    MEB_BACKUP_OBJECT_PATH = archive.replace(local_backup_volume_mount, "", 1)
    MEB_BACKUP_OBJECT_PATH = MEB_BACKUP_OBJECT_PATH[1:] if MEB_BACKUP_OBJECT_PATH.startswith('/') else MEB_BACKUP_OBJECT_PATH
    MEB_BACKUP_CLOUD_USER = cloud_storage_container.split('/')[0] + ':' + cloud_storage_user
    MEB_BACKUP_CLOUD_PASSWORD = cloud_storage_user_password
    MEB_BACKUP_CLOUD_URL = uri_tokens.scheme + "://" + uri_tokens.netloc
    CA_CERT_INFO = constants.CA_CERT_INFO

    cmd="{MEB}  --cloud-service=openstack "
    cmd=cmd +  " --cloud-container={MEB_BACKUP_CONTAINER}"
    cmd=cmd +  " --cloud-object={MEB_BACKUP_OBJECT_PATH}"
    cmd=cmd +  " --cloud-user-id='{MEB_BACKUP_CLOUD_USER}'"
    cmd=cmd +  " --cloud-password='{MEB_BACKUP_CLOUD_PASSWORD}'"
    cmd=cmd +  " --cloud-ca-info={CA_CERT_INFO}"
    cmd=cmd +  " --cloud-tempauth-url={MEB_BACKUP_CLOUD_URL}  --backup-image=- validate"
    cmd=cmd.format(MEB=MEB,
                MEB_BACKUP_CONTAINER=MEB_BACKUP_CONTAINER,
                MEB_BACKUP_OBJECT_PATH=MEB_BACKUP_OBJECT_PATH,
                MEB_BACKUP_CLOUD_USER=MEB_BACKUP_CLOUD_USER,
                MEB_BACKUP_CLOUD_PASSWORD=MEB_BACKUP_CLOUD_PASSWORD,
                CA_CERT_INFO=CA_CERT_INFO,
                MEB_BACKUP_CLOUD_URL=MEB_BACKUP_CLOUD_URL)
    return cmd;

#
##
###generates validate command
def get_BMC_validate_cmd(storage_uri, local_backup_volume_mount, cloud_storage_container, archive, cloud_storage_user, cloud_storage_user_password):
    """
    Gets mysqlback validate command for cloud backup image
    """
    import constants
    import urlparse

    uri_tokens = urlparse.urlparse(storage_uri)
    MEB = constants.MEB_LOC
    MEB_BACKUP_CONTAINER = cloud_storage_container.split('/')[1]
    MEB_BACKUP_OBJECT_PATH = archive.replace(local_backup_volume_mount, "", 1)
    MEB_BACKUP_OBJECT_PATH = MEB_BACKUP_OBJECT_PATH[1:] if MEB_BACKUP_OBJECT_PATH.startswith('/') else MEB_BACKUP_OBJECT_PATH
    MEB_BACKUP_CLOUD_USER =  cloud_storage_user
    MEB_BACKUP_CLOUD_PASSWORD = cloud_storage_user_password
    MEB_BACKUP_CLOUD_URL = common_lib.get_BMC_Storage_basicauth_URL(storage_uri) 
    CA_CERT_INFO = constants.CA_CERT_INFO

    cmd="{MEB}  --cloud-service=openstack "
    cmd=cmd +  " --cloud-container={MEB_BACKUP_CONTAINER}"
    cmd=cmd +  " --cloud-object={MEB_BACKUP_OBJECT_PATH}"
    cmd=cmd +  " --cloud-user-id='{MEB_BACKUP_CLOUD_USER}'"
    cmd=cmd +  " --cloud-password='{MEB_BACKUP_CLOUD_PASSWORD}'"
    cmd=cmd +  " --cloud-ca-info={CA_CERT_INFO}"
    cmd=cmd +  " --cloud-basicauth-url={MEB_BACKUP_CLOUD_URL}"  
    cmd=cmd +  " --cloud-chunked-transfer=false"  
    cmd=cmd +  " --cloud-buffer-size=64"  
    cmd=cmd +  " --limit-memory=512"  
    cmd=cmd +  " --backup-image=- validate"
    cmd=cmd.format(MEB=MEB,
                MEB_BACKUP_CONTAINER=MEB_BACKUP_CONTAINER,
                MEB_BACKUP_OBJECT_PATH=MEB_BACKUP_OBJECT_PATH,
                MEB_BACKUP_CLOUD_USER=MEB_BACKUP_CLOUD_USER,
                MEB_BACKUP_CLOUD_PASSWORD=MEB_BACKUP_CLOUD_PASSWORD,
                CA_CERT_INFO=CA_CERT_INFO,
                MEB_BACKUP_CLOUD_URL=MEB_BACKUP_CLOUD_URL)
    return cmd;

