#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'


import abc
import constants
import os
import shutil
import urlparse
import msaas_common_lib as common_lib


#
##
###
def clock(func):
    """
    Decorator function to decorate the functions which need timing inormation
    """
    from datetime import  datetime

    def clocked(*args):
        name = func.__name__
        common_lib.logger("INFO","Entering {name}.".format(name=name))
        startTime = datetime.now()
        result = func(*args)
        duration = datetime.now() - startTime
        duration = duration.seconds * 1000 + duration.microseconds / 1000.0
        common_lib.logger("INFO","Leaving {name}.".format(name=name))
        common_lib.logger("INFO","Total time spent on {name} in milliseconds {duration}".format(name=name, duration=duration))
        return result
    return clocked

def createDir(dirPath):
    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)
    executor = common_lib.Executor()

    if not os.path.isdir(dirPath):
       common_lib.logger("INFO","Creating directory {dirPath}. ".format(dirPath=dirPath))
       executor = common_lib.Executor()
       exe_result = executor.execute_cmd("mkdir -p {dirPath}".format(dirPath=dirPath))
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Unable to create directory {dirPath}. Reason: {reason}"
                                          .format(reason=exe_result.get_detail(),dirPath=dirPath))
          op_return_obj.set_status_msg("<MSCS-ERR-20716>: Unable to create directory")
          op_return_obj.set_bool_status(False)
          return op_return_obj
       common_lib.logger("INFO","Directory {dirPath} created. ".format(dirPath=dirPath))

    return op_return_obj


class BackupFactory():
   """
   Factory class for producing backup objects based on the backup destination and type.
   """
   def __init__(self, dictionaryData):
       self.dictionaryData = dictionaryData

   def get_backupObject(self):
       try:
          backupDestination = self.dictionaryData['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
          isFull = self.dictionaryData['SM_OPERATION_INFO']['backup']['isFull']
          initiatedBy = self.dictionaryData['SM_OPERATION_INFO']['backup']['initiatedBy']
          isBMC = True if self.dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI'].startswith("https://swiftobjectstorage") else False
       except KeyError as e:
          common_lib.logger("ERROR","Key BACKUP_DESTINATION or initiatedBy or isFull not found.")
          raise KeyError
       #BMC check
       if isBMC:
          if backupDestination == "BOTH" and isFull  and initiatedBy == "scheduled" :
             return FullCloudScheduledBackUp(self.dictionaryData)
          elif  backupDestination == "BOTH" and isFull and not initiatedBy == "scheduled" :
             return FullCloudBackUp(self.dictionaryData)
          elif  backupDestination == "BOTH" and not isFull :
             return IncrementalCloudBackUpBMC(self.dictionaryData)
          elif  backupDestination == "OSS" and isFull  and initiatedBy == "scheduled" :
             return FullCloudOnlyScheduledBackUpBMC(self.dictionaryData)
          elif  backupDestination == "OSS" and isFull  and not initiatedBy == "scheduled" :
             return FullCloudOnlyBackUpBMC(self.dictionaryData)
          elif backupDestination == "OSS" and not isFull :
             return IncrementalCloudOnlyBackUpBMC(self.dictionaryData)
          else:
             return None

       #Only if non BMC
       if backupDestination == "DISK" and isFull and initiatedBy == "scheduled" :
          return FullDiskScheduledBackUp(self.dictionaryData)
       elif backupDestination == "DISK" and isFull and not initiatedBy == "scheduled" :
          return FullDiskBackUp(self.dictionaryData)
       elif backupDestination == "DISK" and not isFull :
          return IncrementalDiskBackUp(self.dictionaryData)
       elif backupDestination == "BOTH" and isFull  and initiatedBy == "scheduled" :
          return FullCloudScheduledBackUp(self.dictionaryData)
       elif backupDestination == "BOTH" and isFull and not initiatedBy == "scheduled" :
          return FullCloudBackUp(self.dictionaryData)
       elif backupDestination == "BOTH" and not isFull :
          return IncrementalCloudBackUp(self.dictionaryData)
       elif backupDestination == "OSS" and isFull  and initiatedBy == "scheduled" :
          return FullCloudOnlyScheduledBackUp(self.dictionaryData)
       elif backupDestination == "OSS" and isFull  and not initiatedBy == "scheduled" :
          return FullCloudOnlyBackUp(self.dictionaryData)
       elif backupDestination == "OSS" and not isFull :
          return IncrementalCloudOnlyBackUp(self.dictionaryData)
       else:
          return None

class BackUp:
   """
   Abstract Class backup class
   """
   __metaclass__  = abc.ABCMeta

   def __init__(self, dictionaryData):
       try:
          self.dictionaryData = dictionaryData
          self.backupId = dictionaryData['SM_OPERATION_INFO']['backupId']
          self.backupDestination = self.dictionaryData['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
          self.localStorageRoot = dictionaryData['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT'] if self.backupDestination !="OSS" else os.path.join(os.path.dirname(constants.DATA_DIR), "backupmetadata") 
          self.isFull = dictionaryData['SM_OPERATION_INFO']['backup']['isFull']
          self.initiatedBy = dictionaryData['SM_OPERATION_INFO']['backup']['initiatedBy']
          self.hostList = map(lambda x: x.lower(), dictionaryData['SM_SERVICE_INFO']['components']['mysql']['vmInstances'])
          self.serviceName = dictionaryData['SM_SERVICE_INFO']['serviceName']
          self.serviceType = dictionaryData['SM_SERVICE_INFO']['serviceType']
          self.backupImageName = "backup_full.mbi" if dictionaryData['SM_OPERATION_INFO']['backup']['isFull'] else "backup_incremental.mbi"
          self.MySQLUser = constants.MYSQL_USER
          self.cleanUpRequired = False
          self.backupUploadedToCloud = False
          if self.backupDestination =="OSS" :
             createDir(self.localStorageRoot)
       except KeyError as e:
          common_lib.logger("ERROR","Some keys critical to backup operation are missing in the input JSON.")
          raise KeyError


   @classmethod
   @abc.abstractmethod
   def get_backUpCommand(self):
       return   constants.MEB_LOC + " --user=" + constants.MYSQL_USER

   @classmethod
   @abc.abstractmethod
   def get_backUpValidateCommand(self):
       return   constants.MEB_LOC


   @abc.abstractmethod
   def doBackupAndValidate(self):
       return None

   @abc.abstractmethod
   def doCleanUp(self):
       return None

   @abc.abstractmethod
   def doPreCheck(self):
       """
       Encapsulate pre-checks common across backup types.
       """
       preCheckResults = dict()

       common_lib.logger("INFO","Performing prechecks ")

       preCheck_result = self.checkMySQLStatus()

       if preCheck_result.get_return_code() == 0:
          common_lib.logger("INFO","MySQL server accepting connection.")
          preCheckResults["mysql_status_check"] = { "status" : True , "message" : "MySQL server accepting connection."}
       else:
          common_lib.logger("INFO","MySQL server is down.")
          preCheckResults["mysql_status_check"] = { "status" : False, "message" : "MySQL server is down. Please start MySQL server and retry the operation."}

       preCheck_result = self.checkDataAndBackupDir()
       if preCheck_result.get_return_code() == 0:
          common_lib.logger("INFO","Data directory and  backup volume exist.")
          preCheckResults["dir_check"] = { "status" : True , "message" : "Data directory and backup volume exist."}
       else:
          if preCheck_result.get_return_code() == 3:
             common_lib.logger("INFO","Data directory and backup volume does not exist.")
             preCheckResults["dir_check"] = { "status" : False , "message" : "Data directory and backup volume does not exist."}
          elif preCheck_result.get_return_code() == 2:
             common_lib.logger("INFO","Data directory does not exist.")
             preCheckResults["dir_check"] = { "status" : False , "message" : "Data directory does not exist."}
          else:
             common_lib.logger("INFO","Backup volume does not exits.")
             preCheckResults["dir_check"] = { "status" : False , "message" : "Backup volume does not exist."}


       #perform space check only if the ddata and backup voulme exists.
       if preCheck_result.get_return_code() == 0:
          preCheck_result = self.checkAvailableSpace()
          if preCheck_result.get_return_code() == 0:
             common_lib.logger("INFO","Enough space available on the backup volume for the backup.")
             preCheckResults["space_check"] = { "status" : True , "message" : "Enough space available on the backup volume for the backup."}
          else:
             if preCheck_result.get_return_code() == 2:
                common_lib.logger("INFO","Data directory is empty.")
                preCheckResults["space_check"] = { "status" : False , "message" : "Data directory is empty."}
             else:
                common_lib.logger("INFO","Not enough space available on the backup volume.")
                preCheckResults["space_check"] = { "status" : False , "message" : "Not enough space available on the backup volume. Please increase the space on the backup volume and retry."}

       return preCheckResults


   def set_backupUploadedToCloud(self, value):
       self.backupUploadedToCloud = value

   def isBackupUploadedToCloud(self):
       return self.backupUploadedToCloud

   def isCleanupRequired(self):
       return self.cleanUpRequired

   def set_cleanUpRequired(self,value):
       self.cleanUpRequired = value

   def get_dictionaryData(self):
       return self.dictionaryData

   def get_backupId(self):
       return self.backupId

   def get_localStorageRoot(self):
       return self.localStorageRoot

   def isFull(self):
       return self.isFull

   def get_initiatedBy(self):
       return self.initiatedBy

   def get_hostList(self):
       return self.hostList

   def get_host(self):
       import socket
       return socket.gethostname()

   def get_serviceName(self):
       return self.serviceName

   def get_serviceType(self):
       return self.serviceType

   def get_backupImageName(self):
       return self.backupImageName

   def get_pathToMySQLInstallScript(self):
        #get the script directory
        tools_path=os.path.realpath(__file__)
        #build path to the mysql-instalation-utils.sh
        mysql_install_script=tools_path[:tools_path.index("service_scripts")] + "vm-scripts/mysql-installation-utils.sh"
        return mysql_install_script

   def get_MySQLUser(self):
        return self.MySQLUser


   def get_backupType(self):
       #ToDo make changes to the following as when the details are available
       #if self.get_initiatedBy() == 'weblogic' and self.isFull :
       #   backupType = "onDemandFull"
       #elif self.get_initiatedBy() == 'weblogic' and not self.isFull :
       #   backupType = "onDemandIncremental"
       if self.get_initiatedBy() == 'scheduled' and self.isFull :
          backupType = "scheduledFull"
       elif self.get_initiatedBy() == 'scheduled' and not self.isFull :
          backupType = "scheduledIncremental"
       else:
          backupType = "onDemandFull"
          

       return backupType

   def get_backupMetaData(self):
       return common_lib.getBackupMetaData(self.get_backupDirectory())
       
   def get_backupCloudObject(self):
       """
       Returns objects path in the cloud.
       example : /MSCS/servname/backupid/object_name
       """
       path_till_service_name = os.path.join(self.get_serviceType(), self.get_serviceName())
       path_till_backup_type = os.path.join(path_till_service_name, self.get_backupType())
       path_till_backupId = os.path.join(path_till_backup_type, self.get_backupId())
       object_path = os.path.join(path_till_backupId, self.get_backupImageName())

       return object_path

   def get_backupDirectory(self):
       """
       Returns backup directory on the disk.
       The backup directory holds backup metadata and backup images.
       """
  
       path_till_service_type = os.path.join(self.get_localStorageRoot(), self.get_serviceType())
       path_till_service_name = os.path.join(path_till_service_type, self.get_serviceName())
       backupType = self.get_backupType()
       path_till_type = os.path.join(path_till_service_name, backupType)
       path = os.path.join(path_till_type, self.get_backupId())

       return path

   @clock
   def doBackup(self):
       """
       Performs MySQL backup.
       The command to run the backup is obtained by calling self.get_backUpCommand()
       Returns execution result an instance of CMDExecutionResultClass() in common lib
       """
       common_lib.logger("INFO","Getting backup command")
       #get command executor object
       executor = common_lib.Executor()
       self.set_cleanUpRequired("True")

       backupCommand, backupCommand_for_print, extractCommand, extractCommand_for_print  = self.get_backUpCommand()
       if extractCommand:
          common_lib.logger("INFO","The fullbackup metadata is not avilable on disk.")
          common_lib.logger("INFO","Extracting fullbackup metadata from cloud storage.")
          common_lib.logger("INFO","Executing command {extractCommand}".format(extractCommand=extractCommand_for_print))
          exe_result = executor.execute_cmd(commandline=extractCommand,command_for_print=extractCommand_for_print)
          common_lib.logger("INFO","===============output from mysqlbackup (extract) ================")
          std_out = exe_result.get_std_out()
          std_err = exe_result.get_std_err()
          print exe_result.get_std_out()
          print exe_result.get_std_err()

          if exe_result.get_return_code() != 0:
             common_lib.logger("ERROR","mysqlbackup terminated with retruncode = 1 while perfroming extract.")
             return exe_result

       common_lib.logger("INFO","Starting backup of mysql")
       common_lib.logger("INFO","Executing command {backupCommand}".format(backupCommand=backupCommand_for_print))
       exe_result = executor.execute_cmd(commandline=backupCommand,command_for_print=backupCommand_for_print)
       common_lib.logger("INFO","===============output from mysqlbackup (backup) ================")
       std_out = exe_result.get_std_out()
       std_err = exe_result.get_std_err()
       print exe_result.get_std_out()
       print exe_result.get_std_err()

       #check for 'mysqlbackup completed OK!' to conform the success
       if (std_out + std_err).find("mysqlbackup completed OK!") == -1 and exe_result.get_return_code() == 0:
          common_lib.logger("ERROR","Could not get 'mysqlbackup completed OK!' confirmation for backup")
          exe_result.set_return_code(1) 

       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","mysqlbackup terminated with retruncode = 1 while perfroming backup.")
          exe_result.set_return_code(1) 

       return exe_result

   @clock
   def doBackupValidate(self):
       """
       Validates the backup image created using MEB
       The command to run the validate is obtained by calling self.self.get_backupValidateCommand()
       Returns execution result an instance of CMDExecutionResultClass() in common lib
       """
       common_lib.logger("INFO","Getting backup validation command")
       backupValidateCommand, backupValidateCommand_for_print = self.get_backupValidateCommand()

       #get command executor object
       executor = common_lib.Executor()

       common_lib.logger("INFO","Starting backup validation")
       common_lib.logger("INFO","Executing command {backupValidateCommand}".format(backupValidateCommand=backupValidateCommand_for_print))
       exe_result = executor.execute_cmd(commandline=backupValidateCommand, command_for_print=backupValidateCommand_for_print )
       common_lib.logger("INFO","===============output from mysqlbackup (validate) ================")
       std_out = exe_result.get_std_out()
       std_err = exe_result.get_std_err()
       print exe_result.get_std_out()
       print exe_result.get_std_err()
       
       #check for 'mysqlbackup completed OK!' to conform the success
       if (std_out + std_err).find("mysqlbackup completed OK!") == -1 and exe_result.get_return_code() == 0:
          common_lib.logger("ERROR","Could not get 'mysqlbackup completed OK!' confirmation for validation")
          exe_result.set_return_code(1) 
 
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","mysqlbackup terminated with retruncode = 1 while perfroming backup image validation.")
          exe_result.set_return_code(1) 

       return exe_result

   def checkMySQLStatus(self):
       """
       Confirms if the MySQL is up and accepting connections.
       Invokes getMysqlStatus function in mysql-installation-utils.sh
       Returns execution result an instance of CMDExecutionResultClass() in common lib.
       """
       common_lib.logger("INFO","Verifying connection to MySQL")
       executor = common_lib.Executor()
       op_return_obj = common_lib.OperationReturnObj()

       cmd = "source {mysql_install_script} && getMysqlStatus {mysqluser}"\
                        .format(mysql_install_script=self.get_pathToMySQLInstallScript(), mysqluser=self.get_MySQLUser())
       common_lib.logger("INFO","Running command " + cmd)
       preCheck_result = executor.execute_cmd(cmd)
       return  preCheck_result

   def checkDataAndBackupDir(self):
       datadir_and_backupvolume_check_result = common_lib.CMDExecutionResultClass()
       datadir_and_backupvolume_check_result.set_return_code(0)
       if not os.path.isdir(self.get_localStorageRoot()):
          #common_lib.logger("INFO","Backup volume does not exists.")
          datadir_and_backupvolume_check_result.set_return_code(1)
       if not os.path.isdir(constants.DATA_DIR):
          #common_lib.logger("INFO","Data directory does not exists.")
          if datadir_and_backupvolume_check_result.get_return_code() == 1:
             datadir_and_backupvolume_check_result.set_return_code(3)
          else:
             datadir_and_backupvolume_check_result.set_return_code(2)

       return datadir_and_backupvolume_check_result

   def checkAvailableSpace(self):
       """
       Checks to see if estimated space for backup is avilable on the data directory
       Returns execution result an instance of CMDExecutionResultClass() in common lib.
       """
       import socket
       available_space_check_result = common_lib.CMDExecutionResultClass()
       available_space_check_result.set_return_code(0)

       free_space = common_lib.getdiskFreeSpace(self.get_localStorageRoot())
       #files to be excluded
       excludes = [ 'ib_logfile*', socket.gethostname() + '*', 'ibtmp*', 'undo*' ]
       data_dir_size = common_lib.getDirSize(constants.DATA_DIR, excludes)
       if not free_space >= data_dir_size * 0.6 :
           available_space_check_result.set_return_code(1)
       if data_dir_size == 0 :
          available_space_check_result.set_return_code(2)


       common_lib.logger("INFO","Available disk space on backup volume {free_space} bytes required {data_dir_size} bytes.".format(free_space=free_space, data_dir_size=data_dir_size * 1.1 ))
  
       return available_space_check_result
                      
 


class DiskBackUp(BackUp):
   """
   A sub class of Backup, implements doBackupAndValidate as it will be common for all disk backups.
   """
   def __init__(self, dictionaryData):
       BackUp.__init__(self, dictionaryData)
       self.backUpImageFullName = os.path.join(BackUp.get_backupDirectory(self), BackUp.get_backupImageName(self) )

   @clock
   def doBackupAndValidate(self):
       """
       Calls backup and vlidate functions to backup and vaidate the disk backups.
       Returns an instance for class  OperationReturnObj from common lib
       """
       #get operation return object
       op_return_obj = common_lib.OperationReturnObj()

       exe_result = self.doBackup()
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Backup operation failed in doBackup() mysqlbackup returncode=1, exiting. Please check mysqlbackup logs.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20101>: Backup process failed during backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup of mysql successfully.")

       exe_result = self.doBackupValidate()
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Validate operation failed in doValidate() mysqlbackup returncode=1, exiting.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20102>: Validation of the backup image failed, could not complete backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup image validation successfully.")
       op_return_obj.set_bool_status(True)
       #op_return_obj.set_status_msg("<MSCS-INFO-20100>: Backup and backup image validation completed successfully.")

       return op_return_obj

   def get_backUpImageFullName(self):
       return self.backUpImageFullName

   def doCleanUp(self):
       """
       Cleans up the backup directory.
       """
       if os.path.isdir(self.get_backupDirectory()):
          shutil.rmtree(self.get_backupDirectory(), ignore_errors=True)
          common_lib.logger("INFO","Removed backup directory " + self.get_backupDirectory())

   def doPreCheck(self):
       """
       calls doPreCheck from the base class.
       more pre_checks for disk only backups should be added if required.
       """
       preCheckResults = BackUp.doPreCheck(self)
       return preCheckResults

          

class FullDiskBackUp(DiskBackUp):
   """
   A concreate class of DiskBackup, implements get_backupValidateCommand and get_backUpCommand functions for full backup.
   """
   def __init__(self, dictionaryData):
       DiskBackUp.__init__(self, dictionaryData)


   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

   def get_backUpCommand(self):
       """
       Returns MEB backup command for disk full backup.
       """
       cmd = ( BackUp.get_backUpCommand() + " "
               " --backup-dir=" + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --compress backup-to-image " )
       return cmd, cmd, None, None

class FullDiskScheduledBackUp(DiskBackUp):
   """
   A concreate class of DiskBackup, implements get_backupValidateCommand and get_backUpCommand functions for full scheduled backup.
   """
   def __init__(self, dictionaryData):
       DiskBackUp.__init__(self, dictionaryData)


   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

   def get_backUpCommand(self):
       """
       Returns MEB backup command for disk full backup.
       """
       cmd = ( BackUp.get_backUpCommand() + " "
               " --backup-dir=" + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --compress backup-to-image " )
       return cmd, cmd, None, None


class IncrementalDiskBackUp(DiskBackUp):
   """
   A concreate class of DiskBackup, implements get_backupValidateCommand and get_backUpCommand functions for incremental backup.
   """

   def __init__(self, dictionaryData):
       DiskBackUp.__init__(self, dictionaryData)
       archiveFileName = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName'] 
       self.incrementalBase = os.path.dirname(archiveFileName) if archiveFileName.startswith(self.localStorageRoot) else os.path.dirname(os.path.join(self.localStorageRoot, archiveFileName))

   def get_incrementalBase(self):
       #if not on the disk download to disk and extract the meta folder
       #if not os.path.isDir(self.incrementalBase):
          # raises excetion common_lib.download(
       return self.incrementalBase

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand()  +  " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --incremental_base=dir:" + self.get_incrementalBase() + " "
               " --incremental  backup-to-image " )

       return cmd, cmd, None, None

   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

class CloudBackUp(BackUp):
   """
   A sub class of Backup, implements doBackupAndValidate as it will be common for all cloud backups.
   """

   def __init__(self, dictionaryData):
       BackUp.__init__(self, dictionaryData)
       try:
          self.backUpImageFullName = os.path.join(BackUp.get_backupDirectory(self), BackUp.get_backupImageName(self) )
          self.cloudStorageURI = dictionaryData['SM_OPERATION_INFO']['backup']['backupStorageURI']
          self.cloudStorageUser = dictionaryData['SM_OPERATION_INFO']['cloudStorageUser']
          self.cloudStoragePassword = dictionaryData['SM_OPERATION_INFO']['cloudStoragePassword']
          self.cloudStorageServiceInstanceContainer = common_lib.get_Container_from_Storage_URL(self.cloudStorageURI)
          self.cloudStorageServiceInstance = self.cloudStorageServiceInstanceContainer.split('/')[0]
          self.cloudStorageContainer = self.cloudStorageServiceInstanceContainer.split('/')[1]
          self.uriTokens = urlparse.urlparse(self.cloudStorageURI)
          self.mebCloudStorageURI = self.uriTokens.scheme + "://" + self.uriTokens.netloc
          self.mebCloudStorageUser = self.cloudStorageServiceInstance +  ":" + self.cloudStorageUser
       except KeyError as e:
          common_lib.logger("ERROR","Some keys critical to backup operation are missing in the input JSON.")
          raise KeyError

   def get_cloudObjectURI(self):
       """
       Returns the URL of the object on cloud
       example
         https://storage.oraclecorp.com/v1/<serviceInstanceName>-<identityDomainName>/<container>/<serviceType>/<serviceName>/<backupType>/backupId/backup_full.mbi
       """
       return urlparse.urljoin(self.get_cloudStorageURI(), self.get_backupCloudObject())

   def get_cloudStorageURI(self):
       return self.cloudStorageURI + '/'

   def get_cloudStorageUser(self):
       return self.cloudStorageUser

   def get_cloudStoragePassword(self):
       return self.cloudStoragePassword

   def get_cloudStorageServiceInstanceContainer(self):
       return self.cloudStorageServiceInstanceContainer

   def get_cloudStorageServiceInstance(self):
       return self.cloudStorageServiceInstance

   def get_cloudStorageContainer(self):
       return self.cloudStorageContainer

   def get_uriTokens(self):
       return self.uriTokens

   def get_mebCloudStorageURI(self):
       return self.mebCloudStorageURI

   def get_mebCloudStorageUser(self):
       return self.mebCloudStorageUser

   def get_backUpImageFullName(self):
       return self.backUpImageFullName

   @clock
   def doBackupAndValidate(self):
       """
       Performs MySQL backup on to the disk and uploads the image to cloud storage.
       And also performs validate on the backup image on the disk
       Return:
         rtype: OperationReturnObj
       """ 
       #get operation return object
       op_return_obj = common_lib.OperationReturnObj()

       exe_result = self.doBackup()
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Backup operation failed in doBackup() mysqlbackup returncode=1, exiting. Please check mysqlbackup logs.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20101>: Backup process failed during backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup of mysql successfully.")

       #download_result = self.DownloadBackUpToDisk()
       #if not download_result.get_bool_status():
       #   common_lib.logger("ERROR","backup image could not be downloaded")
       #   op_return_obj.set_bool_status(False)
       #   op_return_obj.append_status_msg(download_result.get_status_msg())
       #   return op_return_obj
       #common_lib.logger("INFO","Finished downloading backup image")
       upload_result = self.upLoadBackupToCloud()
       if not upload_result.get_bool_status():
          common_lib.logger("ERROR","Backup image could not be uploaded to cloud storage." + upload_result.get_status_msg())
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg(upload_result.get_status_msg())
          return op_return_obj
      
       #set the upload status to assit in cleanup
       self.set_backupUploadedToCloud(True)
       
       common_lib.logger("INFO","Finished uploading backup image to cloud storage successfully.")

       exe_result = self.doBackupValidate()
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Validate operation failed in doValidate() mysqlbackup returncode=1, exiting.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20102>: Validation of the backup image failed, could not complete backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup image validation successfully.")
       op_return_obj.set_bool_status(True)
       #op_return_obj.append_status_msg("Backup and backup validation ran successfully.")

       return op_return_obj

   @clock
   def upLoadBackupToCloud(self):
       """
       Uploads the backup image to cloud storage after breaking it into chunks of specified size.
       Return:
         rtype: OperationReturnObj
       """
       op_return_obj = common_lib.OperationReturnObj()
       op_return_obj.set_bool_status(True)

       source = self.get_backUpImageFullName()
       target = self.get_cloudObjectURI()
       credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()

       return_obj, chunksDetail = common_lib.chunkAndUpload(source, target, credential, self.get_cloudStorageURI(), self.get_cloudStorageContainer())
       if not return_obj.get_bool_status():
          op_return_obj.set_status_msg(return_obj.get_status_msg())
          op_return_obj.set_bool_status(False)
          if chunksDetail:
             #delete uploaded chunks
             for key in chunksDetail:
                chunkURL = chunksDetail[key]["target"]
                delete_return_obj = common_lib.deleteObjectFromCloud(chunkURL,credential)
                if not delete_return_obj.get_bool_status():
                   op_return_obj.append_status_msg(" " + delete_return_obj.get_status_msg())

          return op_return_obj

       #op_return_obj.set_status_msg("Sucessfully uploaded the backup image to cloud")
       return op_return_obj


   #@clock
   #def DownloadBackUpToDisk(self):
   #    download_result = common_lib.download_backup_from_cloud(self.get_cloudObjectURI(), self.get_backUpImageFullName(),
   #                                                       self.get_cloudStorageUser(), self.get_cloudStoragePassword())
   #    return download_result

   @clock
   def doCleanUp(self):
       """
       Cleans up backup image on cloud storage and removes the backup directory on disk if it exists
       """

       credential = self.get_cloudStorageUser() + ":" + self.get_cloudStoragePassword()
       #cleanup the disk backup directory
       if os.path.isdir(self.get_backupDirectory()):
          shutil.rmtree(self.get_backupDirectory(), ignore_errors=True)
          common_lib.logger("INFO","Removed backup directory " + self.get_backupDirectory())

       #delete from the cloud storage
       #delete_result=common_lib.delete_backup_from_cloud(self.get_cloudObjectURI(), self.get_cloudStorageUser(),
       #                                                  self.get_cloudStoragePassword())
       if self.isBackupUploadedToCloud():
          target = self.cloudStorageURI + '?prefix=' + self.get_backupCloudObject() + '&&format=json'
          delete_return_obj = common_lib.deleteObjectFromCloudDLO(target, credential)
          if not delete_return_obj.get_bool_status():
             common_lib.logger("ERROR","Backup image could not be deleted")
          else:
             common_lib.logger("INFO","Finished deleting backup image")

   @clock
   def doPreCheck(self):
       """
       calls doPreCheck from the base class.
       more pre_checks for cloud backups should be added if required.
       Return:
         rtype: dictionary, with each precheck as key and status as the value
       """
       preCheckResults = BackUp.doPreCheck(self)
       return preCheckResults

class FullCloudBackUp(CloudBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for full cloud backup.
   """

   def __init__(self, dictionaryData):
       CloudBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --backup-dir=" + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --compress  backup-to-image " )
       return cmd, cmd, None, None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

class FullCloudScheduledBackUp(CloudBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for full cloud scheduled backup.
   """

   def __init__(self, dictionaryData):
       CloudBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --backup-dir=" + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --compress backup-to-image " )
       return cmd, cmd, None, None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

class IncrementalCloudBackUp(CloudBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for incremental cloud backup.
   ToDo: Update  the fucntions once finanlized.
   """

   def __init__(self, dictionaryData):
       CloudBackUp.__init__(self, dictionaryData)
       archiveFileName = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName'] 
       self.fullBackupArchiveName = archiveFileName if archiveFileName.startswith(self.localStorageRoot) else os.path.join(self.localStorageRoot, archiveFileName)
       self.incrementalBase = os.path.dirname(self.fullBackupArchiveName) 


   def get_incrementalBase(self):
       #import urlparse
       #if parent backup dire is not on the disk download from cloud and extract met folder
       #if not os.path.isDir(self.incrementalBase):
       #   backupArchive = self.fullBackupArchiveName
       #   backupVolumeMount =  self.get_localStorageRoot()
       #   credential = backupObj.get_cloudStorageUser() + ":" + backupObj.get_cloudStoragePassword()
       #   cloudObject = backupArchive.replace(backupVolumeMount,"", 1) if not backupArchive.replace(backupVolumeMount,"", 1).startswith('/') else backupArchive.replace(backupVolumeMount,"", 1)[1:]
       #   cloudObjectURI =  urlparse.urljoin(backupObj.get_cloudStorageURI(), cloudObject)
       #   target = os.path.dirname(backupArchive)
       #   delete_return_obj = common_lib.downloadObjectFromCloud(cloudObjectURI, target, credential)
       
       return self.incrementalBase

   def get_backUpCommand(self):
       """
         Generates incremental backup command.
         Also if the incremental base if not available on disk it generates the command to extract the parent backup from cloud storage
       """
       extractCmd = None
       extractCmdToPrint = None

       backupArchive = self.fullBackupArchiveName
       if not os.path.isfile(os.path.join(os.path.dirname(backupArchive), "meta/backup_variables.txt")) :
          backupVolumeMount =  self.get_localStorageRoot()
          cloudObject = backupArchive.replace(backupVolumeMount,"", 1) if not backupArchive.replace(backupVolumeMount,"", 1).startswith('/') else backupArchive.replace(backupVolumeMount,"", 1)[1:]
          fullBackupDir = os.path.dirname(backupArchive)
      
          extractCmd = ( BackUp.get_backUpCommand()  +  " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + cloudObject + " "
               " --backup-dir=" + fullBackupDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  image-to-backup-dir " )

          extractCmdToPrint = extractCmd.replace(self.get_cloudStoragePassword(), "XXXXXXXX")
 
	
       cmd = ( BackUp.get_backUpCommand()  +  " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --incremental_base=dir:" + self.get_incrementalBase() + " "
               " --incremental backup-to-image " )

       return cmd, cmd, extractCmd, extractCmdToPrint

   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand

class CloudOnlyBackUp(CloudBackUp):
   """
   A sub class of Backup, implements doBackupAndValidate as it will be common for all cloud backups.
   """

   def __init__(self, dictionaryData):
       CloudBackUp.__init__(self, dictionaryData)
       try:
          self.backUpImageFullName = self.get_cloudObjectURI()
          self.localStorageRoot = os.path.join(os.path.dirname(constants.DATA_DIR), "backupmetadata")
       except KeyError as e:
          common_lib.logger("ERROR","Some keys critical to backup operation are missing in the input JSON.")
          raise KeyError

   def checkDataDir(self):
       datadir_check_result = common_lib.CMDExecutionResultClass()
       datadir_check_result.set_return_code(0)
       if not os.path.isdir(constants.DATA_DIR):
             datadir_check_result.set_return_code(1)

       return datadir_check_result


   def checkAvailableSpace(self):
       """
       Checks to see if estimated space for backupmetadata is avilable on the data directory
       Returns execution result an instance of CMDExecutionResultClass() in common lib.
       """
       import socket
       available_space_check_result = common_lib.CMDExecutionResultClass()
       available_space_check_result.set_return_code(0)

       free_space = common_lib.getdiskFreeSpace(self.get_localStorageRoot(),"data")
       #files to be excluded
       excludes = [ 'ib_logfile*', socket.gethostname() + '*', 'ibtmp*', 'undo*' ]
       data_dir_size = common_lib.getDirSize(constants.DATA_DIR, excludes)

       if not free_space >= 1048576 :
           available_space_check_result.set_return_code(1)
       if data_dir_size == 0 :
          available_space_check_result.set_return_code(2)

       common_lib.logger("INFO","Available disk space on backupmetadata directory {free_space} bytes required {required_size} bytes.".format(free_space=free_space, required_size=1048576 ))

       return available_space_check_result

   @clock
   def doPreCheck(self):
       """
       Encapsulate pre-checks for cloudonly backup.
       """
       preCheckResults = dict()

       common_lib.logger("INFO","Performing prechecks ")

       
       #check mysql status
       preCheck_result = self.checkMySQLStatus()

       if preCheck_result.get_return_code() == 0:
          common_lib.logger("INFO","MySQL server accepting connection.")
          preCheckResults["mysql_status_check"] = { "status" : True , "message" : "MySQL server accepting connection."}
       else:
          common_lib.logger("INFO","MySQL server is down.")
          preCheckResults["mysql_status_check"] = { "status" : False, "message" : "MySQL server is down. Please start MySQL server and retry the operation."}

       #data directory existance check.
       preCheck_result = self.checkDataDir()
       if preCheck_result.get_return_code() == 0:
          common_lib.logger("INFO","Data directory exist.")
          preCheckResults["dir_check"] = { "status" : True , "message" : "Data directory exists."}
       else:
          common_lib.logger("INFO","Data directory does not exist.")
          preCheckResults["dir_check"] = { "status" : False , "message" : "Data directory does not exist."}


       #perform data directory space check only if the data directory exists.
       if preCheck_result.get_return_code() == 0:
          preCheck_result = self.checkAvailableSpace()
          if preCheck_result.get_return_code() == 0:
             common_lib.logger("INFO","Enough space available on the backupmetadata directiry for the backup metadata.")
             preCheckResults["space_check"] = { "status" : True , "message" : "Enough space available on the backup volume for the backup."}
          else:
             if preCheck_result.get_return_code() == 2:
                common_lib.logger("INFO","Data directory is empty.")
                preCheckResults["space_check"] = { "status" : False , "message" : "Data directory is empty."}
             else:
                common_lib.logger("INFO","Not enough space available on the backupmetadata directory.")
                preCheckResults["space_check"] = { "status" : False , "message" : "Not enough space available on the backupmetadata directory. Please increase the space on the data volume and retry."}

       return preCheckResults


   @clock
   def doBackupAndValidate(self):
       """
       Performs MySQL backup on to the disk and uploads the image to cloud storage.
       And also performs validate on the backup image on the disk
       Return:
         rtype: OperationReturnObj
       """
       #get operation return object
       op_return_obj = common_lib.OperationReturnObj()

       #create Backupmetadata directory
       createDir(self.localStorageRoot)

       exe_result = self.doBackup()
       #set the upload status to assit in cleanup
       self.set_backupUploadedToCloud(True)
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Backup operation failed in doBackup() mysqlbackup returncode=1, exiting. Please check mysqlbackup logs.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20101>: Backup process failed during backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup of mysql successfully.")


       common_lib.logger("INFO","Finished uploading backup image to cloud storage successfully.")

       exe_result = self.doBackupValidate()
       if exe_result.get_return_code() != 0:
          common_lib.logger("ERROR","Validate operation failed in doValidate() mysqlbackup returncode=1, exiting.")
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg("<MSCS-ERR-20102>: Validation of the backup image failed, could not complete backup.")
          return op_return_obj

       common_lib.logger("INFO","Finished backup image validation successfully.")
       op_return_obj.set_bool_status(True)
       #op_return_obj.append_status_msg("Backup and backup validation ran successfully.")

       return op_return_obj

class FullCloudOnlyBackUp(CloudOnlyBackUp):
   #
   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --compress backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print

class FullCloudOnlyScheduledBackUp(CloudOnlyBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for full cloudonly scheduled backup.
   """

   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --compress backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print
class IncrementalCloudOnlyBackUp(CloudOnlyBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for incremental cloud only backup.
   ToDo: Update  the fucntions once finanlized.
   """

   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)
       self.fullBackupArchiveName = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
       self.incrementalBase = os.path.dirname( os.path.join(self.localStorageRoot,self.fullBackupArchiveName ))


   def get_incrementalBase(self):
       return self.incrementalBase


   def get_backUpCommand(self):
       """
         Generates incremental backup command.
         Also if the incremental base if not available on disk it generates the command to extract the parent backup from cloud storage
       """
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --incremental_base=dir:" + self.get_incrementalBase() + " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --incremental backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')

       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_mebCloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-tempauth-url=" + self.get_mebCloudStorageURI() + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print

class FullCloudOnlyBackUpBMC(CloudOnlyBackUp):
   #
   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --compress backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --limit-memory=512 "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print


class FullCloudOnlyScheduledBackUpBMC(CloudOnlyBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for full cloudonly scheduled backup.
   """

   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)

   def get_backUpCommand(self):
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --compress backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --limit-memory=512 "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print

class IncrementalCloudOnlyBackUpBMC(CloudOnlyBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for incremental cloud only backup.
   ToDo: Update  the fucntions once finanlized.
   """

   def __init__(self, dictionaryData):
       CloudOnlyBackUp.__init__(self, dictionaryData)
       self.fullBackupArchiveName = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
       self.incrementalBase = os.path.dirname( os.path.join(self.localStorageRoot,self.fullBackupArchiveName ))


   def get_incrementalBase(self):
       return self.incrementalBase


   def get_backUpCommand(self):
       """
         Generates incremental backup command.
         Also if the incremental base if not available on disk it generates the command to extract the parent backup from cloud storage
       """
       cmd = ( BackUp.get_backUpCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --incremental_base=dir:" + self.get_incrementalBase() + " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --backup-image=-"
               " --incremental backup-to-image" )
       cmd_for_print = cmd.replace(self.get_cloudStoragePassword(),'XXXXXXXX')

       return cmd, cmd_for_print,None,None

   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + self.get_backupCloudObject() + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               " --limit-memory=512 "
               " --backup-image=- validate")

       cmd_for_print = backupValidateCommand.replace(self.get_cloudStoragePassword(),'XXXXXXXX')
       return backupValidateCommand, cmd_for_print


class IncrementalCloudBackUpBMC(CloudBackUp):
   """
   A concreate class of CloudBackUp, implements get_backupValidateCommand and get_backUpCommand functions for incremental cloud backup.
   ToDo: Update  the fucntions once finanlized.
   """

   def __init__(self, dictionaryData):
       CloudBackUp.__init__(self, dictionaryData)
       archiveFileName = dictionaryData['SM_OPERATION_INFO']['backup']['fullBackup']['archiveFileName']
       self.fullBackupArchiveName = archiveFileName if archiveFileName.startswith(self.localStorageRoot) else os.path.join(self.localStorageRoot, archiveFileName)
       self.incrementalBase = os.path.dirname(self.fullBackupArchiveName)


   def get_incrementalBase(self):
       return self.incrementalBase

   def get_backUpCommand(self):
       """
         Generates incremental backup command.
         Also if the incremental base if not available on disk it generates the command to extract the parent backup from cloud storage
       """
       extractCmd = None
       extractCmdToPrint = None

       backupArchive = self.fullBackupArchiveName
       if not os.path.isfile(os.path.join(os.path.dirname(backupArchive), "meta/backup_variables.txt")) :
          backupVolumeMount =  self.get_localStorageRoot()
          cloudObject = backupArchive.replace(backupVolumeMount,"", 1) if not backupArchive.replace(backupVolumeMount,"", 1).startswith('/') else backupArchive.replace(backupVolumeMount,"", 1)[1:]
          fullBackupDir = os.path.dirname(backupArchive)

          extractCmd = ( BackUp.get_backUpCommand()  +  " "
               " --cloud-service=openstack "
               " --cloud-user-id='" + self.get_cloudStorageUser() + "'"
               " --cloud-password='" + self.get_cloudStoragePassword() + "'"
               " --cloud-basicauth-url=" + common_lib.get_BMC_Storage_basicauth_URL(self.cloudStorageURI) + " "
               " --cloud-container=" + self.get_cloudStorageContainer() + " "
               " --cloud-object=" + cloudObject + " "
               " --cloud-chunked-transfer=false "
               " --cloud-buffer-size=64 "
               " --limit-memory=512 "
               " --backup-dir=" + fullBackupDir + " "
               " --cloud-ca-info=" + constants.CA_CERT_INFO + " "
               #" --cloud-ca-info=/etc/ssl/certs/ca-bundle.crt "
               " --backup-image=-  image-to-backup-dir " )

          extractCmdToPrint = extractCmd.replace(self.get_cloudStoragePassword(), "XXXXXXXX")


       cmd = ( BackUp.get_backUpCommand()  +  " "
               " --backup-dir="  + self.get_backupDirectory() + " "
               " --backup-image=" + self.get_backupImageName() + " "
               " --incremental_base=dir:" + self.get_incrementalBase() + " "
               " --incremental backup-to-image " )

       return cmd, cmd, extractCmd, extractCmdToPrint

   def get_backupValidateCommand(self):
       """
       Returns validate command for disk full backup.
       """
       backupValidateCommand = ( BackUp.get_backUpValidateCommand() + " "
               " --backup-image=" + self.get_backUpImageFullName() + " "
               " validate " )
       return backupValidateCommand, backupValidateCommand



