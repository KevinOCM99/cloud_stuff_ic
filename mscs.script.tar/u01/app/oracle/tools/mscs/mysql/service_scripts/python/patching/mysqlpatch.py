import framework
import sys
import os
import logging
import json
import subprocess
import getpass
import time, datetime
import shutil
import constants
from mysqlutils import MysqlUtils
from glob import glob
from collections import OrderedDict

class Patch:

    service_key = constants.serviceKey
    component = constants.component
    
    def __init__(self, pcontext):
        self.context=pcontext
        sc=framework.ShellCommand(pcontext)
        self.mysql=MysqlUtils(pcontext,sc)
        self.patch_folder=constants.patch_folder
        #initialize patch steps make sure functions for steps do exist
        self.patchsteps=OrderedDict(
            [(self.download_patch_binaries_patch_step1,self.download_patch_binaries_patch_revert_step1),
            (self.shutdown_mysql_for_patch_step2,self.revert_shutdown_mysql_for_patch_step2),
            (self.backup_current_mysql_patch_step3 , self.revert_backup_current_mysql_patch_step3 ),
            (self.extract_new_mysql_binary_patch_step4 , self.revert_extract_new_mysql_binary_patch_step4 ),
            (self.change_mysql_soft_link_patch_step5 , self.revert_change_mysql_soft_link_patch_step5 ),
            (self.start_mysql_for_upgrade_patch_step6 , self.revert_start_mysql_for_upgrade_patch_step6 ),
            (self.run_mysqlupgrade_patch_step7 , self.revert_run_mysqlupgrade_patch_step7 ),
            (self.restart_mysql_after_mysqlupgrade_patch_step8 , self.revert_restart_mysql_after_mysqlupgrade_patch_step8 )
            ]
        )
        self.temperory_directories=[]
        self.filestobe_cleaned=[]

    #add a progress message, periodically refresh the last write if buffered
    def add_message(self, message, timestamp = 0, flush=False):
        self.context.addMessage(message,timestamp,flush)

    def add_failure(self, message, timestamp = 0):
        self.context.addFailure(message,timestamp)

    def get_failure(self):
        return self.context.getFailure()

    def log(self,message,level='INFO'):
        MysqlUtils.patchlog(message,level)

    def exit(self, code=0, print_on_stdOut=1, message=None, status=None):
        return self.context.exit(code, print_on_stdOut, message, status)

    def hasVmInstances(self):
        return 'vmInstances' in self.context.args['SM_SERVICE_INFO']['components'][self.service_key]

    #function to execute precheck operation
    def precheck(self,precheckLevelFlag=0):
        ret = 0
        precheck_status = 0
        if precheckLevelFlag == 2 :
            operation_name = "rollback"
        else:
            operation_name = "patching"

        # check if zipBundle is available at cloud storage
        storageURL = self.context.getStorageURL()
        cloudKey = self.context.getStorageKey(
            serviceKey=self.service_key, component=self.component
        )
        mysqlStorageURL = storageURL+'/'+cloudKey
        self.log("Checking if the zipBundle is available on the Cloud storage: "+mysqlStorageURL)
        ret = self.mysql.check_for_zipbundles_on_cloudstorage(mysqlStorageURL)
        if ret != 0:
            self.add_failure("MySQL Binaries NOT Found in Cloud")
            self.log("Check for availability of zip bundles on the cloud storage got failed", "ERROR")
            precheck_status=1
        else:
            self.add_message("MySQL Binaries in Cloud: Verified")
        for hostname in self.context.getHosts(self.service_key):
            # check if MySQL process is running
            self.log("Checking if the MySQL process is running or not for the host : " +hostname)
            ret = self.mysql.check_process(hostname)
            if ret != 0:
                self.add_failure("MySQL Process NOT Found")
                self.log("MySQL running status check got failed","ERROR")
                precheck_status=1
            else:
                self.add_message("Mysql is up and running: Verified")
                self.log("Mysql is up and running: Verified")
            # check available space
            self.log("Checking if the space needed for the "+operation_name+" to be successful is available on the VM or not")
            storageURL=self.context.getStorageURL()
            cloudKey=self.context.getStorageKey(serviceKey=self.service_key, component=self.component)
            ret = self.mysql.check_for_available_space(storageURL,cloudKey,hostname)
            if ret != 0:
                self.log("Space availability check got failed in host" + hostname, "ERROR")
                precheck_status=1
            else:
                self.add_message("Availability of disk space: Verified")

            # TODO remove skipping check for rollback once bug is fixed: 24930642
            # check for md5sum value in payload
            if operation_name == "rollback":
                self.log("md5sum field in payload: Verification Skipped")
            else:
                if self.context.hasMd5sum(serviceKey=self.service_key, component=self.component):
                    self.log("md5sum field in payload: Verified")
                else:
                    self.add_failure("md5sum field is missing in patch payload")
                    self.log("md5sum field in payload: NOT FOUND", "ERROR")
                    precheck_status=1

            # bounce MySQL server
            if precheckLevelFlag == 1:
                self.add_message("Restarting the MySQL server")
                ret = self.mysql.bounceMySQL(hostname,pcontext=self.context)
                if ret!=0:
                    self.log("Failed to bring up MySQL after restart", "ERROR")
                    self.add_failure("Mysql status after bouncing the server: Failed")
                    precheck_status=1
                else:
                    self.log("Mysql status after bouncing the server: Verified")
                    self.add_message("Mysql restart status: Success")
        return precheck_status

    def download_patch_binaries_patch_step1(self,hostname):
        """it is a patch step function, 
        revert function for this is 'download_patch_binaries_patch_revert_step1'
        """

        self.cleanup_objects=[]
        #clean previous patch folders if any exists
        pattern=constants.patch_folder + "*"
        for item in glob(pattern):
            if not os.path.isdir(item):
                continue
            shutil.rmtree(item)

        # make temperory patch directory
        timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y%m%d-%H%M%S')
        self.patch_folder = constants.patch_folder +  timestamp
        os.makedirs(self.patch_folder)
        
        # temp directory where artifacts will be downloaded from the cloud
        self.log("Directory to download the artifacts created : " +self.patch_folder)
        self.msaasInstaller=self.patch_folder + "/msaas-installer-patch.zip"
        self.msaasInstallerExtractLocation="/tmp/patch-msaas-installers" +  timestamp

        # Fetching the artifacts
        storageURL=self.context.getStorageURL()
        md5sum='None'
        if self.operation != 'Rollback':
            if self.context.hasMd5sum(serviceKey=self.service_key, component=self.component):
                md5sum=self.context.getMd5sum(serviceKey=self.service_key, component=self.component)
            else:
                self.log("md5sum field in payload: Not Found", "ERROR")
                patch_status=1
        else:
            md5sum='None'

        cloudKey=self.context.getStorageKey(serviceKey=self.service_key, component=self.component)
        patch_status=self.mysql.fetchArtifact(self.msaasInstaller,storageURL,cloudKey,md5sum,hostname)
        if patch_status != 0:
            raise Exception("Couldn't fetch the artifacts")

        # making temp directory where downloaded artifact/zipped_file will be extracted
        if os.path.exists(self.msaasInstallerExtractLocation):
            shutil.rmtree(self.msaasInstallerExtractLocation)
        os.makedirs(self.msaasInstallerExtractLocation)

        # Extracting the artifacts
        patch_status=self.mysql.extractZipArtifact(self.msaasInstaller,self.msaasInstallerExtractLocation,hostname)
        if patch_status != 0:
            raise Exception("Couldn't extract the MySQL Cloud Service Installer")

        # MySQL and MEB installer temp locations
        self.mysqlInstaller=self.msaasInstallerExtractLocation + "/mysql/*.tar.gz"
        self.mebInstallerZip=self.msaasInstallerExtractLocation + "/meb/*.zip"

        # MySQL required libraries, starting 5.7.19
        self.miscLibsInstaller=self.msaasInstallerExtractLocation + "/misc/*.zip"


    def download_patch_binaries_patch_revert_step1(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'download_patch_binaries_patch_step1'
        """
        pattern=constants.patch_folder + "*"
        #clean previous patch folders if any exists
        try:
            for item in glob(pattern):
                if not os.path.isdir(item):
                    continue
                shutil.rmtree(item)
        except Exception as ex:
            self.log(ex.message,"ERROR")
            self.log("Failed to remove temperory folders for patch","ERROR")


    def revert_shutdown_mysql_for_patch_step2(self,hostname):
        """ this is a patch step revert function,
        """
        ret = self.mysql.check_process(hostname)
        if ret != 0:
            self.log("Couldn't find running MySQL server", "ERROR")
            self.log("Going to start MySQL server")
            status = self.mysql.startMySQL(hostname)
            if status != 0:
                self.log("Couldn't start MySQL server", "ERROR")
                self.add_failure("Couldn't start MySQL server")
            else:
                self.log("Mysql server Started")
                self.add_message("Mysql server Started")

    def shutdown_mysql_for_patch_step2(self,hostname):
        """it is a patch step function, 
        """
        # step: shutdown MySQL
        clean_shutdown = 1
        status = self.mysql.shutdownMysql(hostname, clean_shutdown)
        
        if status != 0:
            raise Exception("Couldn't shutdown MySQL server")

    def backup_current_mysql_patch_step3(self,hostname):
        """it is a patch step function, 
        revert function for this is 'revert_backup_current_mysql_patch_step3'
        """
        # where the installers to be extracted
        self.mysql_extractLocation=constants.BIN_HOME
        self.base_dir=constants.BIN_HOME + "/mysql"

        # soft link of current MySQL installation
        command="readlink {extractLocation}/mysql".format(extractLocation = self.mysql_extractLocation)
        status,stdout = self.mysql.shellcommand.run(command,hostname)
        if status != 0:
            self.log("read link:" + self.mysql_extractLocation+"/mysql error", "ERROR")
            raise Exception("Error in backing up mysql binaries")

        self.current_mysql_location = stdout.strip()
        self.backup_mysql_location = self.mysql_extractLocation + '/mysql_backup'
        self.log("Going to move current mysql "+self.current_mysql_location+" to " + self.backup_mysql_location)
        shutil.move(self.current_mysql_location,self.backup_mysql_location)
        self.add_message("Mysql Binary backed up")
        self.log("Moved "+self.current_mysql_location +" to "+self.backup_mysql_location)

        # delete link to current mysql
        if os.path.exists(self.base_dir):
            self.log("Found link " + self.base_dir)
            os.remove(self.base_dir)
            self.log("Deleted the link: "+self.base_dir+" to: "+self.current_mysql_location)

    def revert_backup_current_mysql_patch_step3(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'backup_current_mysql_patch_step3'
        """

        if os.path.exists(self.backup_mysql_location+'/bin/mysqld_safe'):
            self.log("Found back up at "+self.backup_mysql_location)
        else:
            self.log("Could not Find back up at "+self.backup_mysql_location, "ERROR")
            raise Exception("Couldnot find backup at: "+self.backup_mysql_location)

        # move mysql binary backup to current mysql location
        self.log("Going to move current mysql "+self.backup_mysql_location+" to " + self.current_mysql_location)
        shutil.move(self.backup_mysql_location,self.current_mysql_location)
        self.add_message("Restored current Mysql Binary")
        self.log("Moved "+self.backup_mysql_location +" to "+self.current_mysql_location)

        # restore basedir link to current mysql if link doesnt exist or pointed to somewhere else
        if os.path.exists(self.base_dir):
            self.log("Found link " + self.base_dir)
            command="readlink {basedir}".format(basedir=self.base_dir)
            status,stdout = self.mysql.shellcommand.run(command,hostname)
            if status !=0:
                self.log("read link error", "ERROR")
            else:
                current_link = stdout.strip()
                if current_link == self.current_mysql_location:
                    self.log("Found an existing link pointed to current mysql: "+self.current_mysql_location)
                else:
                    os.remove(self.base_dir)
                    self.log("Deleted the link: "+self.base_dir+" to: "+self.current_mysql_location)
                    status = self.mysql.changeSoftLink(self.base_dir,self.backup_mysql_location,self.current_mysql_location,hostname)
                    if status != 0:
                        raise Exception("Error in changing softlink "+self.base_dir +" to current MySQL dir:" +self.current_mysql_location)
                    else:
                        self.log("Successfully restored the soft link: "+self.base_dir +" to current MySQL dir:" +self.current_mysql_location)
        else:
            status = self.mysql.changeSoftLink(self.base_dir,self.backup_mysql_location,self.current_mysql_location,hostname)
            if status != 0:
                raise Exception("Error in changing softlink "+self.base_dir +" to current MySQL dir:" +self.current_mysql_location)
            else:
                self.log("Successfully restored the soft link: "+self.base_dir +" to current MySQL dir:" +self.current_mysql_location)

    def extract_new_mysql_binary_patch_step4(self,hostname):
        """it is a patch step function, 
        revert function for this is 'revert_extract_new_mysql_binary_patch_step4'
        """
        # get mysql release versions from pcontext
        self.mysql_release_version=self.context.getReleaseVersion(self.service_key)
        self.mysql_current_version=self.context.getCurrentVersion()
        self.log("Current MySQL version: " + self.mysql_current_version + ", New MySQL Version: " + self.mysql_release_version)

        self.log("going to extract mysql installer: "+ self.mysqlInstaller)
        # extracting the new MySQL into BIN_HOME
        self.new_mysql_location = self.mysql.extractMysql(self.mysqlInstaller,self.mysql_release_version,self.mysql_extractLocation)
        self.new_mysql_location = self.new_mysql_location.strip()
        if self.new_mysql_location == constants.FAILURE:
            raise Exception("Couldn't extract the MySQL")

        command = "yum list installed | grep {libnuma} | cut -d ' ' -f 1".format(libnuma=constants.LIBNUMA)
        status,stdout=self.mysql.shellcommand.run(command)
        numaPackage=stdout.strip()
        if not numaPackage:
            # extracting the numa library into LIB_HOME, if it is not installed
            self.log("going to extract mysql required libraries: "+ self.miscLibsInstaller)
            lib_location=self.new_mysql_location + "/lib"
            extract_status=self.mysql.extractZipArtifact(self.miscLibsInstaller,lib_location,hostname)
            if extract_status != 0:
                raise Exception("Couldn't extract the artifacts")

            # set LD_LIBRARY_PATH to mysql lib path 
            mysql_lib_dir=constants.BIN_HOME + "/mysql/lib"
            if 'LD_LIBRARY_PATH' not in os.environ:
                os.environ['LD_LIBRARY_PATH'] = mysql_lib_dir

            command="echo export LD_LIBRARY_PATH={mysql_lib_dir} >> ~/.bashrc".format(mysql_lib_dir=mysql_lib_dir)
            status=self.mysql.shellcommand.run(command)

    def revert_extract_new_mysql_binary_patch_step4(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'extract_new_mysql_binary_patch_step4'
        """
        # remove new mysql directory if exists
        if os.path.exists(self.new_mysql_location):
            self.log("Found new mysql binary folder: "+self.new_mysql_location)
            shutil.rmtree(self.new_mysql_location)
        else:
            self.log("Not Found new mysql binary folder: "+self.new_mysql_location)

    def change_mysql_soft_link_patch_step5(self,hostname):
        """it is a patch step function,
        revert function for this is 'revert_change_mysql_soft_link_patch_step5'
        """
         # step: change soft link 
        status = self.mysql.changeSoftLink(self.base_dir,self.current_mysql_location,self.new_mysql_location,hostname)
        if status != 0:
            raise Exception("Error in changing softlink")
        else:
            self.log("Successfully changed the soft link: "+self.base_dir +" to new MySQL dir:" +self.new_mysql_location)

        # copying my.cnf from old to new directory 
        src = self.backup_mysql_location + '/my.cnf'
        dest = self.new_mysql_location + '/my.cnf'
        try:
            shutil.copy2(src,dest)
            self.log("Copied my.cnf from old: "+ src + " location to new: " + dest)
        except Exception as ex:
            self.log(ex.message,"ERROR")
            raise Exception("Error in copying my.cnf")

    def revert_change_mysql_soft_link_patch_step5(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'change_mysql_soft_link_patch_step5'
        """
        if os.path.exists(self.base_dir):
            try:
                self.log("Found link " + self.base_dir)
                os.remove(self.base_dir)
                self.log("Deleted the link: "+self.base_dir+" to: "+self.current_mysql_location)
            except:
                self.log("Couldn't remove the link: "+self.base_dir, "ERROR")
        else:
            self.log("Could not find link: "+self.base_dir)

    def start_mysql_for_upgrade_patch_step6(self,hostname):
        """it is a patch step function,
        revert function for this is 'revert_start_mysql_for_upgrade_patch_step6'
        """
        # step start mysql server with new binaries for upgrade
        mysql_arguments = "--skip-networking --disabled-storage-engines="
        status = self.mysql.startMySQL(hostname,mysql_arguments)
        if status != 0:
            self.log("Starting MySQL failed", "ERROR")
            self.add_message("Starting Mysql For Upgrade Failed")           
            raise Exception("Error in starting mysql for upgrade")

    def revert_start_mysql_for_upgrade_patch_step6(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'start_mysql_for_upgrade_patch_step6'
        """
        ret = self.mysql.check_process(hostname)
        if ret != 0:
            self.log("MySQL is not running")
        else:
            self.log("Mysql is up and running going to shut down")
            clean_shutdown = 1
            status = self.mysql.shutdownMysql(hostname, clean_shutdown)      
            if status != 0:
                raise Exception("Couldn't shutdown mysql")

    def run_mysqlupgrade_patch_step7(self,hostname):
        """it is a patch step function,
        revert function for this is 'revert_run_mysqlupgrade_patch_step7'
        step : run mysql upgrade 
        """
        # run mysql upgrade with --force option if patch id start with TEST
        patch_id = self.context.getPatchId() 
        test_string = patch_id[:4]
        options = ''
        if test_string == "TEST":
            options = "--force"
        upgrade_status=self.mysql.runMysqlUpgrade(self.base_dir,hostname,options) 
        if upgrade_status != 0:
            self.log("MySQL Upgrade failed", "ERROR")
            self.add_message("Mysql Upgrade Failed")
            raise Exception("MySQL Upgrade failed")

        # copy mysql server file 
        self.data_dir=constants.data_dir 
        try:
            status=self.mysql.copyMysqlServerFile(self.base_dir,self.data_dir,hostname) 
        except:
            self.log("Unable to copy MysqlServerFile", "Warning")

    def revert_run_mysqlupgrade_patch_step7(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'run_mysqlupgrade_patch_step7'
        """
        self.log("Reverting operation started for mysqlupgrade failure")

    def restart_mysql_after_mysqlupgrade_patch_step8(self,hostname):
        """it is a patch step function,
        revert function for this is 'revert_restart_mysql_after_mysqlupgrade_patch_step8'
        """
        # step restart mysql 
        clean_shutdown = 1
        status = self.mysql.shutdownMysql(hostname, clean_shutdown)
        if status != 0:
            self.add_failure("Failed to shutdown MySQL server after upgrade")
            raise Exception("Shuting down MySQL failed after upgrade")
        else:
            self.log("Shutdown mysql after upgrade.")
            self.add_message("Shutdown MySQL server after upgrade")

        #TBD: a temp workaround; need a solid way to check whether mysqld is indeed down.
        time.sleep(10)

        #starting mysql
        status = self.mysql.startMySQL(hostname) 
        if status != 0:
            self.add_failure("Starting Mysql server Failed after upgrade")
            raise Exception("Starting Mysql server Failed after Upgrade")
        else:
            self.log("Started MySQL after mysqlupgrade")
            self.add_message("Started MySQL Server after upgrade")

    def revert_restart_mysql_after_mysqlupgrade_patch_step8(self,hostname):
        """ this is a patch step revert function,
        patch step function for this is 'restart_mysql_after_mysqlupgrade_patch_step8'
        """
        # try shutdown msyql server once again 
        ret = self.mysql.check_process(hostname)
        if ret != 0:
            self.log("MySQL is not running")
        else:
            self.log("Mysql is up and running going to shut down")
            clean_shutdown = 1
            status = self.mysql.shutdownMysql(hostname, clean_shutdown)      
            if status != 0:
                self.log("Failed to shutdown MySQL server after upgrade","ERROR")
                self.add_failure("Failed to shutdown MySQL server after upgrade")


    def handle_patch_failure(self,failed_step,hostname):
        """ this function will run the revert patch steps mentioned in patchseteps 
        dictionary in reverse order from the step caused failure.
        """
        execute_flag=0
        #do revert options of steps from failed step to first step
        for patch_step,patch_revert_step in self.patchsteps.items()[::-1]:
            if execute_flag == 0:
                if failed_step == patch_step:
                    patch_revert_step(hostname)
                    execute_flag=1
            else:
                patch_revert_step(hostname)

    # apply patch for mysql
    def apply_patch(self,operation='Patching'):
        """function to apply patch for mysql installation and meb
            return true if patch steps doesnt throw any error
                and binaries for patch-version are deployed correctly
            returns fals if any of the patch steps fails
                and current binaries are retained
            if any failure happens, function should make sure msyql and meb binaries do exist
            and mysql and meb backup do work.
            TODO - should extend for multiple host patching Later
        """
        patch_status = 0
        self.operation=operation
        for hostname in self.context.getHosts(self.service_key):
            """ going to use the patchsteps ordered dictionary to execute each pat steps functions in order
            if any step fails handle_patch_failure function is called with failing_step as an argument.
            handle_patch_failure method will call revert functions to remove the changes done by patching steps executed so far.
            """
            
            try:
                for patch_step,patch_revert_step in self.patchsteps.items():
                    patch_step(hostname)
            except Exception as ex:
                self.log(ex.message,'ERROR')
                self.add_message("Error in "+operation+" Operation")
                self.log("Starting the "+operation+" failure handling operation")
                self.add_message("Starting "+operation+" failure handling operation")
                try:
                    self.handle_patch_failure(patch_step,hostname)
                except Exception as ex2:
                    self.log(ex2.message,'ERROR')
                    self.add_message(operation+" handling operation Failed")
                    self.log("Failed to handle "+operation+" failure",'ERROR')
                return 1

            """ Patching mysql is successfull 
            going ahead with cleaning temperory folders.
            and Patching MEB
            """
            # adding Temp folders to cleaning objects
            self.cleanup_objects.append(self.patch_folder)
            self.cleanup_objects.append(self.msaasInstallerExtractLocation)
            self.cleanup_objects.append(self.backup_mysql_location)

            # Patching Operations for MEB
            try:
                self.context.addMessage(operation+" MEB")
                self.log(operation+" MEB")
                temp_location="/tmp/patch-meb"
                self.cleanup_objects.append(temp_location)

                # extracting the artifact at temp location
                extract_status=self.mysql.extractZipArtifact(self.mebInstallerZip,temp_location,hostname)
                if extract_status != 0:
                    raise Exception("Couldn't extract the artifacts")
                mebInstaller = temp_location + '/meb*.tar.gz'
                if glob(mebInstaller):
                    self.log("Found MEB installer: "+mebInstaller)
                else:
                    raise Exception("Could not find MEB Installer: "+mebInstaller)
            except Exception as ex:
                # returning true s
                self.log(ex.message,"WARNING")
                self.log("MEB bianry not found, so not "+operation+" MEB")
                self.mysql.removeDirectories(self.cleanup_objects,hostname)
                return 0

            """ patch MEB 
                TODO if not found existing meb install new meb
                on Exception put back meb_backup
            """

            #read the soft link of current MEB installation dir
            meb_extractLocation = constants.BIN_HOME
            current_meb_link = meb_extractLocation + "/meb"
            current_meb=os.readlink(current_meb_link)
            old_meb = meb_extractLocation + '/meb_backup'
            shutil.move(current_meb,old_meb)
            #self.context.addMessage("Moved "+current_meb +" to "+old_meb)
            self.log("Moved "+current_meb +" to "+old_meb)

            #to know the new MEB version
            command = "tar tzf {mebInstaller} | sed -e 's@/.*@@' | uniq".format(mebInstaller=mebInstaller)
            status,stdout = self.mysql.shellcommand.run(command,hostname)
            new_meb=stdout.strip()
            #self.context.addMessage("Current Meb Version: "+current_meb + ", New MEB version: " +new_meb)
            self.log("Current Meb Version: "+current_meb + ", New MEB version: " +new_meb)

            #extract MEB Artifact
            status = self.mysql.extractTarGzArtifact(mebInstaller,meb_extractLocation,hostname)
            if status == 0:
                meb_loc = meb_extractLocation + "/meb"
                new_meb_loc = meb_extractLocation +"/" +new_meb
                status_soft_link = self.mysql.changeSoftLink(meb_loc,old_meb,new_meb_loc,hostname)
                if status_soft_link == 0:
                    #self.context.addMessage("Soft link change is successful ")
                    self.log("Current Meb Version: "+current_meb + ", New MEB version: " +new_meb)
                    self.cleanup_objects.append(old_meb)
                    self.mysql.removeDirectories(self.cleanup_objects,hostname)
                else:
                    #self.context.addMessage("Failed to create soft link")
                    self.log("Failed to create soft link", "ERROR")
                    toRemove = meb_extractLocation +"/" +new_meb
                    try:
                        shutil.rmtree(toRemove)
                    except Exception as ex:
                        os.remove(toRemove)
                    self.context.addMessage("Removed new MEB")
                    self.log("Removed new MEB")
                    self.mysql.changeSoftLink(meb_loc,old_meb,current_meb,hostname)
                    shutil.move(old_meb,current_meb)
            else:
                self.context.addMessage("Failed to create soft link")
                self.log("Failed to create soft link", "ERROR")
                toRemove = meb_extractLocation + "/" +new_meb
                try:
                    shutil.rmtree(toRemove)
                except Exception as ex:
                    os.remove(toRemove)
                shutil.move(old_meb,current_meb)
            self.mysql.removeDirectories(self.cleanup_objects,hostname)

            #check Patch success.
            ret = self.mysql.check_process(hostname)
            if ret != 0:
                self.context.addMessage("MySQL is not up. "+operation+" failed!")
                self.log("MySQL is not up. "+operation+" failed!", "ERROR")
                return ret
            else:
                self.context.addMessage(operation+" successful")
                self.log(operation+" successful")
                return 0
        return patch_status


