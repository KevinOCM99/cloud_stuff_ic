#
# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
#

import os
import zipfile
import shutil
import glob


class msaasLogCollector():
    def __init__(self):
        return

    def details(self):
        return "This collector can be used to collect MySQL server logs from all the servers which are part of this service instance"

    def name(self):
        return "MySQL Log Collector"

    def collect(self, jsonArgs, platformJsonArgs, filePath):
        mysqlLogsDir = filePath
        if not os.path.exists(mysqlLogsDir):
            os.makedirs(mysqlLogsDir)

        self.addFileToDir('/u01/app/oracle/tools/msaas/log/*', mysqlLogsDir)

        self.createZip(mysqlLogsDir, mysqlLogsDir)
        shutil.rmtree(mysqlLogsDir)

    def addFileToDir(self, fileName, mysqlLogsDir):
        for name in glob.glob(fileName):
            shutil.copy2(name, mysqlLogsDir)

    def childCollectors(self):
        return []

    def createZip(self, src, dst):

        zf = zipfile.ZipFile("%s.zip" % (dst), "w", zipfile.ZIP_DEFLATED)
        abs_src = os.path.abspath(src)
        for dirname, subdirs, files in os.walk(src):
            for filename in files:
                absname = os.path.abspath(os.path.join(dirname, filename))
                arcname = absname[len(abs_src) + 1:]
                parentdir = os.path.basename(os.path.abspath(os.path.join(absname, os.pardir)))
                arcname = os.path.join(parentdir, arcname)

                zf.write(absname, arcname)
        zf.close()

