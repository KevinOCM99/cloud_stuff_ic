#!/usr/bin/env python
#
# Copyright (c) 2016 Oracle and/or its affiliates. All rights reserved.
#

import time, datetime
import sys
import os
import subprocess
import json
import logging
import constants
from pprint import pprint


def check_process(host='localhost'):
    """ function to return mysql server status
    returns success if mysql server is up
    returns failure if msyql server is not up
    """
    tools_path = os.path.realpath(__file__)
    mysql_install_script = tools_path[:tools_path.index(
        constants.service_scripts_var)] + constants.mysql_install_script_relative_path
    sys_user = constants.sys_user
    logger("Shell script path used for MySQL running status is : " + mysql_install_script)
    command = "source {mysql_install_script} && getMysqlStatus {sys_user}".format(
        mysql_install_script=mysql_install_script, sys_user=sys_user)
    logger("Command for MySQL running status : " + command)
    status, stdout = call(command)
    logger("Status for the command run is : " + str(status) + ". The stdout says : " + str(stdout))
    if status == 0:
        return constants.SUCCESS
    else:
        return constants.FAILURE


def execute_sql(snapshot_sql):
    """ function to return mysql server status
    returns success if mysql server is up
    returns failure if msyql server is not up
    """

    tools_path = os.path.realpath(__file__)
    mysql_install_script = tools_path[:tools_path.index(
        constants.service_scripts_var)] + constants.mysql_install_script_relative_path
    sys_user = constants.sys_user
    logger("Shell script path used for MySQL running status is : " + mysql_install_script)
    #let executeSqlForCurrentUser() delete the snapshot_sql file
    command = "source {mysql_install_script} && executeSqlForCurrentUser {sql_file} {sys_user} 1".format(
        mysql_install_script=mysql_install_script, sql_file=snapshot_sql, sys_user=sys_user)
    logger("Command for executing SQL: " + command)
    status, stdout = call(command)
    logger("Status for the command run is : " + str(status) + ". The stdout says : " + str(stdout))

    if status == 0:
        return constants.SUCCESS
    else:
        return constants.FAILURE


# blocking call
def call(command, args=None):
    if args:
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(command)
    else:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = process.communicate()

    if not stdout:
        stdout = stderr
    return process.returncode, stdout


# to print the dictionary as a json
def print_dict_as_json(dictionary):
    try:
        print(json.dumps(dictionary, indent=4))
    except Exception as e:
        print(str(e))


def logger(message, level='INFO'):
    """
    logger prints the level and message to standard out
    """ 
    if level == 'PLAIN':
        print message
    else:
        print "%s [%s]:%s" % (time.strftime('%Y-%m-%dT%H:%M:%S.000+00.00', time.gmtime()),
                              level, message)

