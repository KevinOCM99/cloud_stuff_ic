#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'pradeep'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import sys
import atexit
import os

# Add current path to sys.path for imports to succeed
path = os.path.dirname(os.path.realpath(__file__))
if path not in sys.path:
    sys.path.append(path)

import msaas_common_lib as common_lib
import constants
from module_exe_util import ModuleExecutionReturnClass


module_exe_result = ModuleExecutionReturnClass()
module_exe_result.set_operation_type("delete")


def main():
    """
    Performs input JSON validation, if validates returns do_delete function
    and if validation falis returns OperationReturnObj 
    """
 
    op_return_obj = common_lib.OperationReturnObj()
    input_dict_args = common_lib.JSONUtil.decode_from_json_str(sys.argv[1])

    if not input_dict_args:
        common_lib.logger("ERROR","Exiting delete operation. Invalid JSON argument")
        op_return_obj.set_bool_status(False)
        op_return_obj.append_status_msg("Exiting delete operation. Invalid JSON arguments...")
        return op_return_obj

    return do_delete(input_dict_args)

#
##
###
def execute(input_dict_args):
    """
    Performs JSON formated dump and calls do_delete() function.
    If do_delete succeeds returns "0" else "1"
    also  flushes the operation details to stdout
    Operation details are as follows:
    <JsonResult>{
    "status": "Success", 
    "SM_EXECUTION_RESULT": {
        "serviceType": <serviceType>, 
        "serviceName": <serviceName>, 
        "deleteDetails": {
            "deletedBackupImage": <deleted backup image path>
        }
    }, 
    "statusMessage": "Deleted the backup archive: <deleted backup image path>..."
   }
    </JsonResult>
    """
    import copy
    global module_exe_result
    input_dict_args = common_lib.decode_secure_params(input_dict_args)
    #obfuscate password before dumping
    common_lib.logger("INFO","Formated input JSON dump.")
    input_dict_args_for_print = copy.deepcopy(input_dict_args)
    if input_dict_args_for_print.has_key('SM_OPERATION_INFO') and input_dict_args_for_print['SM_OPERATION_INFO'].has_key('cloudStoragePassword'):
       input_dict_args_for_print['SM_OPERATION_INFO']['cloudStoragePassword'] = 'XXXXXXXX'
    #if input_dict_args_for_print.has_key('cloudStoragePassword'):
    #   input_dict_args_for_print['cloudStoragePassword'] = 'XXXXXXXX'
    common_lib.JSONUtil.print_dict_as_json(input_dict_args_for_print)

    result = do_delete(input_dict_args)
    service_info = input_dict_args.get(constants.SERVICE_INFO)
    if service_info:
       module_exe_result.set_service(service_info)

    if module_exe_result:
       module_exe_result.set_bool_status(result.get_bool_status())
       module_exe_result.set_errorType(result.get_error_type())
       status_message=result.get_status_msg()
       status_message=(status_message.replace(status_message.split(':')[0] + ':','')).lstrip()
       module_exe_result.set_status_log(status_message)
       module_exe_result.flush()

    module_exe_result = None

    return 0 if result.get_bool_status() else 1

#
##
### deletes backup archive
def do_delete(json_data):
    """
    Deletes the backup image from the cloud  storage for cloud storage backups 
    Deletes the backup image from disk if it is still available on disk
    Return:
       rtype: OperationReturnObj
    """
    import constants
    import urlparse
    import datetime

    op_return_obj = common_lib.OperationReturnObj()
    op_return_obj.set_bool_status(True)

    startTime = datetime.datetime.now()

    # The argument passed in, must have [backup:archiveFileName]
    archiveFileName = json_data['SM_OPERATION_INFO']['backup']['archiveFileName']
    backup_destination=json_data['SM_SERVICE_INFO']['attributes']['BACKUP_DESTINATION']
    op_return_obj.set_status_msg("<MSCS-INFO-20700>: Deleted the backup archive.")

    if not archiveFileName:
        common_lib.logger("ERROR","Unable to delete the backup, {backup:archiveFileName} is empty in JSON data, exiting the delete operation.")
        op_return_obj.set_bool_status(False)
        op_return_obj.set_error_type("Fatal")
        op_return_obj.set_status_msg("<MSCS-ERR-20701>: Unable to delete the backup. The archiveFileName is "
                                     "empty in input JSON.")
        return op_return_obj


    if backup_destination=="BOTH" or  backup_destination=="OSS" :

       storage_URI=json_data['SM_OPERATION_INFO']['backup']['backupStorageURI']
       uri_tokens=urlparse.urlparse(storage_URI)
       storage_cloud_uri=uri_tokens.scheme + "://" + uri_tokens.netloc
       archive_file_name= json_data['SM_OPERATION_INFO']['backup']['archiveFileName']
       storage_serviceInstance_container=common_lib.get_Container_from_Storage_URL(storage_URI)
       storage_user=json_data['SM_OPERATION_INFO']['cloudStorageUser']
       storage_user_password=json_data['SM_OPERATION_INFO']['cloudStoragePassword']

       if not storage_URI.endswith('/'):
          storage_URI = storage_URI + '/'

       if backup_destination=="BOTH" :
          local_backup_dir=json_data['SM_SERVICE_INFO']['attributes']['LOCAL_BACKUP_VOLUME_MOUNT']
          archive = os.path.join(local_backup_dir, archiveFileName)
          if not local_backup_dir.endswith('/'):
             local_backup_dir =local_backup_dir + '/'
          image_url = urlparse.urljoin(storage_URI,  archive_file_name.replace(local_backup_dir,'', 1))

       if backup_destination=="OSS" :
          image_url = urlparse.urljoin(storage_URI, archive_file_name.replace(storage_URI,'',1))

       credential = storage_user + ':' + storage_user_password
       get_object_info_result, response = common_lib.GetCloudObjectinfo(image_url, credential)
       if not get_object_info_result.get_bool_status():
          common_lib.logger("ERROR","Backup image {image} info could not be found.".format(image=image_url))
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg('Backup image info could not be found.')
          return op_return_obj
       if dict(response.get_http_response().info()).get('x-static-large-object',None): 
          delete_return_obj = common_lib.deleteObjectFromCloud(image_url + '?multipart-manifest=delete', credential)
       else:
          objectPath = image_url.replace(storage_URI, '', 1)
          target = json_data['SM_OPERATION_INFO']['storageURI'] + '?prefix=' + objectPath + '&&format=json' 
          delete_return_obj = common_lib.deleteObjectFromCloudDLO(target, credential)
       #delete_result=common_lib.delete_backup_from_cloud(image_url, storage_user, storage_user_password)
       if not delete_return_obj.get_bool_status():
          common_lib.logger("ERROR","Backup image {URL} could not be deleted from cloud storage.".format(URL=image_url))
          common_lib.logger("ERROR",delete_return_obj.get_status_msg())
          op_return_obj.set_bool_status(False)
          op_return_obj.set_status_msg(delete_return_obj.get_status_msg())
          return op_return_obj
       else:
          common_lib.logger("INFO","Finished deleting backup image {URL} from cloud storage.".format(URL= image_url))

    if backup_destination=="BOTH" :
       executor = common_lib.Executor()
       del_directory=os.path.dirname(archive)
       if os.path.isdir(del_directory):
          common_lib.logger("INFO","Deleting the backup archive {archive}".format(archive=archive))
          deletion_result = executor.execute_cmd("rm -rf {del_directory}".format(del_directory=del_directory))

          if deletion_result.get_return_code() != 0:
             common_lib.logger("ERROR","Unable to delete the backup archive {archive} from disk.".format(archive=archive))
             op_return_obj.set_bool_status(False)
             op_return_obj.set_status_msg("<MSCS-ERR-20702>: Unable to delete the backup archive from disk.")
             #op_return_obj.set_status_msg("<MSCS-ERR-20701>: Unable to delete the backup archive: {archive}"
             #                           .format(archive=archive))
             return op_return_obj
          common_lib.logger("INFO","Finished deleting the backup archive {archive} from disk.".format(archive=archive))
       else:
          common_lib.logger("INFO","The backup archive {archive} not found on the disk".format(archive=archive))

    #calculate the timings
    endTime = datetime.datetime.now()
    duration = endTime - startTime
    duration = duration.seconds * 1000 + duration.microseconds / 1000.0
    common_lib.logger("INFO","Total time spent on deleting the archive in milliseconds {duration}".format(duration=duration))

    module_exe_result.set_operation_detail("deletedBackupImage", archiveFileName)
    return op_return_obj

@atexit.register
def at_exit():
    """
    This function will get invoked when script exits
    :return:
    """
    if module_exe_result:
        module_exe_result.flush()

if __name__ == "__main__":
    result = main()
    module_exe_result.set_status_log(result.get_status_msg())

    sys.exit(0 if result.get_bool_status() else 1)

