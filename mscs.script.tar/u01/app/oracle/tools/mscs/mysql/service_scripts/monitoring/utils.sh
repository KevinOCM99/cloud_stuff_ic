#!/bin/bash

#to get the cpu utilization
getCpuUtilization(){
    top -b -n2 -p 1 | fgrep "Cpu(s)" | tail -1 | awk -F'id,' -v prefix="$prefix" '{ split($1, vs, ","); v=vs[length(vs)]; sub("%", "", v); printf "%s%.1f\n", prefix, 100 - v }' >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       CPU_USAGE=$(top -b -n2 -p 1 | fgrep "Cpu(s)" | tail -1 | awk -F'id,' -v prefix="$prefix" '{ split($1, vs, ","); v=vs[length(vs)]; sub("%", "", v); printf "%s%.1f\n", prefix, 100 - v }')
       echo $CPU_USAGE
       return 0
    fi
}

#to get free memory
getFreeMemory(){
    free -m | fgrep "Mem" | awk '{printf $4}' /dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       FREE_MEM=$(free -m | fgrep "Mem" | awk '{printf $4}')
       echo $FREE_MEM
       return 0
    fi
}

#to get mysql status
getMySQLStatus(){
    MYSQLSTATUS=$(mysqladmin -uoracle status 2>&1)
    status=$?
    echo $MYSQLSTATUS
    return $status
}

#to get queries per second
getQueriesPerSecond(){
    mysqladmin -uoracle status >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       QPS=$(mysqladmin -uoracle status | awk '{print $(NF)}')
       echo $QPS
       return 0
    fi
}


#to get uptime in seconds
getMySQLUpTime(){
    mysqladmin -uoracle status >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       UT=$(mysqladmin -uoracle status | cut -d ' ' -f 2)
       echo $UT
       return 0
    fi
}

#to get no of open connections
getOpenConnections(){
    mysql -uoracle -e "show status like '%onn%'" >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       OC=$(mysql -uoracle -e "show status like '%onn%'" | grep Threads_connected | awk '{print $(NF)}')
       echo $OC
       return 0
    fi
}


#to get data volume utilization
getDataVolumeUtilization(){
    df -kh | grep data | awk '{print $4}' | sed 's/.$//' >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       DV_USAGE=$(df -kh | grep data | awk '{print $4}' | sed 's/.$//')
       echo $DV_USAGE
       return 0
    fi
}

#to get data volume utilization
getDataVolumeFree(){
    df -kh | grep data | awk '{print $4}' | sed 's/.$//' >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       DV_USAGE=$(df -kh | grep data | awk '{print $4}' | sed 's/.$//')
       DV_FREE=$((100-DV_USAGE))
       echo $DV_FREE
       return 0
    fi
}


#to get translog volume utilization
getTransLogVolumeUtilization(){
    df -kh | grep log | awk '{print $4}' | sed 's/.$//' >/dev/null 2>&1
    status=$?
    if [ $status -ne 0 ]; then
       return 1
    else
       TV_USAGE=$(df -kh | grep log | awk '{print $4}' | sed 's/.$//')
       echo $TV_USAGE
       return 0
    fi
}

