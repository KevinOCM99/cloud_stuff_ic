#!/usr/bin/env python
#
# Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.
#
__author__ = 'calvin'
__copyright__ = 'Copyright (c) 2014-2015 Oracle and/or its affiliates. All rights reserved.'

import os
import time
import constants
import msaas_common_lib as common_lib


#
##
### Delete one backup from disk
def delete_backups_from_disk(local_backup_dir):
    """
    Delete the backup image on disk.
    Return:
    """

    common_lib.logger("INFO", "Start deleting expired backups from disk.")

    # Get current time for consistent cutoff
    now = time.time()

    # first, delete incremental backups older than 7 days.
    incr_dir = os.path.join(local_backup_dir, constants.INCREMENTAL_BACKUP_DIR)
    incr_files = find_matching_files(incr_dir, constants.INCREMENTAL_BACKUP_NAME)
    for backup in incr_files:
        #common_lib.logger("INFO", "Incremental backup file: {backup}.".format(backup=backup))
        if os.stat(backup).st_mtime < now - constants.LOCAL_RETENTION_DAYS * 86400:
            delete_one_backup_from_disk(backup)

    # next, delete full backups older than 7 + 6 days.
    full_dir = os.path.join(local_backup_dir, constants.FULL_BACKUP_DIR)
    full_files = find_matching_files(full_dir, constants.FULL_BACKUP_NAME)
    for backup in full_files:
        #common_lib.logger("INFO", "Full backup file: {backup}.".format(backup=backup))
        if os.stat(backup).st_mtime < now - (constants.LOCAL_RETENTION_DAYS + 6) * 86400:
            delete_one_backup_from_disk(backup)

    # also, delete on-demand full backups older than 7 days.
    on_demand_dir = os.path.join(local_backup_dir, constants.ON_DEMAND_BACKUP_DIR)
    on_demand_files = find_matching_files(on_demand_dir, constants.FULL_BACKUP_NAME)
    for backup in on_demand_files:
        #common_lib.logger("INFO", "On demand backup file: {backup}.".format(backup=backup))
        if os.stat(backup).st_mtime < now - constants.LOCAL_RETENTION_DAYS * 86400:
            delete_one_backup_from_disk(backup)

    common_lib.logger("INFO", "Finished deleting expired backups from disk.")


#
##
### Find all matching files under the path
def find_matching_files(path, file_name):
    result = []
    for root, dirs, files in os.walk(path):
        if file_name in files:
            result.append(os.path.join(root, file_name))
    return result


#
##
### Delete one backup
def delete_one_backup_from_disk(backup_file):
    """
    Delete the backup image identified by backupInfo from disk.
    Return:
    """

    import shutil

    backup_file_dir = os.path.dirname(backup_file)

    if os.path.isdir(backup_file_dir):
        try:
            shutil.rmtree(backup_file_dir)
            common_lib.logger("INFO","Deleted backup {backup} from disk.".format(backup=backup_file_dir))
        except IOError as e:
            common_lib.logger("ERROR","Failed to delete backup {backup} from disk.".format(backup=backup_file_dir))
    else:
        common_lib.logger("INFO","The backup {backup} not found on disk".format(backup=backup_file_dir))
